<?php
session_start();

unset($_SESSION['login']);
unset($_SESSION['userId']);
unset($_SESSION['firstName']);
unset($_SESSION['lastName']);
unset($_SESSION['email']);
unset($_SESSION['phone']);
unset($_SESSION['address']);

session_unset();
session_destroy();
session_commit();

header("location: register.php");
?>