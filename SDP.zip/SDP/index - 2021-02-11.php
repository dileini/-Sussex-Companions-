<?php
require_once('./header.php');

require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM products WHERE productID='" . $_GET["code"] . "'");
			$newProductID  = 'x'.$productByCode[0]["productID"];
			$itemArray     = array($newProductID=>array('name'=>$productByCode[0]["productTitle"], 
																	 'code'=>$productByCode[0]["productID"], 
																	 'quantity'=>$_POST["quantity"], 
																	 'price'=>$productByCode[0]["newAmnt"], 
																	 'image'=>'images/'.$productByCode[0]["homepageImage"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($newProductID,array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($newProductID == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					var_dump($v);
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]); 
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
//new cart
$product_array = $db_handle->runQuery("SELECT * FROM products ORDER BY productID");
?>
<title>Sussex Companions</title>
<style type="text/css">
<!--
.style1 {color: #F00}
-->
</style><body>
<div class="wrapper">
  <?php
require_once('./menu.php');
?>
  <section class="main-slider">
      <div class="slider">
      <ul class="mslider">
    <?php
/*$selectSlideShowImage = "SELECT `ID`,
						`Name`,
						`Image`,
						`status`,
						`type`
						FROM `slide_show`";

$selectslideshowRes = mysql_query($selectSlideShowImage);

if(mysql_num_rows($selectslideshowRes)!=0)
{
	while($mySlide = mysql_fetch_array($selectslideshowRes))
	{
		$sID 			  = $mySlide['ID'];
		$sName 			  = $mySlide['Name'];
		$sImage 	 	  = $mySlide['image'];
		$sstatus		  = $mySlide['status'];
		$stype		      = $mySlide['type'];
	}
}*/
?>
		<li><img src="images/slider2.jpg"/></li>
        <li><img src="images/slider3.jpg"/></li>
		<li><img src="images/slider4.jpg"/></li>
      </ul>
    </div>
    <div class="main-slider-curve curve-img"></div>
  </section>
  <section class="welcome-section">
    <div class="container">
      <div class="row">
        <div class="inner-container">
          <div class="col-lg-6">
            <h1 align=>Welcome to <br>
              Sussex Companions</h1>
            <br />
            <p align=> <strong> We are club for the over 50s, which seeks to match up individuals with new friends. </strong></p>
            <p align=>The company is based in Brighton - a charming city by the sea on the South Coast of England.Many people move to Brighton and other places on the South Coast after retirement and seek to find newfriends with similar hobbies and interests. SC has lots of customers and is thriving as a business. </p>
          </div>
          <div class="col-lg-6"><img src="images/wcpic.png"></div>
        </div>
      </div>
    </div>
  </section>
  <section class="pro-slider">
    <div class="pro-bx-slider">
      <div class="pro-slider-wrap" >
        <ul class="pbxslider gallery" align="center"> </ul>
      </div>
    </div>
  </section>
  <section class="new-collection">
    <div class="container">
      <div class="row">
        <div class="">
          <div class="col-lg-12 stitle">
            <h2 align="left">New Member</h2>
          </div>
          <div id="main-container">
            <div id="content"> </div>
            <!--/content-->
            <div style="display:none;" class="nav_up" id="nav_up">
              <div style="margin-top:3px;margin-left:2px;"> <strong></strong> </div>
            </div>
            <script language="Javascript" type="text/javascript">
$(function() {
    var $elem = $('#content');

    $('#nav_up').fadeIn('slow');

    $(window).bind('scrollstop', function() {
        $('#nav_up,#nav_down').stop().animate({'opacity': '0.4'});
    });

    $('#nav_up').click(
        function(e) {
            $('html, body').animate({scrollTop: '0px'}, 600);
        }
    );
});
</script>
            <p style="clear:both;"></p>
          </div>
          <!--/main-container-->
          
<?php


//new cart

if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
	<form method="post" action="index.php?action=add&code=<?php echo $product_array[$key]["productID"]; ?>">
		<div class="col-lg-3 col-sm-3">
            <div class="deal_store round">
              <div class="pro-holder">
                <div class="deal-image">
                  <!--<div class="sale-tag">New</div>-->
                  <img src="images/<?php echo $product_array[$key]["homepageImage"]; ?>" alt="productggg" width="100%" style="border-radius:10px;box-shadow:0px 1px 2px rgba(0,0,0,0.3);"/></a> </div>
                <div class="pro-content">
                  <div class="title_store">
                    <h4 class="pro-title" style="color:#000066; margin-left:7px;"> <?php echo $product_array[$key]["productTitle"]; ?> <span> <a target="_blank" href="moreInfo.php?id=<?php echo $product_array[$key]["productID"] ?>">(more info..)</a></span> <span style="color:#F00">5%</span> OFF! &nbsp;&nbsp; </h4>
                  </div>
                  <div class="pro-footer">
                    <div class="deal-row" style="margin-bottom:5px; width:100%;">
                      <div class="grid_original"><span style="color:#000">Original Price </span> <br/>
                        <strong><span style="color:#000">Rs. <?php echo $product_array[$key]["originalPrice"]; ?></span></strong></div>
                      <div class="grid_dc"><span style="color:#000">Discount</span> <br/>
                        <strong><span style="color:#000"><?php echo $product_array[$key]["discountAmnt"]; ?></span></strong> </div>
                      <div class="grid_save"><span style="color:#000">You Save </span><br/>
                        <strong><span style="color:#000">Rs. </span><span class="style1"><?php echo $product_array[$key]["saveAmt"]; ?></span></strong></div>
                    </div>
                    <div class="price_store" style="width:100%">
                      <h4 style="margin-left:15px;"><span style="color:#00f">Now Only Rs.</span><span class="style1"><?php echo $product_array[$key]["newAmnt"]; ?></span></h4 >
                    </div>
					<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input type="submit" value="Add to Cart" class="btnAddAction" /></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
	</form>	
			
	<?php
		}
	}
	
	else{
		echo 'no records';
		
		
	}


?>	   
        </div>
      </div>
    </div>
  </section>
  <?php
require_once('./footer.php');
?>
</div>
</body>
</html>