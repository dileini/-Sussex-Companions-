<?php
require_once('./header.php');
?>

<body>
 
<div class="wrapper">
 
<?php
require_once('./menu.php');
?> 
 
<section class="main-slider inner-slider">
<div class="slider">
<ul class="mslider-inner">
<li><img src="images/si1.jpg" alt="spare parts Responsive"/></li>
<li><img src="images/si2.jpg" alt="spare parts Responsive"/></li>
<li><img src="images/si3.jpg" alt="spare parts Responsive"/></li>
</ul>
</div>
<div class="main-slider-curve curve-img"></div>
</section>
 
 
<section class="about">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12">
<h2 class="main-title">Our Story</h2>
<h4 class="sub-title">Buy motor spare parts online at best price in Sri Lanka.</h4>
</div>
</div>
 
<div class="row">
<div class="col-lg-12 col-md-12">
<div class="about-main">
<p><img src="images/about-pic.jpg" alt=""></p>
<p>Lanka Auto Motive Spare Parts website is the ultimate source to find quality and reliable Toyota, Nissan, Mitsubishi,Honda and Suzuki products for the lowest price in SriLanka. </p>
<p>We provide excellent customer service and expert advice for your convenience of being able to shop right from the comfort of your home.</p>
</div>
</div>
</div>
 
<div class="gap-45"></div>
 
<div class="row">
<div class="col-lg-12 col-md-12 full-tabs">
 
<ul class="nav nav-tabs">
<li><a href="#tab1" data-toggle="tab">History</a></li>
</ul>
 
<div class="tab-content">
<div class="tab-pane active" id="tab1">
<p> Lanka Auto Motive Spare Parts shop was established in 1977 by Mr. Nimal Perera , the founder of Lanka Auto Motive Spare Parts shop. His entrepreneurial spirit and quest for a superior and affordable form of motor spare parts for Sri Lankans led him to introduce best auto motive products to Sri Lanka.</p>
</div>
</div>
</div>
</div>
 
<div class="experts">
<div class="row">
<div class="col-lg-12 col-md-12">
<h2 class="main-title">Meet Our Team</h2>
</div>
</div>
<div class="row team gallery">
<div class="col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/t4.jpg" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Nimal Perera</a></h3>
<span>Ceo & Director</span>
<p>Nimal Perera is the founder of Lanka Auto Motive Spare Parts shop. His entrepreneurial spirit and quest for a superior and affordable form of motor spare parts for Sri Lankans.</p>
</li>
<li></li>
</ul>
</div>
<div class="col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/t1.jpg" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Kamal Silva</a></h3>
<span>General Manager</span>
<p>Kamal Siva's background in management skills help to ensure high market share by maximizing sales through service network.</p>
</li>
<li></li>
</ul>
</div>
<div class="col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/t3.jpg" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Anitha Jenny</a></h3>
<span>Sals Manager</span>
<p>Anitha Jenny' sales management skills has achieve growth and hit sales targets by successfully managing the sales team.</p>
</li>
<li></li>
</ul>
</div>
<div class="col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/t2.jpg" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Josh Gayan</a></h3>
<span>Assistant Sales Manager</span>
<p>Josh Gayan is able to delegate tasks to the sales staff in the absence of the Sales Manager and responsible for developing strategies to improve sales, effectively.</p>
</li>
<li></li>
</ul>
</div>
</div>
 
</div>
<div class="row">
<div class="partner-logos">
<h3>Our Partners</h3>
<ul class="pbxslider gallery">
<li class="col-lg-2 col-sm-2"><img src="images/brand1.png" alt=""/></li>
<li class="col-lg-2 col-sm-2"><img src="images/brand2.png" alt=""/></li>
<li class="col-lg-2 col-sm-2"><img src="images/brand3.png" alt=""/></li>
<li class="col-lg-2 col-sm-2"><img src="images/brand4.png" alt=""/></li>
<li class="col-lg-2 col-sm-2"><img src="images/brand5.png" alt=""/></li>
<li class="col-lg-2 col-sm-2"><img src="images/brand6.png" alt=""/></li>
</ul>
</div>
</div>
 
</div>
</section>


<?php
require_once('./footer.php');
?>


</div>
 
</body>

</html>
