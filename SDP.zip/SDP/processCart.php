<?php
session_start();
require_once('./header.php');
require_once("dbcontroller.php");
$db_handle    = new DBController();
$newProductID = "";
$userId       = "";
$firstName    = "";
$lastName     =	"";
$emailAddress =	"";
$phoneNo      =	"";
$address      =	"";
$nic          =	"";

if(isSet($_SESSION['login']) && $_SESSION['login'] == 1){
//Required detals for process shopping-cart
$userId       = $_SESSION['userId'];
$firstName    =	$_SESSION['firstName'];
$lastName     =	$_SESSION['lastName'];
$emailAddress =	$_SESSION['email'];
$phoneNo      =	$_SESSION['phone'];
$address      =	$_SESSION['address'];
$nic          =	$_SESSION['nic'];

}
else{
	header("location: register.php?err=3");
}

if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM products WHERE productID='" . $_GET["code"] . "'");
			$newProductID  = 'x'.$productByCode[0]["productID"];
			$itemArray     = array($newProductID=>array('name'=>$productByCode[0]["productTitle"], 
																	 'code'=>$productByCode[0]["productID"], 
																	 'quantity'=>$_POST["quantity"], 
																	 'price'=>$productByCode[0]["newAmnt"], 
																	 'image'=>'images/'.$productByCode[0]["homepageImage"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($newProductID,array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($newProductID == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					var_dump($v);
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]); 
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}

//new cart

if(isSet($_GET['job']) && isSet($_GET['searchme'])){
	$query   = "SELECT * FROM products where `productID` <> 0 ";
	$catos   = "";
	$itemTex = "";
	if($_GET['job'] != '0'){
		$query = $query . " and `catoID` = " .$_GET['job'];
	}
	if($_GET['searchme'] != ''){
		$query = $query . " and `productTitle` LIKE '%". $_GET['searchme'] ."%' ";
	}
	//echo $query;
	$product_array = $db_handle->runQuery($query);
}
else{
	$product_array = $db_handle->runQuery("SELECT * FROM products ORDER BY productID");
}
?>

<title>Lanka Automotive Motor Spare Parts  Store</title>
<style type="text/css">
<!--
.style1 {color: #F00}
-->
</style><body>
<div class="wrapper">
  <?php
require_once('./menu.php');
?>
  <section class="main-slider">
      <div class="slider">
      <ul class="mslider">
		<li><img src="images/slider2.jpg"/></li>
        <li><img src="images/slider3.jpg"/></li>
      </ul>
    </div>
    <div class="main-slider-curve curve-img"></div>
  </section>
  <section class="welcome-section">
    <div class="container">
      <div class="row">
        
		<div id="shopping-cart">
<div class="txt-heading">Shopping Cart</div>

<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	
<table cellpadding="10" cellspacing="1" class="blueTable" border="1">
<thead>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Code</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
</tr>
<thead>	
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ". number_format($item_price,2); ?></td>
				</tr>
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>

<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong>$ <span id="finalPrice"><?php echo number_format($total_price, 2); ?> </span></strong></td>
</tr>
</tbody>
</table>		
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty Now</div>
<?php 
}
?>
</div>
		
		
      </div>
    </div>
  </section>
  <section class="pro-slider">
    <div class="pro-bx-slider">
      <div class="pro-slider-wrap" >
        <ul class="pbxslider gallery" align="center"> </ul>
      </div>
    </div>
  </section>
  <section class="new-collection">
    <div class="container">
      <div class="row">
        <div class="inner-container">
          <div class="col-lg-12 stitle">
            <h2 align="left">Personal detals and shipping</h2>
          </div>
          <div id="main-container">
<form name="paymentForm" action="myOrders.php" method="post">            
<div class="col-md-6">
<div class="form-group">
<div class="input-group">
<input type="text" class="form-control" name="Fname" id="Fname" placeholder="First name" required value="<?php echo $firstName; ?>" >
<span class="input-group-addon"><i class="fa fa-user"></i></span> </div>
</div>
<div class="form-group">
<div class="input-group">
<input type="text" class="form-control" name="Lname" id="Lname" placeholder="Last name" required value="<?php echo $lastName; ?>" >
<span class="input-group-addon"><i class="fa fa-envelope"></i></span> </div>
</div>
<div class="form-group">

<div class="form-group">
<div class="input-group">
<input type="text" class="form-control" name="Email" id="Email" placeholder="Email" required value="<?php echo $emailAddress; ?>" >
<span class="input-group-addon"><i class="fa fa-phone"></i></span> </div>
</div>

<div class="form-group">
<div class="input-group">
<input type="text" class="form-control" name="Phone" id="Phone" placeholder="Phone number" required value="<?php echo $phoneNo; ?>" >
<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
</div>


<div class="form-group">
<div class="input-group">
<input type="text" class="form-control" name="nic" id="nic" placeholder="National ID card Number" required value="<?php echo $nic; ?>" >
<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
</div>



<div class="form-group">
<div class="input-group textarea">
  <textarea name="Address" id="Address" class="form-control" placeholder="Address" rows="2" required ><?php echo $address; ?></textarea>
</div>

<div class="form-group">
<div class="input-group">
<br/>
Payment Method
<input name="pay" type="radio" id="cod" value="cod" checked="CHECKED"> &nbsp;
  <label for="male">COD</label> &nbsp; &nbsp; &nbsp;
  <input type="radio" id="online" name="pay" value="online">
  &nbsp;
  <label for="female">Online Payment</label><br>
  </div>
</div>

<div class="form-group" style="padding-top:25px;">
<input type="submit" name="submit" id="submit" value="Compleate Order" class="btn btn-info pull-down">
</div>
</div>
<input type="hidden" id="finalPrice" name="finalPrice" value="<?php echo $total_price; ?>">
</div>
</form>































           
            
            
            
            
            
            
            
            <!--/content-->
            <div style="display:none;" class="nav_up" id="nav_up">
              <div style="margin-top:3px;margin-left:2px;"> <strong></strong> </div>
            </div>
			<div></div>
            <script language="Javascript" type="text/javascript">
$(function() {
    var $elem = $('#content');

    $('#nav_up').fadeIn('slow');

    $(window).bind('scrollstop', function() {
        $('#nav_up,#nav_down').stop().animate({'opacity': '0.4'});
    });

    $('#nav_up').click(
        function(e) {
            $('html, body').animate({scrollTop: '0px'}, 600);
        }
    );
});
</script>
            <p style="clear:both;"></p>
          </div>
        <!--/main-container--></div>
      </div>
    </div>
  </section>
  <?php
require_once('./footer.php');
?>
</div>
</body>
</html>