<?php
session_start();
include("dealsManager/db_connector.php");
$username = $_POST['uname'];
$password = md5($_POST['passwd']);

$selectQuery = "SELECT `id`,`firstName`,`lastName`,`gender`,`email`,`password`,`phone`,`address` , `nic`
FROM customer 
WHERE `email` = '$username' AND `password` = '$password'";

$_SESSION['login']=0;
$_SESSION['userId']="";
$_SESSION['firstName']="";
$_SESSION['lastName']="";
$_SESSION['email']="";
$_SESSION['phone']="";
$_SESSION['address']="";
$_SESSION['nic']="";


$result = mysql_query($selectQuery);
$recCount = mysql_num_rows($result);

if($recCount>=1){
	$res=mysql_fetch_row($result);
	//var_dump($res);
	
	$_SESSION['login']='1';
	$_SESSION['userId']=$res['0'];
	$_SESSION['firstName']=$res['1'];
	$_SESSION['lastName']=$res['2'];
	$_SESSION['email']=$res['4'];
	$_SESSION['phone']=$res['6'];
	$_SESSION['address']=$res['7'];
	$_SESSION['nic']=$res['8'];

	//header("location: products.php");
	header("location: list.php");
	
}
else{
	header("location: register.php?err=1");
}


?>