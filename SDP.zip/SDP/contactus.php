<?php
require_once('./header.php');
?>
<style type="text/css">
<!--
.style2 {
			font-size: 16px;
			font-weight:bold;
			color: #FF0000;
		}
-->
</style>
<body>
 
<div class="wrapper">
 
<?php
require_once('./menu.php');
?>
 
<section class="main-slider inner-slider">
<div class="slider">
<ul class="mslider-inner">
<li><img src="images/si1.jpg" alt="spare parts Responsive"/></li>
<li><img src="images/si2.jpg" alt="spare parts Responsive"/></li>
<li><img src="images/si3.jpg" alt="spare parts Responsive"/></li>
</ul>
</div>
<div class="main-slider-curve curve-img"></div>
</section>
 
 
<section class="contact">
<div class="container">
<div class="row">
<div class="col-lg-10 col-md-10">
<h2 class="main-title">Contact Us.<span class="style2">
  <br>
  <?php
if(isSet($_GET['err'])){ 
	if($_GET['err'] == '5'){
		echo 'E-mail sucessfully send.';
	}
	if($_GET['err'] == '6'){
		echo 'E-mail sending error. please try again';
	}
	
}

?>
</span></h2>
<p class="p">Want to get in touch with us? we would love to hear from you. If you have any qiuestions, just fill in the contact form and we will answer you shortly. If you live nearby feel free to visit our premices.</p>
</div>
</div>
<div class="row">
<div class="col-lg-8">
<div class="contact-form">
<form id="contactform" method="post" action="./contact/contact-process.php">
<div class="col-md-6">
<div class="form-group">
<div class="input-group">
<input name="name" type="text" required class="form-control" id="name" placeholder="Name">
<span class="input-group-addon"><i class="fa fa-user"></i></span> </div>
</div>
<div class="form-group">
<div class="input-group">
<input name="email" type="text" required class="form-control" id="email" placeholder="Email">
<span class="input-group-addon"><i class="fa fa-envelope"></i></span> </div>
</div>
<div class="form-group">
<div class="input-group">
<input name="phone" type="text" required class="form-control" id="phone" placeholder="Phone">
<span class="input-group-addon"><i class="fa fa-phone"></i></span> </div>
</div>
<div class="form-group">
<div class="input-group">
<input name="subject" type="text" required class="form-control" id="subject" placeholder="Subject">
<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
</div>
</div>
<div class="col-md-6 text-area">
<div class="form-group">
<div class="input-group textarea">
<textarea name="message" id="message" class="form-control" placeholder="Message" rows="11" required></textarea>
</div>
</div>
<input type="submit" name="submit" id="submit" value="Submit" class="btn btn-info pull-right">
</div>
</form>
</div>
</div>
<div class="col-md-4">
<address>
<ul>
<li>
<p class="first">Here's how you can reach us.</p>
</li>
<li class="add">
<p>No:820, Battaramulla.</p>
</li>
<li class="tell">
<p> T : 0112853853</p>
</li>
<li class="skype">
<p>Fax: 0112862545</p>
</li>
<li class="email">
<p><a href="mailto:info@lankaAutomotive.com">info@lankaAutomotive.com</a></p>
</li>
</ul>
</address>
</div>
</div>

</div>
</section>
 

<?php
require_once('./footer.php');
?>


</div>
 
</body>

</html>
