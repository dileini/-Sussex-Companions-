<?php
session_start();
require_once('./header.php');
require_once("dbcontroller.php");
$db_handle    = new DBController();
$newProductID = "";
$userId       = "";
$firstName    = "";
$lastName     =	"";
$emailAddress =	"";
$phoneNo      =	"";
$address      =	"";
$nic          =	"";
$finalPrice   = "";
$shipping     = "";
$payment      = "";

$fastShipping = 300.00;
$slowShipping = 0.00;
$finalShipping= 0.00;

$payMethod = 'cod';
$totalCost = 0.00;

$userId       = $_SESSION['userId'];

if(isSet($_SESSION['login']) && $_SESSION['login'] == 1 && isSet($_POST['submit'])){
//Required detals for process shopping-cart

$firstName    =	$_POST['Fname'];
$lastName     =	$_POST['Lname'];
$emailAddress =	$_POST['Email'];
$phoneNo      =	$_POST['Phone'];
$address      =	$_POST['Address'];
$nic          =	$_POST['nic'];
$finalPrice   = $_POST['finalPrice'];
$shipping     = "";
$payment      = $_POST['pay'];

if($shipping == 'fast'){
	$finalShipping = $fastShipping;
}else{
	$finalShipping = $slowShipping;
}

if($payment == 'online'){
	$payMethod = 'online';
}

$totalCost = $finalPrice + $fastShipping;


//insert to the database
$insetHeadQuery = "insert into `order_head`(`user_id`,`firstName`,`lastName`,`email`,`phone`,`address`,`nic`,
					`product_cost`,`shipping`,`total_price`,`pay_method`, `odr_date`)
values($userId,'$firstName','$lastName','$emailAddress','$phoneNo','$address','$nic',
					 $finalPrice,$finalShipping,$totalCost,'$payMethod', now())";
mysql_query($insetHeadQuery);

//selecting the max record
$maxRecQ = mysql_query("select max(`id`) from `order_head`");
$maxRecQres = mysql_fetch_row($maxRecQ);
$orderHeadId = $maxRecQres[0];

//extracting items form shopping cart
foreach ($_SESSION["cart_item"] as $item){
    $item_price = $item["quantity"]*$item["price"];
	
	//inserting the items to DB
	$insetItemQ = "insert into `order_items`(`user_id`,`head_id`,`item_id`,`item_name`,`unit_price`,`qty`,`total_price`)
					values($userId,$orderHeadId,".$item["code"].",'". $item["name"] ."',". $item["price"] .",". $item["quantity"] .",". $item_price.")";
	mysql_query($insetItemQ);	
	
	$eventID = $item["code"];
	$insertToEvent = "INSERT INTO `assign_event`(`client_id`, `event_id`) 	VALUES($userId,$eventID)";
	mysql_query($insertToEvent);
	
	
}

//Clear the cart session.
unset($_SESSION["cart_item"]);
header("location: myOrders.php?err=5");
}

?>


<style type="text/css">
<!--
.style2 {
			font-size: 16px;
			font-weight:bold;
			color: #FF0000;
		}
-->
</style>

<title>Lanka Automotive Motor Spare Parts  Store</title>


<body>
<div class="wrapper">
  <?php
require_once('./menu.php');
?>
  <section class="main-slider">
      <div class="slider">
      <ul class="mslider">
		<li><img src="images/slider2.jpg"/></li>
        <li><img src="images/slider3.jpg"/></li>
      </ul>
    </div>
    <div class="main-slider-curve curve-img"></div>
  </section>
  <section class="welcome-section">
    <div class="container">
      <div class="row">
        
		<div id="shopping-cart">
 <h2>
<span class="style2"> 
<?php
if(isSet($_GET['err'])){ 
	if($_GET['err'] == '5'){
		echo 'Order Process is Completed. ';
	}
}

?></span>

</h2>       
        
<div class="txt-heading">My Orders</div>
<?php 
	$selectMyOrder = "SELECT h.`id` as orderNo, h.`user_id`, h.`firstName`, h.`lastName`, h.`email`, h.`phone`, h.`address`, h.`nic`, h.`ordere_date`, h.`product_cost`,
		h.`shipping`, h.`total_price`, h.`pay_method`, h.`current_status`,
		i.`id`, i.`user_id`, i.`head_id`, i.`item_id`, i.`total_price`, i.`unit_price`, i.`qty`, i.`order_date`, i.`item_name`
		FROM `order_head` h, `order_items` i
		WHERE h.`id`=i.`head_id` AND h.`user_id`=$userId
		ORDER BY h.`id` DESC";
	$selectMyOrderRes = mysql_query($selectMyOrder);
	
	if(mysql_num_rows($selectMyOrderRes) != '0'){
		?>
<table cellpadding="10" cellspacing="1" class="blueTable" border="1">
<thead>
  <tr>
  	<th scope="col" style="text-align:left;">#</th>
    <th scope="col"style="text-align:right;">Order ID</th>
    <th scope="col" style="text-align:right;">Order Date</th>
    <th scope="col" style="text-align:right;">Dilivary Address</th>
    <th scope="col" style="text-align:right;">Order Status</th>
    <th scope="col" style="text-align:right;">Item Total Cost</th>
    <th scope="col" style="text-align:right;">Total Price</th>
    <th scope="col" style="text-align:right;">Payment Method</th>
    <th scope="col" style="text-align:right;">Item Name</th>
    <th scope="col" style="text-align:right;">Unit Price</th>
    <th scope="col" style="text-align:right;">QTY</th>
    <th scope="col" style="text-align:right;">Total</th>
  </tr>
  </thead>
		<?php
	$itemId = "";
	$count = 1;
	while($row = mysql_fetch_array($selectMyOrderRes)){
		?>
<tr>
  	<td><?php
	if($itemId != $row['orderNo']){echo $count++;}
	
	?></td>
    <td style="text-align:center;"><?php 
	if($itemId != $row['orderNo']){ echo $row['orderNo']; }
	?></td>
    <td><?php if($itemId != $row['orderNo']){ echo $row['ordere_date']; }?></td>
    <td><?php if($itemId != $row['orderNo']){ echo $row['address']; }?></td>
    <td><?php if($itemId != $row['orderNo']){ echo $row['current_status']; }?></td>
    <td><?php if($itemId != $row['orderNo']){ echo $row['product_cost']; }?></td>
    <td><?php if($itemId != $row['orderNo']){ echo $row['total_price']; }?></td>
    <td><?php if($itemId != $row['orderNo']){ echo $row['pay_method']; }?></td>
    <td><?php echo $row['item_name']; ?></td>
    <td><?php echo $row['unit_price']; ?></td>
    <td><?php echo $row['qty']; ?></td>
    <td><?php echo $row['total_price']; ?></td>
</tr>
		
		
		<?php
		$itemId = $row['orderNo'];
		
	}
	
	?>
	</table>
	<?php
	}
	
	
	else{
		echo '<span style="font-weight:bold; color: #FF0000;"> You dont have any orders..</span>';
	}
	  
	  
	  ?>
		</div>
      </div>
    </div>
  </section>

  <?php
require_once('./footer.php');
?>
</div>
</body>
</html>