/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 10.4.16-MariaDB : Database - lamsp
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lamsp` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lamsp`;

/*Table structure for table `brands` */

DROP TABLE IF EXISTS `brands`;

CREATE TABLE `brands` (
  `brandId` int(11) NOT NULL AUTO_INCREMENT,
  `brandName` varchar(255) NOT NULL,
  `brandImage` varchar(300) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'yes',
  `brandOrder` int(11) NOT NULL,
  PRIMARY KEY (`brandId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `brands` */

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `nic` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`id`,`firstName`,`lastName`,`gender`,`email`,`password`,`phone`,`address`,`nic`) values (1,'Mahinda','jay','m','a@b.com','e10adc3949ba59abbe56e057f20f883e','0117558965','Address',NULL),(2,'Amal','Silva','m','amal@gmail.com','21ad0bd836b90d08f4cf640b4c298e7c','0784512122','Colombo','7815232V'),(3,'Kamal','Perera','m','kamal@gmail.com','21ad0bd836b90d08f4cf640b4c298e7c','0775684521','Gampaha',NULL),(4,'Nimal','Soysa','m','nimal@gmail.com','21ad0bd836b90d08f4cf640b4c298e7c','078451221','Gall',NULL),(5,'Ramani','Perera','f','ramani@gmail.com','21ad0bd836b90d08f4cf640b4c298e7c','076451124','Kadawatha',NULL),(6,'Saman','Siri','m','saman@gmail.com','21ad0bd836b90d08f4cf640b4c298e7c','0777451221','Rajagiriya',NULL),(7,'abc1','a','m','abc@gmail.com','23734cd52ad4a4fb877d8a1e26e5df5f','0781245124','s','12712320'),(8,'aa','b','m','z@gmail.com','e99a18c428cb38d5f260853678922e03','017','acb','124'),(9,'Mahinda','Jayasundara','m','m@j.com','4124bc0a9335c27f086f24ba207a4912','0777768414','My address\r\nTest','198414001042'),(10,'mahinda','Jaya','m','a@g.com','4124bc0a9335c27f086f24ba207a4912','0777768404','ffsfs','198414001042');

/*Table structure for table `depot` */

DROP TABLE IF EXISTS `depot`;

CREATE TABLE `depot` (
  `depotID` int(11) NOT NULL AUTO_INCREMENT,
  `depotCorde` varchar(100) DEFAULT NULL,
  `depotText` varchar(100) DEFAULT NULL,
  `depotPhone` varchar(100) DEFAULT NULL,
  `depotImageURL` varchar(500) DEFAULT NULL,
  `depotTotalEmp` int(11) DEFAULT NULL,
  `regionCode` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`depotID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `depot` */

insert  into `depot`(`depotID`,`depotCorde`,`depotText`,`depotPhone`,`depotImageURL`,`depotTotalEmp`,`regionCode`) values (1,'HO001','Rajagiriya',NULL,NULL,0,'HO');

/*Table structure for table `jobcats` */

DROP TABLE IF EXISTS `jobcats`;

CREATE TABLE `jobcats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catoCode` varchar(100) DEFAULT NULL,
  `catoText` varchar(100) DEFAULT NULL,
  `addDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `catStatus` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

/*Data for the table `jobcats` */

insert  into `jobcats`(`id`,`catoCode`,`catoText`,`addDate`,`catStatus`) values (17,'BD','Break Disks','2020-11-28 01:03:29',0),(18,'CSC','Central Slave Cylinder','2020-10-01 12:23:05',0),(19,'CC2','Central Slave Cylinder- clutch MAXGEAR','2020-10-01 12:20:02',0),(21,'PVB','Poly V- Belt','2020-10-01 12:24:31',1),(22,'AF','Air Filters','2020-10-01 12:25:08',1),(23,'OFT','Oil Filter Tools','2020-10-01 12:25:46',1),(24,'OF','Oil Filters','2020-10-01 12:26:24',1),(25,'AH','Amio Horns','2020-10-01 12:26:59',1),(26,'BH','Bosh Horns','2020-10-01 12:27:24',1),(27,'OVH','Other Vehicle Horns','2020-10-01 12:28:13',1),(28,'CK','Clutch Kit','2020-10-03 10:10:22',1),(29,'SC','Slave Cylinder','2020-10-03 10:17:59',1),(30,'BRH','Break Hose','2020-10-20 12:42:55',1),(31,'BP','Break Pads','2020-10-20 12:47:11',1),(33,'EO','Engine Oil','2020-10-20 13:01:21',1),(34,'WP','Water Pump','2020-10-20 13:07:39',1),(35,'CCSC','Central C Slave Cylinder','2020-10-20 13:16:06',1);

/*Table structure for table `order_head` */

DROP TABLE IF EXISTS `order_head`;

CREATE TABLE `order_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `nic` varchar(12) DEFAULT NULL,
  `ordere_date` timestamp NULL DEFAULT current_timestamp(),
  `product_cost` decimal(12,2) DEFAULT NULL,
  `shipping` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(12,2) DEFAULT NULL,
  `pay_method` varchar(20) DEFAULT NULL,
  `current_status` varchar(50) DEFAULT 'pending',
  `odr_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `order_head` */

insert  into `order_head`(`id`,`user_id`,`firstName`,`lastName`,`email`,`phone`,`address`,`nic`,`ordere_date`,`product_cost`,`shipping`,`total_price`,`pay_method`,`current_status`,`odr_date`) values (1,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V',NULL,'4080.00','300.00','4380.00','cod','Shiped',NULL),(2,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V',NULL,'4080.00','0.00','4380.00','cod','Completed',NULL),(3,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V',NULL,'4840.00','300.00','5140.00','cod','Completed',NULL),(4,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V',NULL,'4840.00','0.00','5140.00','cod','Shiped',NULL),(6,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-16 10:00:45','4840.00','300.00','5140.00','cod','pending',NULL),(7,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-16 10:01:19','4840.00','300.00','5140.00','online','pending','2020-11-16'),(8,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-16 10:44:30','4840.00','0.00','5140.00','cod','pending','2020-11-16'),(9,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-16 10:45:15','4840.00','0.00','5140.00','cod','pending','2020-11-16'),(10,2,'Amal','Silva','amal@gmail.com','0784512122','No 501,\r\nBattaramulla','7815232V','2020-11-16 10:54:53','4840.00','300.00','5140.00','online','pending','2020-11-16'),(11,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-16 11:08:19','9700.00','300.00','10000.00','online','pending','2020-11-16'),(12,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-16 11:11:44','2900.00','0.00','3200.00','cod','Shiped','2020-11-16'),(13,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-18 21:49:19','1425.00','0.00','1725.00','cod','pending','2020-11-18'),(14,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-20 11:06:03','42750.00','300.00','43050.00','cod','pending','2020-11-20'),(15,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-23 00:04:16','1900.00','0.00','2200.00','cod','pending','2020-11-23'),(16,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-23 00:09:40','1900.00','0.00','2200.00','cod','pending','2020-11-23'),(17,2,'Amal','Silva','amal@gmail.com','0784512122','Colombo','7815232V','2020-11-25 10:53:53','2460.00','0.00','2760.00','cod','pending','2020-11-25');

/*Table structure for table `order_items` */

DROP TABLE IF EXISTS `order_items`;

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `head_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `total_price` double(10,2) DEFAULT NULL,
  `unit_price` double(10,2) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `item_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `order_items` */

insert  into `order_items`(`id`,`user_id`,`head_id`,`item_id`,`total_price`,`unit_price`,`qty`,`order_date`,`item_name`) values (1,2,9,8,1700.00,1700.00,1,'2020-11-16 10:46:53',' Air Filter VALEO'),(2,2,9,9,760.00,760.00,1,'2020-11-16 10:47:31','Air Filter DENCKERMANN'),(3,2,9,25,860.00,860.00,1,'2020-11-16 10:47:38','Oil Filter Pliers VOREL'),(4,2,9,24,1520.00,760.00,2,'2020-11-16 10:47:46','Fuel Filter Spanner KS TOOLS'),(5,2,10,8,1700.00,1700.00,1,'2020-11-16 10:54:54',' Air Filter VALEO'),(6,2,10,9,760.00,760.00,1,'2020-11-16 10:54:54','Air Filter DENCKERMANN'),(7,2,10,25,860.00,860.00,1,'2020-11-16 10:54:54','Oil Filter Pliers VOREL'),(8,2,10,24,1520.00,760.00,2,'2020-11-16 10:54:54','Fuel Filter Spanner KS TOOLS'),(9,2,11,20,950.00,950.00,1,'2020-11-16 11:08:19','V-Ribbed Belts DT'),(10,2,11,10,4750.00,475.00,10,'2020-11-16 11:08:19','Air Filter FILTRON '),(11,2,11,51,4000.00,800.00,5,'2020-11-16 11:08:19','Brake Pad Set, disc brake A.B.S.'),(12,2,12,8,1700.00,1700.00,1,'2020-11-16 11:11:44',' Air Filter VALEO'),(13,2,12,31,1200.00,1200.00,1,'2020-11-16 11:11:44','Air Horn AMiO'),(14,2,13,42,950.00,950.00,1,'2020-11-18 21:49:19','BOSCH Horn Set '),(15,2,13,10,475.00,475.00,1,'2020-11-18 21:49:20','Air Filter FILTRON '),(16,2,14,64,42750.00,2850.00,15,'2020-11-20 11:06:03','Profit Calculate'),(17,2,15,7,950.00,950.00,1,'2020-11-23 00:04:17','V-Ribbed Belts RIDEX'),(18,2,15,49,950.00,950.00,1,'2020-11-23 00:04:17','Brake Hose A.B.S.'),(19,2,16,7,950.00,950.00,1,'2020-11-23 00:09:40','V-Ribbed Belts RIDEX'),(20,2,16,49,950.00,950.00,1,'2020-11-23 00:09:40','Brake Hose A.B.S.'),(21,2,17,8,1700.00,1700.00,1,'2020-11-25 10:53:53','Air Filter VALEO'),(22,2,17,9,760.00,760.00,1,'2020-11-25 10:53:54','Air Filter DENCKERMANN');

/*Table structure for table `order_status` */

DROP TABLE IF EXISTS `order_status`;

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_test` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `order_status` */

insert  into `order_status`(`id`,`status_test`) values (1,'Pending'),(2,'Shiped'),(3,'Completed'),(4,'Cancel');

/*Table structure for table `product_comment` */

DROP TABLE IF EXISTS `product_comment`;

CREATE TABLE `product_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `producct_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `person_name` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `product_comment` */

insert  into `product_comment`(`comment_id`,`producct_id`,`comment`,`person_name`,`status`) values (1,8,'This prodcut is good, Recomended to buy.','Dil',1),(2,8,'good one','Rohan',0),(3,8,'This a good one. low cost. Its worth','Roshana',1),(4,31,'Sound qulity is not good.','Rohan',1);

/*Table structure for table `product_rating` */

DROP TABLE IF EXISTS `product_rating`;

CREATE TABLE `product_rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `product_rating` int(11) DEFAULT NULL,
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `product_rating` */

insert  into `product_rating`(`rating_id`,`product_id`,`product_rating`) values (1,8,5),(2,8,1),(3,8,4),(4,8,4),(5,10,5),(6,10,5),(7,10,1),(8,10,4),(9,31,1);

/*Table structure for table `productimages` */

DROP TABLE IF EXISTS `productimages`;

CREATE TABLE `productimages` (
  `imageID` int(11) NOT NULL AUTO_INCREMENT,
  `productID` int(11) DEFAULT NULL,
  `imageURLOne` varchar(1000) DEFAULT 'products/def1.jpg',
  `imageURLTwo` varchar(1000) DEFAULT 'products/def2.jpg',
  `imageURLThree` varchar(1000) DEFAULT 'products/def3.jpg',
  `imageURLFour` varchar(1000) DEFAULT 'products/def4.jpg',
  `imageURLFive` varchar(1000) DEFAULT 'products/def5.jpg',
  `imageAddedDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `image1` varchar(1000) DEFAULT 'products/def1.jpg',
  `image2` varchar(1000) DEFAULT 'products/def2.jpg',
  `image3` varchar(1000) DEFAULT 'products/def3.jpg',
  PRIMARY KEY (`imageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `productimages` */

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `productID` int(11) NOT NULL AUTO_INCREMENT,
  `catoID` int(11) DEFAULT NULL,
  `productTitle` varchar(1000) DEFAULT NULL,
  `offPresent` int(11) DEFAULT NULL,
  `originalPrice` decimal(10,2) DEFAULT NULL,
  `discountAmnt` decimal(10,2) DEFAULT NULL,
  `saveAmt` decimal(10,2) DEFAULT NULL,
  `newAmnt` decimal(10,2) DEFAULT NULL,
  `homepageImage` varchar(1000) DEFAULT 'frontImage/default.jpg',
  `adMainImage` varchar(1000) DEFAULT 'mainImage/default.jpg',
  `productDesc` varchar(5000) DEFAULT '',
  `itemOrder` int(11) DEFAULT NULL,
  `productAddDate` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `productEndDate` date DEFAULT NULL,
  `availableProductsQTY` int(11) DEFAULT NULL,
  `productEnableDesable` int(1) DEFAULT 1,
  `image1` varchar(1000) DEFAULT 'products/def1.png',
  `image2` varchar(1000) DEFAULT 'products/def2.png',
  `image3` varchar(1000) DEFAULT 'products/def3.png',
  `soteF` int(11) NOT NULL DEFAULT 100000,
  `reorder_level` int(11) DEFAULT 50,
  `view_count` int(11) DEFAULT 1,
  `buyingRate` double(10,2) DEFAULT NULL,
  PRIMARY KEY (`productID`),
  KEY `soteF` (`soteF`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

/*Data for the table `products` */

insert  into `products`(`productID`,`catoID`,`productTitle`,`offPresent`,`originalPrice`,`discountAmnt`,`saveAmt`,`newAmnt`,`homepageImage`,`adMainImage`,`productDesc`,`itemOrder`,`productAddDate`,`productEndDate`,`availableProductsQTY`,`productEnableDesable`,`image1`,`image2`,`image3`,`soteF`,`reorder_level`,`view_count`,`buyingRate`) values (7,21,'V-Ribbed Belts RIDEX',5,'1000.00','0.00','50.00','950.00','frontImage/1602933843-7no 3- V-Ribbed Belts RIDEX.jpg','mainImage/default.jpg','<p><strong>Length [mm]:</strong><strong>1070</strong></p><p><strong>Number of ribs:</strong><strong>6</strong></p>',NULL,'2020-11-23 00:09:40','2021-03-05',9,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,2,750.00),(8,22,'Air Filter VALEO',5,'1800.00','0.00','90.00','1700.00','frontImage/1602933661-8No 1- Air Filter VALEO.jpg','mainImage/default.jpg','<p><strong>Construction year to:</strong><strong>01/2016</strong></p><p><strong>Engine Code:</strong><strong>274.920</strong></p>',NULL,'2020-11-25 10:53:54','2021-03-05',149,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,1600.00),(9,22,'Air Filter DENCKERMANN',5,'800.00','0.00','40.00','760.00','frontImage/1602933683-9no 2- Air Filter DENCKERMANN.jpg','mainImage/default.jpg','<p><strong>Length [mm]:</strong><strong>276</strong></p><p><strong>Width [mm]:</strong><strong>177</strong></p>',NULL,'2020-11-25 10:53:54','2021-03-05',149,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,500.00),(10,22,'Air Filter FILTRON',5,'500.00','0.00','25.00','475.00','frontImage/1602933702-10no 3- Air Filter FILTRON.jpg','mainImage/default.jpg','<p><strong>Manufacturer: FILTRON</strong></p><p><strong>Length [mm]: 276</strong></p><p><strong>Width [mm]: 177</strong></p><p>',NULL,'2020-11-28 01:02:40','2021-03-05',10,1,'products/def1.png','products/def2.png','products/def3.png',1,10,1,320.00),(12,17,'Brake Disc STARK',5,'800.00','0.00','40.00','760.00','frontImage/1602933034-12No 02-Brake Disc STARK.jpg','mainImage/default.jpg','<p>Internally Vented, without wheel hub, without wheel studs</p>',NULL,'2020-11-20 11:22:04','2021-03-05',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,5,400.00),(20,21,'V-Ribbed Belts DT',5,'1000.00','0.00','50.00','950.00','frontImage/1602933537-20no 1 V-Ribbed Belts DT.jpg','mainImage/default.jpg','<p><strong>[mm]: </strong><strong>1060</strong></p><p><strong>Number of ribs:</strong><strong>6</strong></p>',NULL,'2020-11-20 11:22:19','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,750.00),(21,21,'V-Ribbed Belts BOSCH',5,'1000.00','0.00','50.00','950.00','frontImage/1608273529-212893C4F600000578-3078082-image-a-18_1431427854176.jpg','mainImage/1608273549-212893C4F600000578-3078082-image-a-18_1431427854176.jpg','<p><strong>Length [mm]: </strong><strong>1070</strong></p><p><strong>Number of ribs:</strong><strong>6</strong></p>',NULL,'2020-12-18 12:09:33','2021-03-20',100,1,'products/1608273573-212893C4F600000578-3078082-image-a-18_1431427854176.jpg','products/def2.png','products/def3.png',100000,10,1,725.00),(24,23,'Fuel Filter Spanner KS TOOLS',5,'800.00','0.00','40.00','760.00','frontImage/1602934503-24Fuel Filter Spanner KS TOOLS.jpg','mainImage/default.jpg','<p>Chrome Vanadium Steel Material</p>',NULL,'2020-11-20 11:22:32','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,600.00),(25,23,'Oil Filter Pliers VOREL',5,'800.00','0.00','40.00','860.00','frontImage/1602934520-25Oil Filter Pliers VOREL.jpg','mainImage/default.jpg','<p>Stained Matt Surface</p>',NULL,'2020-11-20 11:22:37','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,600.00),(26,23,'Oil Filter Spanner Set ENERGY',5,'750.00','0.00','35.00','715.00','frontImage/1602934472-26Fuel Filter Spanner ENERGY.jpg','mainImage/default.jpg','<p>Type -BMW, Mercedes-Benz, Daihatsu, Fiat, Ford, Honda, Isuzu, Mazda, Mitsubishi, Nissan, Porsche</p>',NULL,'2020-11-20 11:22:51','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,700.00),(27,24,'Oil Filter DENCKERMANN',5,'500.00','0.00','25.00','475.00','frontImage/1602934921-27No 1-Oil Filter DENCKERMANN.jpg','mainImage/default.jpg','<p><strong>Outer diameter [mm]:64 </strong></p><p><strong>Height [mm]:86</strong></p>',NULL,'2020-11-20 11:22:55','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,450.00),(28,24,'Oil Filter FILTRON',5,'900.00','0.00','45.00','855.00','frontImage/1602934936-28no 2-Oil Filter FILTRON.jpg','mainImage/default.jpg','<p><strong>Outer diameter [mm]:</strong><strong>71</strong></p><p><strong>Height [mm]:</strong> <strong>87</strong></p>',NULL,'2020-11-20 11:23:06','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,720.00),(29,24,'Oil Filter ASHIKA',5,'1000.00','0.00','50.00','950.00','frontImage/1602934953-29no 3- Oil Filter ASHIKA.jpg','mainImage/default.jpg','<p><strong>Outer diameter [mm]:</strong><strong>71,5</strong></p><p><strong>Height [mm]:</strong><strong>87</strong></p>',NULL,'2020-11-20 11:23:18','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,830.00),(31,25,'Air Horn AMiO',5,'1250.00','0.00','50.00','1200.00','frontImage/1602935290-31No 2- Air Horn AMiO.jpg','mainImage/default.jpg','<p><strong>Diameter [mm]:</strong><strong>90</strong></p><p><strong>Rated Voltage [V]:</strong><strong>12</strong></p><p><strong>Type: </strong><strong>CHA-02</strong></p>',NULL,'2020-11-20 11:23:32','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,1150.00),(32,25,'Air Horn AMiO',5,'1350.00','0.00','50.00','1300.00','frontImage/1602935279-32no 1- Air Horn AMiO.jpg','mainImage/default.jpg','<p><strong>Rated Voltage [V]:12</strong></p><p><strong>Frequency Range [Hz]:410, 510</strong></p>',NULL,'2020-11-20 11:23:39','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,1250.00),(37,27,'Air Horn HICO',5,'850.00','0.00','50.00','800.00','frontImage/1602936016-37No 1- Air Horn HICO.jpg','mainImage/default.jpg','<p><strong>Rated Voltage [V]:12</strong></p><p><strong>Condition: New</strong></p>',NULL,'2020-11-20 11:24:07','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,800.00),(38,27,'Air Horn AUTOMEGA',5,'1000.00','0.00','50.00','950.00','frontImage/1602936004-38No 2- Air Horn AUTOMEGA.jpg','mainImage/default.jpg','<p><strong>Condition: </strong><strong>New</strong></p>',NULL,'2020-11-20 11:24:16','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,928.00),(39,27,'Air Horn TOPRAN',5,'725.00','0.00','50.00','675.00','frontImage/1602936042-39No 3- Air Horn TOPRAN.jpg','mainImage/default.jpg','<p><strong>Signal',NULL,'2020-11-20 11:24:30','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,720.00),(41,26,'BOSCH Micro Fan Fare Set',5,'1000.00','0.00','50.00','950.00','frontImage/1602936898-41NO 01-BOSCH-Micro-Fan-Fare-Set-12V.jpg','mainImage/default.jpg','<p>',NULL,'2020-11-20 11:24:34','2021-03-13',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,830.00),(42,26,'BOSCH Horn Set ',5,'1000.00','0.00','50.00','950.00','frontImage/1602936919-42NO 2- BOSCH-Horn-12V.jpg','mainImage/default.jpg','<p>12V 350/450 Hz (Copy) (DV0986320191)</p>',NULL,'2020-11-20 11:24:45','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,955.00),(43,26,'BOSCH Horn Set ',5,'1000.00','0.00','50.00','950.00','frontImage/1602936929-43NO 3-bosh-12v-300.jpg','mainImage/default.jpg','<p>12V 350/450 Hz (Copy) (DV0986320191)</p>',NULL,'2020-11-20 11:24:53','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,800.00),(44,26,'BOSCH Horn Set Large ',5,'950.00','0.00','50.00','900.00','frontImage/1602936943-44NO 4 -BOSCH-Horn-Set-24V-1.jpg','mainImage/default.jpg','<p>12V 300/375 Hz (Silver 115db) (DVF002H50911)</p>',NULL,'2020-11-20 11:25:05','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,900.00),(46,26,'BOSCH Horn Set ',5,'1000.00','0.00','50.00','950.00','frontImage/1602937029-46NO 01-BOSCH-Micro-Fan-Fare-Set-12V.jpg','mainImage/default.jpg','<p>24V (DVF002H50941)</p>',NULL,'2020-11-20 11:25:08','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,900.00),(47,26,'BOSCH Red Horn Set',5,'850.00','0.00','50.00','800.00','frontImage/1602936963-47NO 05-Red-Horns.jpg','mainImage/default.jpg','<p>12V 2.5A 360/410 Hz (105-115db-89mm) (DVF002H10188)</p>',NULL,'2020-11-20 11:25:15','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,800.00),(48,30,' Brake Hose A.B.S.',5,'1000.00','0.00','50.00','950.00','frontImage/1603178167-48No 2- Brake Hose A.B.S..jpg','mainImage/default.jpg','<p>Front Axle, Left, Right</p>',NULL,'2020-11-20 11:25:24','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,900.00),(49,30,'Brake Hose A.B.S.',5,'1000.00','0.00','50.00','950.00','frontImage/1603178153-49no 1 - Brake Hose A.B.S..jpg','mainImage/default.jpg','<p>Rear Axle, Left, Right</p>',NULL,'2020-11-23 00:09:40','2021-05-15',149,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,900.00),(50,31,'Brake Pad Set, disc brake MASTER-SPORT',5,'950.00','0.00','50.00','900.00','frontImage/1603178353-50No 1- Brake Pad Set, disc brake MASTER-SPORT.jpg','mainImage/default.jpg','<p>Rear Axle, prepared for wear indicator, excl. wear warning contact</p>',NULL,'2020-11-20 11:25:29','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,900.00),(51,31,'Brake Pad Set, disc brake A.B.S.',5,'850.00','0.00','50.00','800.00','frontImage/1603178463-51no 2- Brake Pad Set, disc brake A.B.S..jpg','mainImage/default.jpg','<p>Rear Axle, prepared for wear indicator</p>',NULL,'2020-11-20 11:29:21','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,720.00),(52,31,'Brake Pad Set, disc brake STARK',5,'950.00','0.00','50.00','900.00','frontImage/1603178739-52no 3-Brake Pad Set, disc brake STARK_.jpg','mainImage/default.jpg','<p>Rear Axle, prepared for wear indicator</p>',NULL,'2020-11-20 11:26:01','2021-03-20',100,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,820.00),(53,33,'SHELL Helix, HX7 DIESEL',5,'750.00','0.00','50.00','700.00','frontImage/1603179229-53NO 1- Engine Oil SHELL Helix, HX7 DIESEL.jpg','mainImage/default.jpg','<p><strong>0W-40, Capacity: 1l, Part Synthetic Oil</strong></p>',NULL,'2020-11-20 11:26:07','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,710.00),(54,33,'SPECOL Spec, Premium C3',5,'1000.00','0.00','50.00','950.00','frontImage/1603179242-54no 2- Engine Oil SPECOL Spec, Premium C3.jpg','mainImage/default.jpg','<p><strong>5W-40, Capacity: 1l</strong></p>',NULL,'2020-11-20 11:26:25','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,975.00),(55,33,'Valvoline MaxLife',5,'1000.00','0.00','50.00','950.00','frontImage/1603179327-55No 3- Engine Oil Valvoline MaxLife.jpg','mainImage/default.jpg','<p>10W-40, Capacity: 1l, Part Synthetic Oil</p>',NULL,'2020-11-20 11:26:28','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,985.00),(56,34,'Water Pump HEPU',5,'1500.00','0.00','250.00','1250.00','frontImage/1603179845-56no 2 - Water Pump HEPU.jpg','mainImage/default.jpg','<p><strong>Operating Mode: </strong><strong>Electric</strong></p>',NULL,'2020-11-20 11:26:41','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,1350.00),(57,34,'Water Pump HEPU',5,'1500.00','0.00','250.00','1250.00','frontImage/1603179664-57no 3- Water Pump TOPRAN.jpg','mainImage/default.jpg','<p><strong>Operating Mode: </strong><strong>Electric</strong></p>',NULL,'2020-11-20 11:26:43','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,1000.00),(58,34,'Water Pump TOPRAN',5,'950.00','0.00','50.00','900.00','frontImage/1603179653-58no 1- Water Pump HEPU.jpg','mainImage/default.jpg','<p>with v-ribbed belt pulley, with housing',NULL,'2020-11-20 11:26:52','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,900.00),(59,35,' Clutch RIDEX',5,'1000.00','0.00','50.00','950.00','frontImage/1603180089-59No 1- - Central Slave Cylinder, clutch RIDEX.jpg','mainImage/default.jpg','<p><strong>Transmission Type: NSG270</strong></p><p><strong>Bore ',NULL,'2020-11-20 11:27:18','2021-03-20',150,1,'products/def1.png','products/def2.png','products/def3.png',100000,10,1,820.00),(64,17,'Profit Calculate',5,'3000.00',NULL,'150.00','2850.00','frontImage/default.jpg','mainImage/default.jpg','<p>This product is for profit Calculation</p>',NULL,'2020-11-20 11:03:04','2021-11-01',500,1,'products/def1.png','products/def2.png','products/def3.png',100000,50,1,2500.00);

/*Table structure for table `region` */

DROP TABLE IF EXISTS `region`;

CREATE TABLE `region` (
  `regionId` int(11) NOT NULL AUTO_INCREMENT,
  `regionCode` varchar(10) DEFAULT NULL,
  `regionText` varchar(200) DEFAULT NULL,
  `regionStatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`regionId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `region` */

insert  into `region`(`regionId`,`regionCode`,`regionText`,`regionStatus`) values (1,'HO','Head Office',1);

/*Table structure for table `region_auth` */

DROP TABLE IF EXISTS `region_auth`;

CREATE TABLE `region_auth` (
  `region_auth_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `deport_id` varchar(5) NOT NULL,
  `user_level` int(11) NOT NULL,
  PRIMARY KEY (`region_auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=419 DEFAULT CHARSET=latin1;

/*Data for the table `region_auth` */

insert  into `region_auth`(`region_auth_id`,`user_id`,`region_id`,`deport_id`,`user_level`) values (409,412,0,'HO001',1),(2,2,1,'1',1),(410,413,0,'HO001',6),(411,414,0,'HO001',5),(412,415,0,'HO001',1),(413,416,0,'HO001',1),(414,417,0,'HO001',1),(415,418,0,'HO001',1),(416,419,0,'HO001',1),(417,420,0,'HO001',1),(418,421,0,'HO001',6);

/*Table structure for table `slide_show` */

DROP TABLE IF EXISTS `slide_show`;

CREATE TABLE `slide_show` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `slide_show` */

insert  into `slide_show`(`id`,`name`,`image`,`status`,`type`) values (1,'1','1488440559-slide_showslider1.jpg',0,''),(2,'2','slider1.jpg',0,''),(3,'3','slider2.jpg',0,''),(4,'4','slider3.jpg',0,'');

/*Table structure for table `user_details` */

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `gender` varchar(2) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_url` varchar(500) NOT NULL DEFAULT 'nouser.jpg',
  `tel_no` varchar(200) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_details` */

insert  into `user_details`(`user_id`,`first_name`,`last_name`,`gender`,`Address`,`created_time`,`image_url`,`tel_no`) values (2,'Dilhani','Senarath','F','820,Kotte','2020-08-01 23:24:41','nouser.jpg','0771245125'),(412,'Saku','Perera','M','Gampola','2020-08-01 01:00:00','nouser.jpg','0784512000'),(413,'Test 123','User ',NULL,'Rsjsgitiys II','2020-08-01 13:27:48','nouser.jpg','077776800'),(414,'test2','user',NULL,'colombo','2020-08-08 17:02:41','nouser.jpg','0775222222'),(415,'test first name','tesst last namw',NULL,'test address','2020-11-13 14:47:06','nouser.jpg','22'),(416,'test two','test',NULL,'dbfbfbf,123','2020-11-13 15:03:20','nouser.jpg','0781245824'),(417,'test three','test ',NULL,'aabd','2020-11-13 15:08:05','nouser.jpg','0781245124'),(418,'test three','test three',NULL,'test address three','2020-11-13 15:14:42','nouser.jpg','077778965236'),(419,'dayan','silva',NULL,'abc,123','2020-11-13 15:35:11','nouser.jpg','0781245214'),(420,'amara','ka',NULL,'anc','2020-11-13 15:40:20','nouser.jpg','0784512451'),(421,'Dilhani','Dil',NULL,'Battaamulla','2020-11-19 14:03:54','nouser.jpg','0777798541');

/*Table structure for table `user_level` */

DROP TABLE IF EXISTS `user_level`;

CREATE TABLE `user_level` (
  `level_id` int(11) NOT NULL,
  `level_name` varchar(100) NOT NULL,
  `avalableUserLevel` int(1) DEFAULT 0,
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_level` */

insert  into `user_level`(`level_id`,`level_name`,`avalableUserLevel`) values (1,'Super Administrator',1),(2,'Administrator',0),(3,'Regional Manager',0),(4,'Deport Officer',0),(5,'Data Entry Operator',1),(6,'Manager',1);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(11) NOT NULL,
  `autoTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=422 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`user_id`,`username`,`password`,`status`,`autoTime`) values (2,'dil','4124bc0a9335c27f086f24ba207a4912',0,'2020-08-08 16:25:55'),(412,'saku','4124bc0a9335c27f086f24ba207a4912',0,'2020-08-01 11:51:27'),(413,'test1','4124bc0a9335c27f086f24ba207a4912',0,'2020-08-01 13:50:27'),(414,'test2','4124bc0a9335c27f086f24ba207a4912',0,'2020-08-08 17:02:41'),(415,'testusername','4124bc0a9335c27f086f24ba207a4912',0,'2020-11-13 14:47:06'),(416,'user1','e99a18c428cb38d5f260853678922e03',0,'2020-11-13 15:03:20'),(417,'user2','e99a18c428cb38d5f260853678922e03',0,'2020-11-13 15:08:05'),(418,'usernamethree','1a1dc91c907325c69271ddf0c944bc72',0,'2020-11-13 15:14:42'),(419,'dayan','78f5065fa06c6f5d67e650984c1dfbba',0,'2020-11-13 15:35:11'),(420,'user5','6ad14ba9986e3615423dfca256d04e3f',0,'2020-11-13 15:40:20'),(421,'manager','e0323a9039add2978bf5b49550572c7c',0,'2020-11-19 14:03:53');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
