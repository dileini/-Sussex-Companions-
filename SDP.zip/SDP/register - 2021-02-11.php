<?php
require_once('./header.php');
?>
<style type="text/css">
<!--
.style2 {
			font-size: 16px;
			font-weight:bold;
			color: #FF0000;
		}
-->
</style>

<script>
function saveNewUser(){

		if (formcheck.checkValidation()) {

			if(document.getElementById('userlevel').value == "0")
			{
				alert("Please select a User Level");
				document.getElementById('userlevel').focus();
			}
			else if(document.getElementById('reigon').value == "0")
			{
				alert("Please select a reigon");
				document.getElementById('reigon').focus();
			}
			else if(document.getElementById('depot').value == "0")
			{
				alert("Please select a depot");
				document.getElementById('depot').focus();
			}
			else if(document.getElementById('pass').value != document.getElementById('conpass').value)
			{
				alert("Please confirm the correct password");
				document.getElementById('conpass').focus();
			}
			else if((document.getElementById('userlevel').value == 5 || 
					document.getElementById('userlevel').value == 4) && (document.getElementById('depot').value == "" 
					|| document.getElementById('depot').value == 0))
			{
				alert("Please select a Deport");
				document.getElementById('depot').focus();
			}
			else
			{
				var query = "depot="+document.getElementById('depot').value
				+"&region="+ document.getElementById('reigon').value
				+"&firstname="+document.getElementById('first_name').value
				+"&lastname="+document.getElementById('last_name').value
				+"&address="+document.getElementById('address').value
				+"&username="+document.getElementById('username').value
				+"&pass="+document.getElementById('pass').value
				+"&tel_no="+document.getElementById('tel_no').value
				+"&userlevel="+document.getElementById('userlevel').value;
				var url = 'ajax/saveUser.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						//alert(result);
						
						if(result.trim() == '01')
						{
							alert('New user added sucessfully')
							window.location.reload();
						}
						else
						{
							alert('Error Occored, Pl. try again..');
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

			}
		}
    }

function validateForm() {
  var x = document.getElementById('Fname').value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
} 

</script>




<title>register new user</title><body>
 
<div class="wrapper">
 
<?php
require_once('./menu.php');
?>
 
<section class="main-slider inner-slider">
<div class="slider">
<ul class="mslider-inner">
<li><img src="images/si1.jpg" alt="spare parts Responsive"/></li>
<li><img src="images/si2.jpg" alt="spare parts Responsive"/></li>
</ul>
</div>
<div class="main-slider-curve curve-img"></div>
</section>
 
 
<section class="contact">
<div class="container">
<div class="row">
<div class="col-lg-10 col-md-10">
<h2 class="main-title">Register or Login.</h2>
<h2>
<span class="style2"> 
<?php
if(isSet($_GET['err'])){ 
	if($_GET['err'] == '1'){
		echo 'Invalid Username or Password, Please try again';
	}
	else if($_GET['err'] == '2'){
		echo 'Registration sucesfull, Please login';
	}
	else if($_GET['err'] == '3'){
		echo 'Please login to the system to proceed..!';
	}
	else if($_GET['err'] == '4'){
		echo 'Processing cart error occcor, Plese try again.';
	}
}

?></span>

</h2>


<p class="p">By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
</div>
</div>
<div class="row">
	<div class="col-lg-4">
	<div class="contact-form">
		<form role="form" method="post" action="registerUser.php" onSubmit="return validateForm()" name="myForm"> 
		<div class="col-md-12">
		<div class="form-group">
		<div class="input-group">
		<input type="text" class="form-control" name="Fname" id="Fname" placeholder="First name" required pattern="[a-zA-Z]+"
		oninvalid="this.setCustomValidity('Enter First Name Here, Text only')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-user"></i></span> </div>
		</div>
		<div class="form-group">
		<div class="input-group">
		<input type="text" class="form-control" name="Lname" id="Lname" placeholder="Last name" required pattern="[a-zA-Z]+"
		oninvalid="this.setCustomValidity('Enter Last Name Here, Text only')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-envelope"></i></span> </div>
		</div>
		<div class="form-group">
		<div class="input-group">
		<input name="gender" type="radio" id="male" value="m" checked="CHECKED"> &nbsp;
		  <label for="male">Male</label> &nbsp; &nbsp; &nbsp;
		  <input type="radio" id="female" name="gender" value="f">
		  &nbsp;
		  <label for="female">Female</label><br>
		  </div>
		</div>
		<div class="form-group">
		<div class="input-group">
		<input type="text" class="form-control" name="Email" id="Email" placeholder="Email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
		oninvalid="this.setCustomValidity('Enter valid E-mail address')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-phone"></i></span> </div>
		</div>
		<div class="form-group">
		<div class="input-group">
		<input type="password" class="form-control" name="Password" id="Password" placeholder="Password" required pattern="[a-zA-Z]+"
		oninvalid="this.setCustomValidity('Please Enter Password..!')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
		</div>
		<div class="form-group">
		<div class="input-group">
		<input type="password" class="form-control" name="Repassword" id="Repassword" placeholder="Re-Password" required pattern="[a-zA-Z]+"
		oninvalid="this.setCustomValidity('Please Enter Re-Password..!')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
		</div>
		<div class="form-group">
		<div class="input-group">
		<input type="text" class="form-control" name="Phone" id="Phone" placeholder="Phone number 0777768425" required pattern="[0-9]{10}"
		oninvalid="this.setCustomValidity('Please Enter Valide Phone..!')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
		</div>


		<div class="form-group">
		<div class="input-group">
		<input type="text" class="form-control" name="nic" id="nic" placeholder="National ID card Number 198514001042" required pattern="[0-9]{12}"
		oninvalid="this.setCustomValidity('Please Enter Valide Nic Number..!')"
		oninput="this.setCustomValidity('')">
		<span class="input-group-addon"><i class="fa fa-pencil"></i></span> </div>
		</div>



		<div class="form-group">
		<div class="input-group textarea">
		  <textarea name="Address" id="Address" class="form-control" placeholder="Address" rows="2" required></textarea>
		</div>

		<div class="form-group" style="padding-top:25px;">
		<input type="submit" name="submit" id="submit" value="Create an account" class="btn btn-info pull-down">
		</div>
		</div>

		</div>

	</form>
	</div>
</div>

<!-- 2020-09-25 -->
<div class="col-md-4">
<form name="myform" method="post" action="login.php">
<div class="form-group">
<div class="input-group">
<input type="text" class="form-control" name="uname" id="uname" placeholder="Username : E-mail address" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
		oninvalid="this.setCustomValidity('Enter valid E-mail address')"
		oninput="this.setCustomValidity('')">
<span class="input-group-addon"><i class="fa fa-envelope"></i></span> </div>
</div>

<div class="form-group">
<div class="input-group">
<input type="password" class="form-control" name="passwd" id="passwd" placeholder="Password" required>
<span class="input-group-addon"><i class="fa fa-envelope"></i></span> </div>
</div>


<div class="form-group" style="padding-top:25px;">
<input type="submit" name="submit" id="submit" value="Login" class="btn btn-info pull-down">
</form>

</div>
</div>





<div class="col-md-4">
<address>
<ul>
<li>
<p class="first">Here's how you can reach us.</p>
</li>
<li class="add">
<p>No:09820, Battaramulla.</p>
</li>
<li class="tell">
<p> T : 0112853853</p>
</li>
<li class="skype">
<p>Fax: 0112862545</p>
</li>
<li class="email">
<p><a href="mailto:info@lankaAutomotive.com">info@lankaAutomotive.com</a></p>
</li>
</ul>
</address>
</div>
</div>
</div>
</section>
 

<?php
require_once('./footer.php');
?>


</div>
 
</body>

</html>
