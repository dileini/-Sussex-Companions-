<?php
require_once('./header.php');
?>

<body>
 
<div class="wrapper">
 
<?php
require_once('./menu.php');
?> 
 
<section class="main-slider inner-slider">
<div class="slider">
<ul class="mslider-inner">
<li><img src="images/si1.jpg" alt="Fashion Responsive"/></li>
<li><img src="images/si2.jpg" alt="Fashion Responsive"/></li>
<li><img src="images/si3.jpg" alt="Fashion Responsive"/></li>
</ul>
</div>
<div class="main-slider-curve curve-img"></div>
</section>
 
 
<section class="team-page gallery team">
<div class="container">
<div class="row">
<div class="col-lg-12">
<h2 class="main-title">Team</h2>
</div>
</div>
<div class="row">
<div class="team-exp1">
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img1.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Sarra Doe</a></h3>
<strong>CEO</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
<li>
<div class="tsocial">
<ul>
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="fa fa-youtube"></i></a></li>
</ul>
</div>
</li>
</ul>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img2.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Chris Doe</a></h3>
<strong>Fashion Designer</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
<li>
<div class="tsocial">
<ul>
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="fa fa-youtube"></i></a></li>
</ul>
</div>
</li>
</ul>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img3.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Angie</a></h3>
<strong>Marketing</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
<li>
<div class="tsocial">
<ul>
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="fa fa-youtube"></i></a></li>
</ul>
</div>
</li>
</ul>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img4.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span><a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fa fa-search"></i></a> </span> <span><a href="#"><i class="fa fa-link"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Zeb Doe</a></h3>
<strong>Programmer</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
<li>
<div class="tsocial">
<ul>
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="fa fa-youtube"></i></a></li>
</ul>
</div>
</li>
</ul>
</div>
</div>
</div>
<div class="row">
<div class="team-exp1 team-exp2">
<div class="col-lg-12">
<h2 class="main-title">Team Option</h2>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img1.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span> <a href="#"><i class="fa fa-facebook"></i></a> </span> <span> <a href="#"><i class="fa fa-twitter"></i></a> </span> <span> <a href="#"><i class="fa fa-linkedin"></i></a> </span> <span> <a href="#"><i class="fa fa-google-plus"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Sarra Doe</a></h3>
<strong>CEO</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
</ul>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img2.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span> <a href="#"><i class="fa fa-facebook"></i></a> </span> <span> <a href="#"><i class="fa fa-twitter"></i></a> </span> <span> <a href="#"><i class="fa fa-linkedin"></i></a> </span> <span> <a href="#"><i class="fa fa-google-plus"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Chris Doe</a></h3>
<strong>Fashion Designer</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
</ul>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img3.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span> <a href="#"><i class="fa fa-facebook"></i></a> </span> <span> <a href="#"><i class="fa fa-twitter"></i></a> </span> <span> <a href="#"><i class="fa fa-linkedin"></i></a> </span> <span> <a href="#"><i class="fa fa-google-plus"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Angie</a></h3>
<strong>Marketing</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
</ul>
</div>
<div class="col-lg-3 col-sm-3">
<ul class="team-w">
<li>
<div class="pro-holder2"> <img src="images/team-img4.png" alt=""/>
<div class="pro-overlay"></div>
<div class="pro-icon"> <span> <a href="#"><i class="fa fa-facebook"></i></a> </span> <span> <a href="#"><i class="fa fa-twitter"></i></a> </span> <span> <a href="#"><i class="fa fa-linkedin"></i></a> </span> <span> <a href="#"><i class="fa fa-google-plus"></i></a> </span> </div>
</div>
</li>
<li>
<h3><a href="#">Zeb Doe</a></h3>
<strong>Programmer</strong>
<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. </p>
</li>
<li class="prograss-sec">
<label>Wordpress</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
<label>Design</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
</div>
<label>Management</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
</div>
<label>PhotoShop</label>
<div class="progress">
<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
</div>
</li>
</ul>
</div>
</div>
</div>
</div>
</section>
 


<?php
require_once('./footer.php');
?>


</div>
 
</body>

</html>
