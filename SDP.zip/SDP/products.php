<?php
require_once('./header.php');
?>

<style type="text/css">
<!--
.style2 {font-style: italic}
-->
</style>
<body>
 
<div class="wrapper">
 
<?php
require_once('./menu.php');
?>
 
<section class="main-slider inner-slider">
<div class="slider">
<ul class="mslider-inner">
<li><img src="images/si1.jpg" alt="Fashion Responsive"/></li>
<li><img src="images/si2.jpg" alt="Fashion Responsive"/></li>
<li><img src="images/si3.jpg" alt="Fashion Responsive"/></li>
</ul>
</div>
<div class="main-slider-curve curve-img"> </div>
</section>
 

<section class="new-collection">
<div class="container">
<div class="row">

		<div class="col-lg-12 stitle">
		<h2 align="left">Products Grid View</h2>
		</div>


<div id="main-container">
<div id="content">

<?php
function seoUrl($string) 
{
    //Lower case everything
    $string = strtolower($string);
    //Make alphanumeric (removes all other characters)
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    //Clean up multiple dashes or whitespaces
    $string = preg_replace("/[\s-]+/", " ", $string);
    //Convert whitespaces and underscore to dash
    $string = preg_replace("/[\s_]/", "-", $string);
    return $string;
}


$selectProducts = "SELECT `productID`,
						`catoID`,
						`productTitle`,
						`offPresent`,
						`originalPrice`,
						`discountAmnt`,
						`saveAmt`,
						`newAmnt`,
						`homepageImage`,
						`adMainImage`,
						`productDesc`,
						`itemOrder`,
						`productAddDate`,
						`productEndDate`,
						`availableProductsQTY`,
						`productEnableDesable`,
						`image1`,
						`image2`,
						`image3`,
						`catoCode`,
						`catoText`
						FROM `products`
						LEFT JOIN `jobcats` 
						ON `products`.`catoID`=`jobcats`.`id`
						WHERE `productEnableDesable`=1 
						ORDER BY soteF, `productID` DESC";

$selectProductsRes = mysql_query($selectProducts);

if(mysql_num_rows($selectProductsRes)!=0)
{
	while($myProdutc = mysql_fetch_array($selectProductsRes))
	{
		$productID 			  = $myProdutc['productID'];
		$catoID 			  = $myProdutc['catoID'];
		$productTitle 		  = $myProdutc['productTitle'];
		$offPresent 		  = $myProdutc['offPresent'];
		$originalPrice		  = $myProdutc['originalPrice'];
		$discountAmnt		  = $myProdutc['discountAmnt'];
		$saveAmt 			  = $myProdutc['saveAmt'];
		$newAmnt 			  = $myProdutc['newAmnt'];
		$homepageImage		  = $myProdutc['homepageImage'];
		$adMainImage 		  = $myProdutc['adMainImage'];
		$productDesc 		  = $myProdutc['productDesc'];
		$itemOrder 			  = $myProdutc['itemOrder'];
		$productAddDate 	  = $myProdutc['productAddDate'];
		$productEndDate		  = $myProdutc['productEndDate'];
		$availableProductsQTY = $myProdutc['availableProductsQTY'];
		$productEnableDesable = $myProdutc['productEnableDesable'];
		$image1               = $myProdutc['image1'];
		$image2               = $myProdutc['image2'];
		$image3 			  = $myProdutc['image3'];
		$catoCode			  = $myProdutc['catoCode'];
		$catoText			  = $myProdutc['catoText'];
		
		
		?>
		
		
		
<div class="col-lg-3 col-sm-4">		
		
<div class="deal_store round">
					

					<div class="pro-holder">
					<div class="deal-image">
					<a target="_blank" href="deal/<?php echo $productID;?>/<?php echo seoUrl($productTitle);?>">
					
					<img src="images/<?php echo $homepageImage;?>" alt="<?php echo $productTitle;?>" width="100%" style="border-radius:10px;box-shadow:0px 1px 2px rgba(0,0,0,0.3);"/></a>
					</div>
					
			
			<div class="">
			<!--<div class="pro-content">-->
			
					<div class="title_store" style="height:28px;"><center>
					<h4 class="pro-title" style="color:#000066; width:100%;">
					 
					  <?php echo $productTitle;?>  
					  <!--<span style="color:#F00"><?php echo $offPresent;?>%</span> OFF! &nbsp;&nbsp;-->
					  </h4></center>
					</div>

			<!--	<div class="pro-footer">
					<div class="deal-row" style="margin-bottom:5px; width:100%;">
						<div class="grid_original"><span style="color:#000">Original Price </span> <br/> <strong><span style="color:#000">Rs. <?php echo $originalPrice;?></span></strong></div>
						<div class="grid_dc"><span style="color:#000">Discount</span> <br/> <strong><span style="color:#000"><?php echo $offPresent;?>%</span></strong> </div>
						<div class="grid_save"><span style="color:#000">You Save </span><br/> <strong><span style="color:#000">Rs. </span><span style="color:#F00"><?php echo $saveAmt;?></span></strong></div>
					</div>-->
					
		
					<!--<div class="price_store" style="width:100%">-->
					<center><h4><span style="color:#00f">Rs.</span><span style="color:#F00"><?php echo $newAmnt;?></span></h4>
					<h5> <a target="_blank" href="deal/<?php echo $productID;?>/<?php echo seoUrl($productTitle);?>">(more info..)</a></h5></center>
				<!--	</div>
				</div>	-->		
				
				<!--<div class="pro-footer">
					<div class="deal-row" style="margin-bottom:5px; width:100%;">
						<div class="grid_original"><span style="color:#000">Original Price </span> <br/> <strong><span style="color:#000">Rs. <?php echo $originalPrice;?></span></strong></div>
						<div class="grid_dc"><span style="color:#000">Discount</span> <br/> <strong><span style="color:#000"><?php echo $offPresent;?>%</span></strong> </div>
						<div class="grid_save"><span style="color:#000">You Save </span><br/> <strong><span style="color:#000">Rs. </span><span style="color:#F00"><?php echo $saveAmt;?></span></strong></div>
					</div>
					
		
					<div class="price_store" style="width:100%">
					<h4 style="margin-left:15px;"><span style="color:#00f">Now Only Rs.</span><span style="color:#F00"><?php echo $newAmnt;?></span></h4 >
					</div>
				</div>			-->
				
				
			</div>
			</div>
			
</div>

</div>


<?php
		
	}
}

else
{
	echo('No Records Found, Please try again..!');
}


?>

</div><!--/content-->


<p style="clear:both;"></p>
</div><!--/main-container-->




</div>
</div>
</section>



<?php
require_once('./footer.php');
?>


</div>
 
</body>

</html>
