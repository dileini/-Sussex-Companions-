<?php
session_start();
require_once('dealsManager/db_connector.php');

//Select product details
$productID = $_GET['id'];
$view_count = 0;
$selectProducts = "SELECT `productID`,
						`catoID`,
						`productTitle`,
						`offPresent`,
						`originalPrice`,
						`discountAmnt`,
						`saveAmt`,
						`newAmnt`,
						`homepageImage`,
						`adMainImage`,
						`productDesc`,
						`itemOrder`,
						`productAddDate`,
						`productEndDate`,
						`availableProductsQTY`,
						`productEnableDesable`,
						`image1`,
						`image2`,
						`image3`,
						`catoCode`,
						`catoText`,
						`view_count`
						FROM `products`
						LEFT JOIN `jobcats` 
						ON `products`.`catoID`=`jobcats`.`id`
						WHERE `productEnableDesable`=1  and productID=$productID
						ORDER BY `productID` DESC";

$selectProductsRes = mysql_query($selectProducts);

if(mysql_num_rows($selectProductsRes)!=0)
{
	while($myProdutc = mysql_fetch_array($selectProductsRes))
	{
		$productID 			  = $myProdutc['productID'];
		$catoID 			  = $myProdutc['catoID'];
		$productTitle 		  = $myProdutc['productTitle'];
		$offPresent 		  = $myProdutc['offPresent'];
		$originalPrice		  = $myProdutc['originalPrice'];
		$discountAmnt		  = $myProdutc['discountAmnt'];
		$saveAmt 			  = $myProdutc['saveAmt'];
		$newAmnt 			  = $myProdutc['newAmnt'];
		$homepageImage		  = $myProdutc['homepageImage'];
		$adMainImage 		  = $myProdutc['adMainImage'];
		$productDesc 		  = $myProdutc['productDesc'];
		$itemOrder 			  = $myProdutc['itemOrder'];
		$productAddDate 	  = $myProdutc['productAddDate'];
		$productEndDate		  = $myProdutc['productEndDate'];
		$availableProductsQTY = $myProdutc['availableProductsQTY'];
		$productEnableDesable = $myProdutc['productEnableDesable'];
		$image1               = $myProdutc['image1'];
		$image2               = $myProdutc['image2'];
		$image3 			  = $myProdutc['image3'];
		$catoCode			  = $myProdutc['catoCode'];
		$catoText			  = $myProdutc['catoText'];
		$view_count			  = $myProdutc['view_count'];
	}
}

//calculate product ratings
$ratingQuery = "SELECT SUM(`product_rating`)/COUNT(*) AS rate
				FROM `product_rating` WHERE `product_id`=$productID";
$ratingRes = mysql_fetch_row(mysql_query($ratingQuery));
//format the rating
$formatedRating = number_format($ratingRes[0], 2);

//select the comments
$commentQuery = "SELECT `comment`, `person_name` FROM `product_comment` WHERE `producct_id`=$productID AND `status`=1"; 
$commentQrest = mysql_query($commentQuery);

$updateViewCount = "UPDATE `products` SET `view_count`= ". ++$view_count. " WHERE `productID`=$productID";
$restView = mysql_query($updateViewCount);

if(isSet($_POST['rating'])){
	$rating    = $_POST['rating'];
	$insertPro = "INSERT INTO `product_rating`(`product_id`, `product_rating`) VALUES($productID, $rating)";
	mysql_query($insertPro);
	echo"<script> alert('Rating sucessfully saved')</script>";
}

if(isSet($_POST['myName']) && isSet($_POST['comment'])){
	$myName = $_POST['myName'];
	$myComm = $_POST['comment'];
	$insertComment = "insert into `product_comment`(`producct_id`, `comment`, `person_name`) values($productID,'$myComm','$myName')";
	mysql_query($insertComment);
	echo"<script> alert('Comment sucessfully saved')</script>";
	
}

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>


<head>

<title>MTC Products More Info</title>

<link rel="shortcut icon" href="./images/f.ico"/>
<link rel="stylesheet" type="text/css" href="css/firstlook.css"/>

<link href="./css/style.css" rel="stylesheet">
<link href="./css/color.css" rel="stylesheet">
<link href="./css/bootstrap.css" rel="stylesheet">
<link href="./css/font-awesome.min.css" rel="stylesheet">
<link href="./css/jquery.bxslider.css" rel="stylesheet">



<body>

<section class="header">
<div class="nav-wrap">
<div class="container">
<div class="row">
<div class="inner-container">
<div class="col-lg-12">
<div class="head-nav">
<div role="navigation" class="navbar navbar-inverse">
<div class="navbar-header">
<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"> <span class=""></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
<a class="navbar-brand" href="index.php"><img src="./images/logo.png" alt="Manawasinghe Trade Center"></a> </div>
<div class="collapse navbar-collapse">
<nav id="nav">
<ul>
		<li class="active"><a href="../../index.php">Home</a></li>
		
		<li><a href="../../contactus.php">Contact Us</a></li>
		</ul>
</nav>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<div class="container text-center" style="padding-top:100px;">  
		
			
				<div class="row">
						<div class="col-sm-12" style="background-color:#FFFFFF;">
						<div class="col-sm-4">
						<div class="well2">
						
						<script data-cfasync="false" src="./js/jquery-1.11.0.min.js"></script>
						<script data-cfasync="false" src="./js/jquery-migrate-1.2.1.min.js"></script>
						 <strong></strong>
						<script type="text/javascript" src="./js/dealpage_postload_bundle.js"></script>
						<script type="text/javascript">
						$(function() {
							$('.jtimeLeft').dealCountdown(1,'day','days');
						});
						</script>
						<script type="text/javascript">
						var imgs = new Array();
						imgs[0] = "./images/<?php echo $image1;?>";
						imgs[1] = "./images/<?php echo $image2;?>";
						imgs[2] = "./images/<?php echo $image3;?>";
						var cnt = imgs.length;
								
								$(function() {
									setInterval(Slider,3000);
								});
								
								function Slider() {
								$("#imageSlide").fadeOut("slow", function() {
								   $(this).attr("src", imgs[(imgs.length++) % cnt]).fadeIn("slow");
								});
								}
						</script>
						
					
									<a><img src="./images/<?php echo $homepageImage;?>" alt="<?php echo $productTitle;?>"  width="100%" name="imageSlide" id="imageSlide"/></a>

								
						</div>
						</div>
						
									
						<div class="col-sm-4" >
						<div class="well2" align="left">
						
									
									<h1><?php echo $productTitle;?></h1>
									<h3> <span style="color:#F00; font-size:30px;"><?php echo $offPresent;?>%</span> OFF ! </h3><br />
									
									<h2><span style="color:#000">Rs.</span><span style="color:#F00"> <?php echo number_format($newAmnt);?></span></h2><br />
									
							        <table width="100%" border="1">
                                      <tr>
                                        <td> <div class="original"><span style="color:#000">Orginal Price</span> <br/> <strong>Rs. <span style="color:#000"><?php echo $originalPrice;?></span></strong></div></td>
                                        <td><div class="dc"><span style="color:#000">Discount</span> <br/> <strong><span style="color:#000"><?php echo $offPresent;?>%</span></strong> </div></td>
                                        <td><div class="save"><span style="color:#000">You Save</span> <br/> <strong>Rs. <span style="color:#F00"><?php echo $saveAmt;?></span></strong></div></td>
                                      </tr>
                                    </table>
					        <p><br />
							
                              <span style="color:#000; font-weight:bolder; font-size:12px"> <?php echo $productDesc;?> </span>

                              <span style="color:#000; font-weight:bolder; font-size:12px">Product Rating: </span>&nbsp;&nbsp;<?php echo $formatedRating; ?>/5<br/> 

                              <span style="color:#000; font-weight:bolder; font-size:12px">Product Comments:</span><br/> 
  <b>
  <span style="color:#000; font-weight:normal; font-size:12px">
  <?php
  if(mysql_num_rows($commentQrest) != 0){
	  while($com = mysql_fetch_array($commentQrest)){
		  echo $com['person_name'] . ' Says, '. $com['comment'] . '<br />';
	  }
  }
  
  
  ?>
  
  </span></p>
  
  
  
  
  
  
					        <form id="form1" name="form1" method="post" action="">
					          <p>
					            <label>
					              <input type="radio" name="rating" value="1" id="rating_0" />
					              1</label>
					            
					            <label>
					              <input type="radio" name="rating" value="2" id="rating_1" />
					              2</label>
					            
					            <label>
					              <input type="radio" name="rating" value="3" id="rating_2" />
					              3</label>
					            
					            <label>
					              <input type="radio" name="rating" value="4" id="rating_3" />
					              4</label>
					            
					            <label>
					              <input name="rating" type="radio" id="rating_4" value="5" checked="checked" />
					              5</label>
					            
				                <input type="submit" name="Rate Product" id="Rate Product" value="Rate Product" />
					            <br />
					          </p>
					          <label for="rate"></label>
			              </form>
 <form action="" method="post" name="form2">
 Your name : <input name="myName" type="text" />
 <br/>
 Comment: &nbsp;&nbsp;&nbsp;<input name="comment" type="text" /><input type="submit" name="Rate Product" id="Rate Product" value="Comment on this" />
 
 </form>
					        <p><br/> 
					          <b><br>
				          </p>
						</div>
   
                        
						</div>
						
						<div class="col-sm-4">
						<div class="well2"><a><a><img src="./images/<?php echo $image1;?>" alt="<?php echo $productTitle;?>" width="100%" name="imageSlide" id="imageSlide2"/></a></a></div>
						</div>
						</div>
				</div>
				
</div>			

	
		


</body>
</html>