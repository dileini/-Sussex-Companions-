<footer>
<section class="footer-one">
  <div class="container">
    <div class="row">
      <div class="inner-container">
        <div class="col-lg-4 col-sm-4">
          <div class="footerbox" style="text-align: justify; text-justify: inter-word;">
            <h3>Career</h3>
            <strong class="sub-head">Position: Web marketing manager</strong>
            <p> The Web Marketing Manager will develop and implement the company web-based marketing strategy to promote the company brand, attract visitors and potential leads, and generate internet sales. <br />
              <br />
              <strong>Education and Experience: </strong><br />
              <br />
              - Bachelors degree in Marketing, Business, or related field required Communications,<br />
              <br />
              - One to three years of related experience preferred <br/>
              <br/>
              <a href="images/Career.pdf" target="_blank">more</a></p>
            <strong>Send your CV to:</strong><br>
            <a href="#">info@lankaautomotive.com</a></div>
        </div>
        <div class="col-lg-4 col-sm-4"> <a href="www.manawasinghetradecenter.com" class="blogbtn">Visit Our Blog</a> </div>
        <div class="col-lg-4 col-sm-4">
          <div class="footerbox">
            <h3>Testimonials</h3>
            <ul class="testim-slider">
              <li> <strong class="author-name">Samantha Jayawickrama<br>
                <p>All motor spare parts genuine spare parts under one roof </p>
                <strong class="author-name">Rahal Cads<br>
              </li>
              <li>
                <p>Genuine part with great quality. Friendly customer service. Highly recommend for motor spare parts. </p>
                <strong class="author-name">Lahiru Biyagama<br>
                <p>Good place to buy classic vehicle spare parts with reasonable price </p>
              </li>
              <li> <strong class="author-name">Samantha Jayawickrama<br>
                <p>All motor spare parts genuine spare parts under one roof </p>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="footer-two">
<div class="container">
<div class="row">
  <div class="inner-container">
    <div class="col-lg-4 col-sm-4">
      <div class="footerbox">
        <h4>Get in Touch <span>Say Hello!</span> </h4>
        <form role="form">
          <div class="form-group">
            <input type="text" class="form-control" placeholder="Enter Name" required>
          </div>
          <div class="form-group">
            <input type="email" class="form-control" placeholder="Enter Email" required>
          </div>
          <div class="form-group">
            <textarea name="text" class="form-control" rows="4" placeholder="Message" required></textarea>
          </div>
          <button type="submit" class="btn btn-default">send it</button>
        </form>
      </div>
    </div>
    <div class="col-lg-4 col-sm-4">
      <div class="footerbox">
        <h4>Our Location <span>No:820, Battaramulla.</span> </h4>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.8908555686153!2d79.9193999147204!3d6.903653795011608!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae25755b7d12075%3A0x93888d329001ce2e!2sSinger%20Showroom%20Battaramulla!5e0!3m2!1sen!2slk!4v1594460100952!5m2!1sen!2slk" width="600" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
    </div>
  </div>
  <div class="footer-curve"></div>
  </section>
  <section class="footer-three">
  <div class="container">
    <div class="row">
      <div class="col-lg-8">
        <div class="footer-box">
          <h4>Contact Us</h4>
          <ul>
            <li><i class="fa fa-location-arrow"></i>820, Battaramulla</li>
            <li><i class="fa fa-phone"></i> T : 0112853853</li>
            <li><i class="fa fa-envelope"></i> www.lankaAutomotive.com</li>
          </ul>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="footer-social"> <strong>Stay Contected</strong>
          <ul>
            <li><a href="#"> <i class="fa fa-facebook"></i> </a></li>
            <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
            <li><a href="#"> <i class="fa fa-linkedin"></i> </a></li>
            <li><a href="#"> <i class="fa fa-google-plus"></i> </a></li>
            <li><a href="#"> <i class="fa fa-skype"></i> </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
<section class="footer-four">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">Copyright &copy; 2020 All rights reserved by Lanka Auto motive spare parts </div>
      <div class="col-lg-6"> </div>
    </div>
  </div>
</section>
</footer>
