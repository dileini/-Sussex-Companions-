<?php
session_start();
require_once('./header.php');
require_once("dbcontroller.php");
$db_handle    = new DBController();
$newProductID = "";
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM products WHERE productID='" . $_GET["code"] . "'");
			$newProductID  = 'x'.$productByCode[0]["productID"];
			$itemArray     = array($newProductID=>array('name'=>$productByCode[0]["productTitle"], 
																	 'code'=>$productByCode[0]["productID"], 
																	 'quantity'=>$_POST["quantity"], 
																	 'price'=>$productByCode[0]["newAmnt"], 
																	 'image'=>'images/'.$productByCode[0]["homepageImage"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($newProductID,array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($newProductID == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					var_dump($v);
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]); 
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}

//new cart

if(isSet($_GET['job']) && isSet($_GET['searchme'])){
	$query   = "SELECT * FROM products where `productID` <> 0 AND `availableProductsQTY` > 0 ";
	$catos   = "";
	$itemTex = "";
	if($_GET['job'] != '0'){
		$query = $query . " and `catoID` = " .$_GET['job'];
	}
	if($_GET['searchme'] != ''){
		$query = $query . " and `productTitle` LIKE '%". $_GET['searchme'] ."%' ";
	}
	//echo $query;
	$product_array = $db_handle->runQuery($query);
}
else{
	$product_array = $db_handle->runQuery("SELECT * FROM products ORDER BY productID");
}

//Generate category list box
$listQuery = "SELECT `id`, `catoText` FROM `jobcats`";
$listQueryR = mysql_query($listQuery);
$headofList = "";
$middleList = "<option value='0' selected>Any</option>";
$tailList = "</select>";
while($litstRow = mysql_fetch_array($listQueryR)){
	$middleList = $middleList. "<option value='".$litstRow['id']."'>".$litstRow['catoText']."</option>";
}
$headofList = "<select name='job' id='job' style='width:180px;'>";
	

?>

<title>Lanka Automotive Motor Spare Parts  Store</title>
<style type="text/css">
<!--
.style1 {color: #F00}
-->
</style><body>
<div class="wrapper">
  <?php
require_once('./menu.php');
?>
  <section class="main-slider">
      <div class="slider">
      <ul class="mslider">
		<li><img src="images/slider2.jpg"/></li>
        <li><img src="images/slider3.jpg"/></li>
      </ul>
    </div>
    <div class="main-slider-curve curve-img"></div>
  </section>
  <section class="welcome-section">
    <div class="container">
      <div class="row">
        
		<div id="shopping-cart">
<div class="txt-heading">Shopping Cart</div>

<a id="btnEmpty" href="list.php?action=empty">Empty Cart</a>

<?php 
if(isset($_SESSION["cart_item"])){
?>
	<a id="btnEmpty" href="processCart.php">Proceed to Check Out</a>
<?php
}

?>

<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	
<table cellpadding="10" cellspacing="1" class="blueTable" border="1">
<thead>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Code</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
<th style="text-align:center;" width="5%">Remove</th>
</tr>
</thead>	
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
			
				<tr>
				<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ". number_format($item_price,2); ?></td>
				<td style="text-align:center;"><a href="list.php?action=remove&code=<?php echo 'x'.$item["code"]; ?>" class="btnRemoveAction"><img src="images/icon-delete.png" alt="Remove Item" /></a></td>
				</tr>
			
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>
<tfoot>
<tr>
<td colspan="2" align="right"  style="line-height:26px;">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tfoot>
</table>		
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty Now</div>
<?php 
}
?>
</div>
		
		
      </div>
    </div>
  </section>
  <section class="pro-slider">
    <div class="pro-bx-slider">
      <div class="pro-slider-wrap" >
        <ul class="pbxslider gallery" align="center"> </ul>
      </div>
    </div>
  </section>
  <section class="new-collection">
    <div class="container">
      <div class="row">
        <div class="inner-container">
          <div class="col-lg-12 stitle">
            <h2 align="left">Our Products</h2>
          </div>
          <div id="main-container">
            <div id="content"> </div>
            <!--/content-->
            <div style="display:none;" class="nav_up" id="nav_up">
              <div style="margin-top:3px;margin-left:2px;"> <strong></strong> </div>
            </div>
			<div>
            
            <form name="search" action="list.php" method="get">
            
             Select Catgory
			<?php echo $headofList. $middleList . $tailList;?>
			Item Name <input type="text" name="searchme" id="searchme" width="250">
			<input type="submit" value="Search Product" class="btnAddAction" />
			</form>
			</div>
            <script language="Javascript" type="text/javascript">
$(function() {
    var $elem = $('#content');

    $('#nav_up').fadeIn('slow');

    $(window).bind('scrollstop', function() {
        $('#nav_up,#nav_down').stop().animate({'opacity': '0.4'});
    });

    $('#nav_up').click(
        function(e) {
            $('html, body').animate({scrollTop: '0px'}, 600);
        }
    );
});
</script>
            <p style="clear:both;"></p>
          </div>
          <!--/main-container-->
          
<?php


//new cart

if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
	<form method="post" action="list.php?action=add&code=<?php echo $product_array[$key]["productID"]; ?>">
		<div class="col-lg-4 col-sm-4">
            <div class="deal_store round">
              <div class="pro-holder">
                <div class="deal-image">
                  <div class="sale-tag">New</div>
                  <img src="images/<?php echo $product_array[$key]["homepageImage"]; ?>" alt="productggg" width="100%" style="border-radius:10px;box-shadow:0px 1px 2px rgba(0,0,0,0.3);"/></a> </div>
                <div class="pro-content">
                  <div class="title_store">
                    <h4 class="pro-title" style="color:#000066; margin-left:7px;"> <?php echo $product_array[$key]["productTitle"]; ?> <span> <a target="_blank" href="moreInfo.php?id=<?php echo $product_array[$key]["productID"] ?>">(more info..)</a></span> <span style="color:#F00">5%</span> OFF! &nbsp;&nbsp; </h4>
                  </div>
                  <div class="pro-footer">
                    <div class="deal-row" style="margin-bottom:5px; width:100%;">
                      <div class="grid_original"><span style="color:#000">Original Price </span> <br/>
                        <strong><span style="color:#000">Rs. <?php echo $product_array[$key]["originalPrice"]; ?></span></strong></div>
                      <div class="grid_dc"><span style="color:#000">Discount</span> <br/>
                        <strong><span style="color:#000"><?php echo $product_array[$key]["discountAmnt"]; ?></span></strong> </div>
                      <div class="grid_save"><span style="color:#000">You Save </span><br/>
                        <strong><span style="color:#000">Rs. </span><span class="style1"><?php echo $product_array[$key]["saveAmt"]; ?></span></strong></div>
                    </div>
                    <div class="price_store" style="width:100%">
                      <h4 style="margin-left:15px;"><span style="color:#00f">Now Only Rs.</span><span class="style1"><?php echo $product_array[$key]["newAmnt"]; ?></span></h4 >
                    </div>
					<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input type="submit" value="Add to Cart" class="btnAddAction" /></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
	</form>	
		
		
		
		
	<?php
		}
	}
	
	else{
		echo 'no records found';
	}

?>	   
        </div>
      </div>
    </div>
  </section>
  <?php
require_once('./footer.php');
?>
</div>
</body>
</html>