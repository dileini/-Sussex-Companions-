/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 10.1.28-MariaDB : Database - spd
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`spd` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `spd`;

/*Table structure for table `assign_event` */

DROP TABLE IF EXISTS `assign_event`;

CREATE TABLE `assign_event` (
  `assign_event_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `assign_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`assign_event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `assign_event` */

insert  into `assign_event`(`assign_event_id`,`client_id`,`event_id`,`assign_date`) values (1,1,1,'2021-02-18 20:57:59'),(2,2,1,'2021-02-18 20:58:51'),(3,1,3,'2021-02-21 10:04:57'),(4,1,2,'2021-02-21 10:42:33'),(7,5,2,'2021-02-25 12:12:13'),(8,5,6,'2021-02-25 12:14:01'),(9,5,3,'2021-02-25 12:14:01'),(10,1,1,'2021-03-17 22:27:14'),(11,1,3,'2021-03-17 22:27:14'),(12,1,2,'2021-03-17 22:28:10');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `address` text,
  `nic` varchar(12) DEFAULT NULL,
  `hobie` int(11) DEFAULT NULL,
  `interest` int(11) DEFAULT NULL,
  `register_by` varchar(10) DEFAULT NULL,
  `location` varchar(10) DEFAULT NULL,
  `cus_image` varchar(200) DEFAULT 'default.png',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`id`,`firstName`,`lastName`,`gender`,`email`,`password`,`phone`,`address`,`nic`,`hobie`,`interest`,`register_by`,`location`,`cus_image`) values (1,'Dilmin','Perera','f','m@j.com','4124bc0a9335c27f086f24ba207a4912','0777768415','Ragama','12563',1,1,'','1','/1614064665-1dilmin.jpg'),(2,'Mahin','Jay','m','m@j1.com','4124bc0a9335c27f086f24ba207a4912','0777768414','addrss','8414',1,2,'admin','1','/1614067731-2mahi.jpg'),(3,'Mahinda','Jayasundara','m','a@b.com','21ad0bd836b90d08f4cf640b4c298e7c','0777768456','addres','456',5,3,'admin','2','/1614067785-3bandara.jpg'),(4,'Chamila','Nishan','m','chami@gmail.com','4124bc0a9335c27f086f24ba207a4912','0777768456','Battaramulla','19991410042',1,2,'admin','1','/1614067841-4chamila.jpeg'),(5,'Vipula','Saparamadu','m','vipu@gmail.com','4124bc0a9335c27f086f24ba207a4912','0777798425','Ragama','19991410042',2,1,'admin','1','/1614067904-5vipula.jpg'),(6,'Inoka','Tennekoon','f','inoka@gmail.com','4124bc0a9335c27f086f24ba207a4912','0778652487','Thalangama','19991410042',3,4,'admin','2','/1614067953-6inoka.jpg'),(7,'Ruvini','Samaraweera','f','ruvini@gmail.com','4124bc0a9335c27f086f24ba207a4912','0777985214','Bognor','19991410042',5,5,'admin','2','/1614068147-7ruvu.jpeg'),(8,'Sirimal','Dadallage','m','srimal@gmail.com','4124bc0a9335c27f086f24ba207a4912','0777985263','Kosawatta','19971410043',1,1,'admin','2','/1614068546-8nimal.jpg');

/*Table structure for table `depot` */

DROP TABLE IF EXISTS `depot`;

CREATE TABLE `depot` (
  `depotID` int(11) NOT NULL AUTO_INCREMENT,
  `depotCorde` varchar(100) DEFAULT NULL,
  `depotText` varchar(100) DEFAULT NULL,
  `depotPhone` varchar(100) DEFAULT NULL,
  `depotImageURL` varchar(500) DEFAULT NULL,
  `depotTotalEmp` int(11) DEFAULT NULL,
  `regionCode` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`depotID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `depot` */

insert  into `depot`(`depotID`,`depotCorde`,`depotText`,`depotPhone`,`depotImageURL`,`depotTotalEmp`,`regionCode`) values (1,'HO001','Eastbourne',NULL,NULL,0,'HO'),(2,'HO002','Bognor Regis',NULL,NULL,0,'HO');

/*Table structure for table `event` */

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_title` varchar(200) DEFAULT NULL,
  `event_cost` double(12,2) DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `event_time` varchar(20) DEFAULT NULL,
  `event_added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `event_per_head_cost` double(10,2) DEFAULT NULL,
  `event_pic` varchar(200) DEFAULT 'default.jpg',
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `event` */

insert  into `event`(`event_id`,`event_title`,`event_cost`,`event_date`,`event_time`,`event_added_date`,`event_per_head_cost`,`event_pic`) values (1,'Chase and Status DJ set',500000.00,'2021-03-05','15.30','2021-03-17 21:35:54',5000.00,'/1614072888-1eve6.jpg'),(2,'The Brickworks',100000.00,'2021-02-28','15:30','2021-02-23 15:03:06',2000.00,'/1614072786-2eve5.jpg'),(3,'We Are Saying It With Flowers',500000.00,'2021-02-28','14:45','2021-02-23 15:02:02',3000.00,'/1614072722-3event4.jpg'),(4,'Japan Tours Festival',500000.00,'2021-02-28','16:30','2021-02-23 15:00:52',2500.00,'/1614072652-4ev3.jpg'),(5,'Tomorrowland Winter',25000.00,'2021-03-25','00:00','2021-03-17 21:36:01',3000.00,'/1614072584-5ev2.jpg'),(6,'Grapevine Gathering Spills Lineup',3000000.00,'2021-03-31','00:00','2021-02-23 14:57:02',5000.00,'/1614072422-6ev1.jpg');

/*Table structure for table `hobbie` */

DROP TABLE IF EXISTS `hobbie`;

CREATE TABLE `hobbie` (
  `hid` int(11) NOT NULL AUTO_INCREMENT,
  `h_text` varchar(100) DEFAULT NULL,
  `h_code` varchar(10) DEFAULT NULL,
  `addDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `hobbie` */

insert  into `hobbie`(`hid`,`h_text`,`h_code`,`addDate`,`status`) values (1,'DIY','DIY','2021-02-12 13:03:46',1),(2,'Watch Online Documentaries','WOD','2021-02-12 13:03:53',1),(3,'Gardening','GAR','2021-02-12 13:03:58',1),(4,'Go Camping','GCA','2021-02-12 13:04:11',1),(5,'Yoga','YOG','2021-02-12 13:04:04',1),(6,'Writing','WRI','2021-02-11 13:23:09',0);

/*Table structure for table `interest` */

DROP TABLE IF EXISTS `interest`;

CREATE TABLE `interest` (
  `iid` int(11) NOT NULL AUTO_INCREMENT,
  `i_text` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `interest` */

insert  into `interest`(`iid`,`i_text`) values (1,'Photography'),(2,'Travel'),(3,'Writing or blogging'),(4,'Travel'),(5,'Foreign languages');

/*Table structure for table `membership_payment` */

DROP TABLE IF EXISTS `membership_payment`;

CREATE TABLE `membership_payment` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `payed_amount` double(10,2) DEFAULT NULL,
  `payment_yeat` int(11) DEFAULT NULL,
  `payment_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `membership_payment` */

insert  into `membership_payment`(`mid`,`member_id`,`payed_amount`,`payment_yeat`,`payment_date`) values (1,1,200.00,2021,'2021-03-15 13:46:59'),(2,2,200.00,2021,'2021-03-15 13:52:21'),(3,3,200.00,2021,'2021-03-15 13:53:02'),(4,1,200.00,2022,'2021-03-15 13:53:35'),(5,4,200.00,2021,'2021-03-15 13:54:26');

/*Table structure for table `office_location` */

DROP TABLE IF EXISTS `office_location`;

CREATE TABLE `office_location` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `l_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `office_location` */

insert  into `office_location`(`lid`,`l_text`) values (1,'Eastbourne'),(2,'Bognor Regis');

/*Table structure for table `order_head` */

DROP TABLE IF EXISTS `order_head`;

CREATE TABLE `order_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `address` text,
  `nic` varchar(12) DEFAULT NULL,
  `ordere_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `product_cost` decimal(12,2) DEFAULT NULL,
  `shipping` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(12,2) DEFAULT NULL,
  `pay_method` varchar(20) DEFAULT NULL,
  `current_status` varchar(50) DEFAULT 'pending',
  `odr_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

/*Data for the table `order_head` */

insert  into `order_head`(`id`,`user_id`,`firstName`,`lastName`,`email`,`phone`,`address`,`nic`,`ordere_date`,`product_cost`,`shipping`,`total_price`,`pay_method`,`current_status`,`odr_date`) values (18,5,'Vipula','Saparamadu','vipu@gmail.com','0777798425','Ragama','19991410042','2021-02-25 12:12:13','2000.00','0.00','2300.00','cod','pending','2021-02-25'),(19,5,'Vipula','Saparamadu','vipu@gmail.com','0777798425','Ragama','19991410042','2021-02-25 12:14:01','8000.00','0.00','8300.00','online','pending','2021-02-25'),(20,1,'Dilmin','Perera','m@j.com','0777768415','Ragama','12563','2021-03-17 22:27:14','16000.00','0.00','16300.00','online','pending','2021-03-17'),(21,1,'Dilmin','Perera','m@j.com','0777768415','Ragama','12563','2021-03-17 22:28:10','2000.00','0.00','2300.00','cod','pending','2021-03-17');

/*Table structure for table `order_items` */

DROP TABLE IF EXISTS `order_items`;

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `head_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `total_price` double(10,2) DEFAULT NULL,
  `unit_price` double(10,2) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `item_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

/*Data for the table `order_items` */

insert  into `order_items`(`id`,`user_id`,`head_id`,`item_id`,`total_price`,`unit_price`,`qty`,`order_date`,`item_name`) values (11,2,11,51,4000.00,800.00,5,'2020-11-16 11:08:19','Brake Pad Set, disc brake A.B.S.'),(23,5,18,2,2000.00,2000.00,1,'2021-02-25 12:12:13','The Brickworks'),(24,5,19,6,5000.00,5000.00,1,'2021-02-25 12:14:01','Grapevine Gathering Spills Lineup'),(25,5,19,3,3000.00,3000.00,1,'2021-02-25 12:14:01','We Are Saying It With Flowers'),(26,1,20,1,10000.00,5000.00,2,'2021-03-17 22:27:14','Chase and Status DJ set'),(27,1,20,3,6000.00,3000.00,2,'2021-03-17 22:27:14','We Are Saying It With Flowers'),(28,1,21,2,2000.00,2000.00,1,'2021-03-17 22:28:10','The Brickworks');

/*Table structure for table `order_status` */

DROP TABLE IF EXISTS `order_status`;

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_test` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `order_status` */

insert  into `order_status`(`id`,`status_test`) values (1,'Pending'),(2,'Shiped'),(3,'Completed'),(4,'Cancel');

/*Table structure for table `region` */

DROP TABLE IF EXISTS `region`;

CREATE TABLE `region` (
  `regionId` int(11) NOT NULL AUTO_INCREMENT,
  `regionCode` varchar(10) DEFAULT NULL,
  `regionText` varchar(200) DEFAULT NULL,
  `regionStatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`regionId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `region` */

insert  into `region`(`regionId`,`regionCode`,`regionText`,`regionStatus`) values (1,'HO','Head Office',1);

/*Table structure for table `region_auth` */

DROP TABLE IF EXISTS `region_auth`;

CREATE TABLE `region_auth` (
  `region_auth_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `deport_id` varchar(5) NOT NULL,
  `user_level` int(11) NOT NULL,
  PRIMARY KEY (`region_auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=419 DEFAULT CHARSET=latin1;

/*Data for the table `region_auth` */

insert  into `region_auth`(`region_auth_id`,`user_id`,`region_id`,`deport_id`,`user_level`) values (2,2,1,'HO001',1),(410,412,1,'HO001',2),(411,413,1,'HO001',3),(412,414,1,'HO001',4),(413,415,1,'HO001',5),(414,417,1,'HO001',1),(415,418,1,'HO001',1),(416,419,1,'HO001',1),(417,420,1,'HO001',1),(418,421,1,'HO001',6);

/*Table structure for table `user_details` */

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `gender` varchar(2) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image_url` varchar(500) NOT NULL DEFAULT 'nouser.jpg',
  `tel_no` varchar(200) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_details` */

insert  into `user_details`(`user_id`,`first_name`,`last_name`,`gender`,`Address`,`created_time`,`image_url`,`tel_no`) values (2,'Dilhani','Senarath','F','820,Kotte','2020-08-01 23:24:41','nouser.jpg','0771245125'),(412,'Saku','Perera','M','Gampola','2020-08-01 01:00:00','nouser.jpg','0784512000'),(413,'Test 123','User ',NULL,'Rsjsgitiys II','2020-08-01 13:27:48','nouser.jpg','077776800'),(414,'test2','user',NULL,'colombo','2020-08-08 17:02:41','nouser.jpg','0775222222'),(415,'test first name','tesst last namw',NULL,'test address','2020-11-13 14:47:06','nouser.jpg','22'),(416,'test two','test',NULL,'dbfbfbf,123','2020-11-13 15:03:20','nouser.jpg','0781245824'),(417,'test three','test ',NULL,'aabd','2020-11-13 15:08:05','nouser.jpg','0781245124'),(418,'test three','test three',NULL,'test address three','2020-11-13 15:14:42','nouser.jpg','077778965236'),(419,'dayan','silva',NULL,'abc,123','2020-11-13 15:35:11','nouser.jpg','0781245214'),(420,'amara','ka',NULL,'anc','2020-11-13 15:40:20','nouser.jpg','0784512451'),(421,'Dilhani','Dil',NULL,'Battaamulla','2020-11-19 14:03:54','nouser.jpg','0777798541');

/*Table structure for table `user_level` */

DROP TABLE IF EXISTS `user_level`;

CREATE TABLE `user_level` (
  `level_id` int(11) NOT NULL,
  `level_name` varchar(100) NOT NULL,
  `avalableUserLevel` int(1) DEFAULT '0',
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_level` */

insert  into `user_level`(`level_id`,`level_name`,`avalableUserLevel`) values (1,'Receptionist ',1),(2,'Client Service Agent',2),(3,'Senior Client Service Agent',3),(4,'Finance Manager',4),(5,'All',5);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(11) NOT NULL,
  `autoTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=416 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`user_id`,`username`,`password`,`status`,`autoTime`) values (2,'rep','4124bc0a9335c27f086f24ba207a4912',0,'2021-02-12 11:31:35'),(412,'csa','4124bc0a9335c27f086f24ba207a4912',0,'2021-03-16 13:55:38'),(413,'scsa','4124bc0a9335c27f086f24ba207a4912',0,'2021-03-16 14:05:06'),(414,'fam','4124bc0a9335c27f086f24ba207a4912',0,'2021-03-16 14:15:54'),(415,'all','4124bc0a9335c27f086f24ba207a4912',0,'2021-03-16 14:17:42');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
