<?php
require_once('dealsManager/db_connector.php');
?>

<!doctype html>
<html lang="en" dir="ltr" class="no-js">


<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="images/f.ico">
<title>Sussex Companions</title>
<link href="css/style.css" rel="stylesheet">
<link href="css/color.css" rel="stylesheet">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/jquery.bxslider.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="css/firstlook.css"/>
<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->


<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
tr.border_bottom td {
  border-bottom:1pt solid black;
}
</style>


<script src="js/jquery-1.11.1.min.js"></script> 
<script src="js/jquery-migrate-1.2.1.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.bxslider.min.js"></script> 
<script src="js/jquery.prettyPhoto.js"></script> 
<script src="js/custom.js"></script> 
<script type="text/javascript" src="dealsManager/js/autocomplete.js"> </script>
<script src="dealsManager/js/mootools.js"         type="text/javascript"></script>
<script src="dealsManager/js/mootools-more.js"    type="text/javascript"></script>
<script src="dealsManager/js/JobsHome/combo.js"          type="text/javascript"></script>
<script src="dealsManager/js/JobsHome/core_functions.js" type="text/javascript"></script>


<script type="text/javascript">
    var formcheck;
    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{
												display : {
													showErrors:1,	
													closeTipsButton : 0,
													keepFocusOnError : 1,
													flashTips : 1
												},
												alerts : {
													required : 'This feield is required..!'
												}
											   });
		load_catos();
    });
	
</script>
<script>

function loadJobs(id)
 {
 	var query = "catoText="+id;
	var url = 'dealsManager/ajax/loadJobsUser.php';

	var req = new Request({method: 'POST',
		data:query,
		url: url,
		onSuccess: function(result){
			hideImgContent('waitingDiv');
			//alert(result);
			
			if(result =='1')
			{
				alert('No recores found')
				//window.location.reload();
			}
			else
			{
				//alert('Category sucess fully added..')
				//window.location.reload();
				$('content').innerHTML = result;
			}
			
		}});
	showImgContent('waitingDiv');
	req.send();
 }
 
 </script>

<script>

function loadPage(pageName)
{
	window.open(pageName,'Print','left=20,top=20,width=720,height=400,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	
}

</script>

<script type="text/javascript">
 
	function print_invoice(id)
	{
		//var num =document.getElementById('invoice_no').value;
    	//var query = "AucId="+document.getElementById('invoice_no').value;
    	//var query = "jobID="+id;
		var query = id;
    	doc_print(query);
    }
    function doc_print(query)
	{
		/*
		window.open('singleJob.php?' +query,'Print','left=20,top=20,width=1200,height=700,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	*/
		
		window.open('dealNumber/' +query,'Print','left=20,top=20,width=1200,height=700,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	
		
	}
	
	function loadPage(pageName)
	{
		window.open(pageName,'Print','left=20,top=20,width=720,height=400,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	
	}
	
	
</script>

</head>
