<?php
session_start();
include("sessionCK.php");
include("templates/header.php");

// Check user logged in or not

?>
<div>
<div class="right" style="float:left;clear:both;width:120px;"><?php add_module('menu'); ?></div>
<div class="content" style="padding-left:80px;margin-left: 130px;">
	<div class="left"> <?php add_module('dashboard'); ?></div>
</div>
</div>
<?php
include("templates/footer.php");
?>
