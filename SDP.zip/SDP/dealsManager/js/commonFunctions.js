/**
 * this files contains all the functions that can be consudered as common
 * 
 * created by thilina 2011- 08- 16
 */

String.prototype.capitalizeFirst = function() {
	return this.replace(/(^|\s)([a-z])/g, function(m, p1, p2) {
		return p1 + p2.toUpperCase();
	});
};

String.prototype.capFirst = function() {
    return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
};
// this function is used to check the data
function dateCheck(dateString)
{
	var splitValues = dateString.split("/");
	
	var x=new Date();
	x.setFullYear(splitValues[2],splitValues[1]-1,splitValues[0]);
	var today = new Date();

	if(today < x)
	{
		return true;
	}
	else
	{
		return false;
	}	
}

function capitalize(elem)
{
	var elementValue = elem.value;
	if(elementValue != "")
	{
		elementValue = elementValue.toUpperCase();
		elem.value = elementValue;
	}
}

function capWords(elem)
{
	var elementValue = elem.value;
	if(elementValue != "")
	{		
		elem.value = elementValue.capFirst();
	}	
}

function checkNumaric(elemName)
{
	var redigit=/\d/g; //regular expression defining char with a 6 digit number
	if (document.getElementById(elemName).value.test(redigit)){ 
		//if match failed	
		return true;
	}
	return false;
}

