
//this function is used for hiding the loading img
// @param elem html div element
function hideImgContent(elem) {

	var divElement = document.getElementById(elem);
	divElement.style.display = "none";
}

//this function is used for viewing the loading img
//@param elem html div element
function showImgContent(elem) {
	var divElement = document.getElementById(elem);
	divElement.style.display = "inline";
}

