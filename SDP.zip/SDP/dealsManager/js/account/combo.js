// JavaScript Document

function load_combo_data(url, ele, text, value, query) {

	document.getElementById(ele).innerHTML = "";
	var req = new Request({
		method : 'GET',
		data : query,
		url : url,
		onSuccess : function(result) 
		{
			var jObj = result.split('</option>');

			var elem1 = document.createElement("option");
			elem1.value = "0";
			elem1.innerHTML = "Any";
			document.getElementById(ele).appendChild(elem1);

			
			for ( var i = 0; i < jObj.length; i++) 
			{
				if(!! (jObj[i].split('value="')[1]))
				{
					var optionID   = jObj[i].split('>')[1];
					var optionText = jObj[i].split('value="')[1].split('\">')[0];
					var elem = document.createElement("option");
					elem.value = optionText;
					elem.innerHTML = optionID;
					document.getElementById(ele).appendChild(elem);
				}
				
			}
			
			document.getElementById(ele).appendChild(elem);

		}
	});
	req.send();
}


function load_combo_data2(url, ele, text, value, query) {

	document.getElementById(ele).innerHTML = "";
	var req = new Request({
		method : 'GET',
		data : query,
		url : url,
		onSuccess : function(result) 
		{
			var jObj = result.split('</option>');

			var elem1 = document.createElement("option");
			elem1.value = "0";
			elem1.innerHTML = "Select Opetion";
			document.getElementById(ele).appendChild(elem1);

			
			for ( var i = 0; i < jObj.length; i++) 
			{
				if(!! (jObj[i].split('value="')[1]))
				{
					var optionID   = jObj[i].split('>')[1];
					var optionText = jObj[i].split('value="')[1].split('\">')[0];
					var elem = document.createElement("option");
					elem.value = optionText;
					elem.innerHTML = optionID;
					document.getElementById(ele).appendChild(elem);
				}
				
			}
			
			document.getElementById(ele).appendChild(elem);

		}
	});
	req.send();
}



function load_region() {
	load_combo_data('ajax/depots.php', 'depot', 'depot_txt', 'depot_id','id=' + document.getElementById('reigon').value);
}
function load_userLevel() {
	load_combo_data('ajax/userLevel.php', 'userlevel', 'level_name','level_id', '');
}
function load_hobbies() {
	load_combo_data2('ajax/hobbies.php', 'hb', 'h_text','hid', '');
}
function load_interrests() {
	load_combo_data2('ajax/inter.php', 'inter', 'i_text','iid', '');
}
function load_locations() {
	load_combo_data2('ajax/locations.php', 'loc', 'depotText','depotID', '');
}

function load_clients() {
	load_combo_data2('ajax/clients.php', 'client', 'firstName','id', '');
}

function load_events() {
	load_combo_data2('ajax/events.php', 'event', 'event_title','event_id', '');
}

function load_hobbies2() {
	load_combo_data('ajax/hobbies.php', 'hb', 'h_text','hid', '');
}
function load_interrests2() {
	load_combo_data('ajax/inter.php', 'inter', 'i_text','iid', '');
}
function load_locations2() {
	load_combo_data('ajax/locations.php', 'loc', 'depotText','depotID', '');
}






















