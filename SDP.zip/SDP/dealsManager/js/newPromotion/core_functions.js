/**
 * this document contains all the core functions need for the form
 * 
 * created by kriska 2011-12-01
 */

function divContent(elem) {

	toggle(elem);
	
	var ele = document.getElementById(elem);
	
	if (ele.style.display == "inline") 
	{
		document.getElementById('advSch').value = '1';
	} 
	
	else 
	{
		document.getElementById('advSch').value = '0';
	}
}

//this function is used for hiding the loading img
// @param elem html div element
function hideImgContent(elem) {

	var divElement = document.getElementById(elem);
	divElement.style.display = "none";
}

//this function is used for viewing the loading img
//@param elem html div element
function showImgContent(elem) {
	var divElement = document.getElementById(elem);
	divElement.style.display = "inline";
}

//this function is used for showing and hiding the div content
//@param elem html div element
function toggle(elem) {
	var ele = document.getElementById(elem);
	
	
	if (ele.style.display == "inline")
	{
		ele.style.display = "none";
	} 
	else 
	{
		ele.style.display = "inline";
	}
	
}