function printContent(idReportHeder,idReportContent,page)
{
var defPage='left=100px,top=100px,width=595px,height=842px';
var pageSize='';
switch(page)
{
	case 'A4':
	       pageSize='left=100px,top=100px,width=1200px,height=842px';
	       
	 break;
	case 'A3':
	        pageSize='left=20px,top=15px,width=842px,height=1191px';
	 break;
	case 'Fanfold':
	      pageSize=defPage;
	 break;
	default:
	   pageSize=defPage;
	   break;
	
}

var reportHeader=document.getElementById(idReportHeder).innerHTML;
var reportContent=document.getElementById(idReportContent).innerHTML;

//resultReport(str);
newwin=window.open('MyPDF.pdf','printwin', pageSize);
newwin.document.write('<HTML>\n <HEAD>\n');
newwin.document.write('<TITLE>\n');
newwin.document.write('</TITLE>\n');
newwin.document.write('<script>\n');
newwin.document.write('function chkstate(){\n');
newwin.document.write('if(document.readyState=="complete"){\n');
newwin.document.write('window.close()\n');
newwin.document.write('}\n');
newwin.document.write('else{\n');
newwin.document.write('setTimeout("chkstate()",2000)\n');
newwin.document.write('}\n');
newwin.document.write('}\n');
newwin.document.write('function print_win(){\n');
newwin.document.write('window.print();\n');
newwin.document.write('chkstate();\n');
newwin.document.write('}\n');
newwin.document.write('<\/script>\n');
newwin.document.write('</HEAD>\n');
newwin.document.write('<BODY style="width:auto; background-color:#ffffff; padding-left:0px; padding-top:0px;padding-bottom:0px;" align="center" >\n');

newwin.document.write('<table border="0" cellpadding="0" cellspacing="0"  hspace="0" vspace="0" align="center" >\n');
	newwin.document.write('<thead>\n');
	newwin.document.write('<tr><td>\n');
	newwin.document.write(reportHeader);
	newwin.document.write('</td></tr>\n');
	newwin.document.write('</thead>\n');
	newwin.document.write('<tbody>\n');
	newwin.document.write('<tr><td>\n');
	newwin.document.write(reportContent);
	newwin.document.write('</td></tr>\n');
	newwin.document.write('</tbody>\n');
	newwin.document.write('<tfoot>\n');
	newwin.document.write('</tfoot>\n');
	newwin.document.write('</table>\n');

newwin.document.write('</BODY>\n');
newwin.document.write('</HTML>\n');
newwin.document.close();

}



function printContentE(idReportContent,page)
{
	
var defPage='left=10px,top=10px,width=700px,height=340px';
var pageSize='';
switch(page)
{
	case 'A4':
	       pageSize='left=100px,top=100px,width=595px,height=842px';
	       
	 break;
	case 'A3':
	        pageSize='left=20px,top=15px,width=842px,height=1191px';
	 break;
	case 'Envilop':
	      pageSize=defPage;
	 break;
	default:
	   pageSize=defPage;
	   break;
	
}

//var reportHeader=document.getElementById(idReportHeder).innerHTML;
var reportContent=document.getElementById(idReportContent).innerHTML;

//resultReport(str);
newwin=window.open('MyPDF.pdf','printwin', pageSize);
newwin.document.write('<HTML>\n <HEAD>\n');
newwin.document.write('<TITLE>\n');
newwin.document.write('</TITLE>\n');
newwin.document.write('<script>\n');
newwin.document.write('function chkstate(){\n');
newwin.document.write('if(document.readyState=="complete"){\n');
newwin.document.write('window.close()\n');
newwin.document.write('}\n');
newwin.document.write('else{\n');
newwin.document.write('setTimeout("chkstate()",2000)\n');
newwin.document.write('}\n');
newwin.document.write('}\n');
newwin.document.write('function print_win(){\n');
newwin.document.write('window.print();\n');
newwin.document.write('chkstate();\n');
newwin.document.write('}\n');
newwin.document.write('<\/script>\n');
newwin.document.write('</HEAD>\n');
newwin.document.write('<BODY style="width:auto; background-color:#ffffff; padding-left:0px; padding-top:0px;padding-bottom:0px;" align="center" >\n');

	newwin.document.write(reportContent);
	
newwin.document.write('</BODY>\n');
newwin.document.write('</HTML>\n');
newwin.document.close();

}

