// JavaScript Document

function load_combo_data(url, ele, text, value, query) {

	document.getElementById(ele).innerHTML = "";
	var req = new Request({
		method : 'GET',
		data : query,
		url : url,
		onSuccess : function(result) 
		{
			var jObj = result.split('</option>');

			var elem1 = document.createElement("option");
			elem1.value = "0";
			elem1.innerHTML = "-select-";
			document.getElementById(ele).appendChild(elem1);

			
			for ( var i = 0; i < jObj.length; i++) 
			{
				if(!! (jObj[i].split('value="')[1]))
				{
					var optionID   = jObj[i].split('>')[1];
					var optionText = jObj[i].split('value="')[1].split('\">')[0];
					var elem = document.createElement("option");
					elem.value = optionText;
					elem.innerHTML = optionID;
					document.getElementById(ele).appendChild(elem);
				}
				
			}
			
			document.getElementById(ele).appendChild(elem);

		}
	});
	req.send();
}


function load_depot() {
	load_combo_data('ajax/depots.php', 'depot', 'depot_txt', 'depot_id','id=' + document.getElementById('reigon').value);
	
}

function load_fname() {
	load_combo_data('ajax/name.php', 'fname', 'fname_txt', 'fname_id','id=' + document.getElementById('epf').value);
	
}

function load_g1fname() {
	load_combo_data('ajax/name.php', 'g1fname', 'g1fname_txt', 'g1fname_id','id=' + document.getElementById('g1epf').value);
	
}

function load_g2fname() {
	load_combo_data('ajax/name.php', 'g2fname', 'g2fname_txt', 'g2fname_id','id=' + document.getElementById('g2epf').value);
	
}

