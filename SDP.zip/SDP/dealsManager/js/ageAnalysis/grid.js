// JavaScript Document

var rows = 0;
var selectedRow = 0;
var pcolid =0;
var prowid =0;
var arr = new Array();
var json;
var rowSelected = false;



function save(){
	var head = "";
	arr = new Array();
	if(formcheck.checkValidation()){
		var ele = document.getElementById("grid_content");
		$$('input').each(function(el){
			if(el.className == "gridField"){
				var expl = el.id.split("_");
				if(arr[expl[1]] == null)
					arr[expl[1]] = new Array();
					var bcol = expl[0].split("col");
					arr[expl[1]][bcol[1]] = el.value;
			}else if(el.name!=""){
				head += "\""+el.name+"\":\""+el.value+"\",";
				
			}
		});
	
	
		$$('select').each(function(el){
			if(el.className == "gridFieldCombo"){
				var expl = el.id.split("_");
				if(arr[expl[1]] == null)
					arr[expl[1]] = new Array();
					var bcol = expl[0].split("col");
					arr[expl[1]][bcol[1]] = el.value;
			}else if(el.name!=""){
				head += "\""+el.name+"\":\""+el.value+"\",";
				
			}
		});
			
		head = head.substr(0,head.length-1);
		var str = "headdata={"+head+"}&itemdata="+JSON.encode(arr);
		var myRequest = new Request({method: 'post',data:str, url: '/stock/action/save_dispatch_note.php',onSuccess: function(person){
			alert("Saved");
		}});
		myRequest.send();

	}

}



	function focus_next(event,el){
		
		if(event.keyCode==13)
		document.getElementById(el).focus();
	
	}
	
	

function resetRow(){
	if(document.getElementById("col1_"+selectedRow)!=null){
		for(var i=1;i<9;i++){
			document.getElementById("col"+i+"_"+selectedRow).parentNode.style.backgroundColor = "#fff"
		}
	}

	if (document.getElementById("colHead_"+selectedRow)!= null)
		document.getElementById("colHead_"+selectedRow).className = "gridRowHandle";	
	if (document.getElementById("dishead"+pcolid)!= null)
		document.getElementById("dishead"+pcolid).className = "gridHeadCol";
	if (document.getElementById("colHead_"+prowid)!= null)
		document.getElementById("colHead_"+prowid).className = "gridRowHandle";	
		
		selectedRow = null;
		rowSelected = false;
		
}


function markRow(el){

	resetRow();
	expl = el.id.split("_");
	var rowid = expl[1];
	for(var i=1;i<9;i++){
		document.getElementById("col"+i+"_"+rowid).parentNode.style.backgroundColor = "#ffe38d"
	}
	
	if (document.getElementById("colHead_"+rowid)!= null)
		document.getElementById("colHead_"+rowid).className = "gridRowHandleSelected";	
	
	selectedRow = rowid;
	rowSelected = true;
}



function selectAxis(el){
	var expl = el.id.split("_");
	var rowid = expl[1];
	
	expl = expl[0].split("col");
	var colid = expl[1];
	
	
	if (document.getElementById("dishead"+pcolid)!= null)
		document.getElementById("dishead"+pcolid).className = "gridHeadCol";
	if (document.getElementById("colHead_"+prowid)!= null)
		document.getElementById("colHead_"+prowid).className = "gridRowHandle";		
		
	document.getElementById("dishead"+colid).className = "gridHeadColSelected";
	document.getElementById("colHead_"+rowid).className = "gridRowHandleSelected";
	
	pcolid = colid;
	prowid = rowid;
	
}


function printRowOrder(){
		var row = 1;	
		$$('div').each(function(el){
			if(el.className == "gridRowHandle" || el.className == "gridRowHandleSelected"){
				el.innerHTML = row++;
			}
		});
			



}


function removerow(){

	
	if(rowSelected != false){
		
		if(document.getElementById("row_"+selectedRow)!= null)	{
			var el = document.getElementById("row_"+selectedRow);
			
			el.parentNode.removeChild(el);
		
		}
	}
	
	rowSelected = false;
	selectedRow = null;
	printRowOrder();
	
}


var species = new Array();
var category = new Array("Logs","Sawn","Other");
var classes = new Array();

function load_species(){

var req = new Request({method: 'GET',
									data:'', 
									url:'/stock/ajax/species.php',
									onSuccess: function(result){
										var jObj = JSON.decode(result);
										
										for(var i=0;i<jObj.length;i++){
											
											species[i] = new Array();
											species[i][0] = jObj[i]['species_id'];
											species[i][1] = jObj[i]['species_txt'];
																						
										}
										
									}});
		req.send();
		
	
	
	var req1 = new Request({method: 'GET',
									data:'', 
									url:'/stock/ajax/classes.php',
									onSuccess: function(result){
										var jObj = JSON.decode(result);
										
										for(var i=0;i<jObj.length;i++){
											
											classes[i] = new Array();
											classes[i][0] = jObj[i]['class_id'];
											classes[i][1] = jObj[i]['class_txt'];
																						
										}
										
									}});
		req1.send();
		
}




function addrow(){
	rows++;
	var container = document.getElementById("grid_content");
	
	var row = document.createElement("div");
	row.className = "gridRow";
	row.id = "row_"+rows;
	
	var colHead = document.createElement("div");
	colHead.className = "gridRowHandle";
	colHead.id = "colHead_"+rows;
	colHead.onclick = function(){ markRow(this);}
	row.appendChild(colHead);
	
	var col1 = document.createElement("div");
	col1.className = "gridCol";	
	var input1 = document.createElement("select");
	input1.id = "col1_"+rows;
	input1.className = "gridFieldCombo";
	input1.onkeydown = function(event){ focus_next(event,"col2_"+rows) };
	input1.onclick = function(){resetRow();selectAxis(this);}
	
	for(var i=0;i<category.length;i++){
		var elem = document.createElement("option");
		elem.value = category[i];
		elem.innerHTML = category[i];
		input1.appendChild(elem);
	}
		
	
	col1.appendChild(input1);
	row.appendChild(col1);
	
	
	var col2 = document.createElement("div");
	col2.className = "gridCol";	
	var input2 = document.createElement("input");
	input2.id = "col2_"+rows;
	input2.className = "gridField";	
	input2.onclick = function(){ resetRow();selectAxis(this);}
	input2.onkeydown = function(event){ focus_next(event,"col3_"+rows) };
	col2.appendChild(input2);
	row.appendChild(col2);
	
	var col3 = document.createElement("div");
	col3.className = "gridCol";	
	var input3 = document.createElement("select");
	input3.id = "col3_"+rows;
	input3.className = "gridFieldCombo";	
	input3.onkeydown = function(event){ focus_next(event,"col4_"+rows) };
	input3.onclick = function(){resetRow();selectAxis(this);}
	
	for(var i=0;i<classes.length;i++){
		var elem = document.createElement("option");
		elem.value = classes[i][0];
		elem.innerHTML = classes[i][1];
		input3.appendChild(elem);
	}
		
	
	col3.appendChild(input3);
	row.appendChild(col3);
	
	
	var col4 = document.createElement("div");
	col4.className = "gridCol";	
	var input4 = document.createElement("select");
	input4.id = "col4_"+rows;
	input4.className = "gridFieldCombo";
	input4.onkeydown = function(event){ focus_next(event,"col5_"+rows) };
	input4.onclick = function(){resetRow();selectAxis(this);}
	
	for(var i=0;i<species.length;i++){
		var elem = document.createElement("option");
		elem.value = species[i][0];
		elem.innerHTML = species[i][1];
		input4.appendChild(elem);
	}
		
	
	col4.appendChild(input4);
	row.appendChild(col4);

	
	var col5 = document.createElement("div");
	col5.className = "gridCol";	
	var input5 = document.createElement("input");
	input5.id = "col5_"+rows;
	input5.className = "gridField";	
	input5.onclick = function(){ resetRow();selectAxis(this);}
	input5.onkeydown = function(event){ focus_next(event,"col6_"+rows) };
	col5.appendChild(input5);
	row.appendChild(col5);
	
	var col6 = document.createElement("div");
	col6.className = "gridCol";	
	var input6 = document.createElement("input");
	input6.id = "col6_"+rows;
	input6.className = "gridField";	
	input6.onclick = function(){ resetRow();selectAxis(this);}
	input6.onkeydown = function(event){ focus_next(event,"col7_"+rows) };
	col6.appendChild(input6);
	row.appendChild(col6);
	
	var col7 = document.createElement("div");
	col7.className = "gridCol";	
	var input7 = document.createElement("input");
	input7.id = "col7_"+rows;
	input7.className = "gridField";	
	input7.onkeydown = function(event){ focus_next(event,"col8_"+rows) };
	input7.onclick = function(){ resetRow();selectAxis(this);}
	col7.appendChild(input7);
	row.appendChild(col7);
	
	var col8 = document.createElement("div");
	col8.className = "gridCol";	
	var input8 = document.createElement("input");
	input8.id = "col8_"+rows;
	input8.className = "gridField";	
	input8.onclick = function(){ resetRow();selectAxis(this);}
	col8.appendChild(input8);
	row.appendChild(col8);
	
	
	if(rowSelected == false)
		container.appendChild(row);
	else{
		
		if(document.getElementById("row_"+selectedRow)!= null)	{
			var el = document.getElementById("row_"+selectedRow);
			el.parentNode.insertBefore(row,el.nextSibling);
		
		}
	}
	
	printRowOrder();

}