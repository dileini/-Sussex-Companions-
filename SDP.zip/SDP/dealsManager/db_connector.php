<?php
mysql_connect("localhost", "root", "") or
	die("Cannot connect to the database !". mysql_error());
mysql_select_db("spd") or
	die("Cannot connect to the Lanka Auto Motive Spare parts store DB !");
?>
