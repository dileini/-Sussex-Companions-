<?php
//session_start();
require_once("./includes/base.php");
if ($_SESSION['logged_in']!=true)
	header('Location:index.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lanka Automotive Motor Spare Parts Store.</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script src="js/mootools.js" type="text/javascript"></script>
<script src="js/mootools-more.js" type="text/javascript"></script>
<script type="text/javascript" src="js/reportPrint/print.js"> </script>

<script type="text/JavaScript">
var i=0;
var count=0;
var limit=5;
function doBlink()
{
	i=1;
	while ( 1000 > i )
	{
		var o=document.getElementById('blink');
		o.className=(o.className.indexOf('blinking_on')!=-1)?'blinking_off':'blinking_on';
		i++;
	}

}
window.onload=function()
{
	//timer=setInterval('doBlink()',500);
}
</script>
<style type="text/css">
.blinking_on {color:#de0000;font-size:14px;font-weight:bold;}
.blinking_off {color:#0000ff;font-size:14px;font-weight:bold;opacity:0.0;}
</style>
</head>

<div class="header">
	<img src="image/logo.png" />
	
</div>

