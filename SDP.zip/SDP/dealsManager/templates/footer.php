<style type="text/css">
#footer {
	float: left;
	width: 100%;
	height: 100px;
	/*background-color: #ffffff;*/
	padding-top: 20px;
}
#footer-area {
	float: left;
	width: 100%;
	height: 90px;
	border-top-width: 1px;
	border-top-style: solid;
	border-top-color: #d3d3d0;	/*background-image: url(image/footer.gif);
	background-repeat: repeat-x;*/
}
#footer-right {
	float: left;
	width: 25%;
	height: 90px;
	background-image: url(image/fotterlog.png);
	background-repeat: no-repeat;
	background-position: right;
	
}
#footer-left {
	float: left;
	width: 70%;
	height: 90px;
	color: #000000;
	padding-left:230px;
}

</style>
<div id="footer">
    <div id="footer-area">
		
		<div id="footer-left">
		 <br />
		  <br />
		<font style="font-size:15px">@ 2021. All Rights Reserved.</font> <br />

<font style="font-size:13px">Sussex Companions 
<a href="www.LankaAutoMotive.com">SussexCompanions.com</a></font>
		</div>
		<div id="footer-right">
		
		</div>

    </div>
</div>