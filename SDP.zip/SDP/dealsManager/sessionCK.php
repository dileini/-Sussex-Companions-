<?php
$mySessionID = session_id ();
if ((! isset ( $_SESSION ['logged_in'] )) or (! isset ( $_SESSION ['username'] )) or ($_SESSION ['sessionBegi'] != $mySessionID))
{
	header ( "Location: index.php?error=4" );
	exit();
}

?>