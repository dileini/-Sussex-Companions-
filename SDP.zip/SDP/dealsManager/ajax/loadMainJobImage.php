<?php
session_start();
require_once('../db_connector.php');



// getting the data from the url
$jobmane         = mysql_real_escape_string($_POST ['jobid']);


$selectImageQ = "SELECT `adMainImage` FROM `products` WHERE `productID`='$jobmane'";
$selectImageQRes = mysql_query($selectImageQ);

if(mysql_num_rows($selectImageQRes) > 0)
{
	
	while($row = mysql_fetch_array($selectImageQRes))
	{
		
	?>
	<img src="../images/<?php echo $row['adMainImage'];?>" width="640" />
	
	<?php
	
	}
}

?>