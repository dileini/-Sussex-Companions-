<?php
session_start();
require_once('../bootstrap.php');
Doctrine_Core::loadModels('../models');
	
	$stmt = $conn->prepare("select * from classes ");
	$stmt->execute();
	$r = $stmt->fetchAll(Doctrine ::FETCH_ASSOC);

	$json = new Doctrine_Parser_Json();
	echo $json->dumpData($r);


$conn->close();
?>
