<?php
session_start();
require_once('../db_connector.php');

$myUser = $_SESSION['user_id'];
$maxUserID = "";

// getting the data from the url
$productName        = mysql_real_escape_string($_POST ['productName']);
$productDesc        = mysql_real_escape_string($_POST ['productDesc']);
$productDisCount    = mysql_real_escape_string($_POST ['productDisCount']);
$productNormalPrice = mysql_real_escape_string($_POST ['productNormalPrice']);
$productSave        = mysql_real_escape_string($_POST ['productSave']);
$productFinalPrice  = mysql_real_escape_string($_POST ['productFinalPrice']);
$toDate             = mysql_real_escape_string($_POST ['toDate']);
$productItems       = mysql_real_escape_string($_POST ['productItems']);
$job                = mysql_real_escape_string($_POST ['job']);
$proID              = mysql_real_escape_string($_POST ['proID']);
$orderNum           = mysql_real_escape_string($_POST ['orderNum']);


$timestamp = strtotime($toDate);
$myNewDate = date("Y-m-d", $timestamp);


/*
	$insertQuery = "INSERT INTO `products`(`catoID`,`productTitle`,`offPresent`,`originalPrice`,`discountAmnt`,`saveAmt`,`newAmnt`,`productDesc`,`productEndDate`,`availableProductsQTY`)
VALUES($job,'$productName', $productDisCount, $productNormalPrice, 0.00, $productSave, $productFinalPrice, '$productDesc', '$myNewDate', $productItems)";
	$insertQueryR = mysql_query($insertQuery);
*/	

$updateQuery = "UPDATE `products` SET
`catoID`=$job,
`productTitle`='$productName',
`offPresent`=$productDisCount,
`originalPrice`=$productNormalPrice,
`discountAmnt`=0.00,
`saveAmt`=$productSave,
`newAmnt`=$productFinalPrice,
`productDesc`='$productDesc',
`productEndDate`='$myNewDate',
`soteF`=$orderNum,
`availableProductsQTY`=$productItems
WHERE `productID`=$proID";

//echo($updateQuery);

mysql_query($updateQuery);

	//echo $insertQuery;
	
	if(mysql_affected_rows()!= 0)
	{
		//2 - no records added.
		echo('1');
	}
	
	else
	{
		//3 - success full..
		echo('2');
	}	

?>