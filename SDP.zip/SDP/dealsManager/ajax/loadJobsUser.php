<?php
session_start();
require_once('../db_connector.php');

function seoUrl($string) 
{
    //Lower case everything
    $string = strtolower($string);
    //Make alphanumeric (removes all other characters)
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    //Clean up multiple dashes or whitespaces
    $string = preg_replace("/[\s-]+/", " ", $string);
    //Convert whitespaces and underscore to dash
    $string = preg_replace("/[\s_]/", "-", $string);
    return $string;
}



$searchCatoType = '';

$catoText = $_POST['catoText'];

$jobsQs = "SELECT 
`productID`,
`catoID`,
`productTitle`,
`offPresent`,
`originalPrice`,
`discountAmnt`,
`saveAmt`,
`newAmnt`,
`homepageImage`,
`adMainImage`,
`productDesc`,
`itemOrder`,
`productAddDate`,
`productEndDate`,
`availableProductsQTY`,
`productEnableDesable`,
`image1`,
`image2`,
`image3`,
`catoCode`,
`catoText`
FROM `products`
LEFT JOIN `jobcats` 
ON `products`.`catoID`=`jobcats`.`id`
WHERE `productEnableDesable`=1 AND `id`=$catoText
ORDER BY soteF,`productID` DESC
			";
 
 $jobsQsRes = mysql_query($jobsQs);
 
 if(mysql_num_rows($jobsQsRes) !=0)
 {
 	while($myProdutc = mysql_fetch_array($jobsQsRes))
	{
		$productID 			  = $myProdutc['productID'];
		$catoID 			  = $myProdutc['catoID'];
		$productTitle 		  = $myProdutc['productTitle'];
		$offPresent 		  = $myProdutc['offPresent'];
		$originalPrice		  = $myProdutc['originalPrice'];
		$discountAmnt		  = $myProdutc['discountAmnt'];
		$saveAmt 			  = $myProdutc['saveAmt'];
		$newAmnt 			  = $myProdutc['newAmnt'];
		$homepageImage		  = $myProdutc['homepageImage'];
		$adMainImage 		  = $myProdutc['adMainImage'];
		$productDesc 		  = $myProdutc['productDesc'];
		$itemOrder 			  = $myProdutc['itemOrder'];
		$productAddDate 	  = $myProdutc['productAddDate'];
		$productEndDate		  = $myProdutc['productEndDate'];
		$availableProductsQTY = $myProdutc['availableProductsQTY'];
		$productEnableDesable = $myProdutc['productEnableDesable'];
		$image1               = $myProdutc['image1'];
		$image2               = $myProdutc['image2'];
		$image3 			  = $myProdutc['image3'];
		$catoCode			  = $myProdutc['catoCode'];
		$catoText			  = $myProdutc['catoText'];
		
		
		?>
<div class="deal_store round">
<div class="title_store">
<h1><?php echo $offPresent;?>% OFF! <img src="images/mydeal_logo.png" width="171" height="35" /><br />
  <br />
  <?php echo $productTitle;?><span> <a href="deal/<?php echo $productID;?>/<?php echo seoUrl($productTitle);?>">(more info..)</a></span></h1>
</div>
<div class="deal-image">
<a href="deal/<?php echo $productID;?>/<?php echo seoUrl($productTitle);?>"><img src="images/<?php echo $homepageImage;?>" alt="<?php echo $productTitle;?>" width="300" height="192"/></a>
</div>
<div class="deal-row" style="margin-bottom:5px; width:300px;">
  <div class="grid_original">Original Price <br/> <strong>Rs. <?php echo $originalPrice;?></strong></div>
<div class="grid_dc">Discount <br/> <strong><?php echo $offPresent;?>%</strong> </div>
<div class="grid_save">You Save <br/> <strong>Rs. <?php echo $saveAmt;?></strong></div>
</div>
<div class="price_store">
<p>Now Only<br/>Rs.<?php echo $newAmnt;?></p>
</div>
<div class="buy-now_store">
<a href="deal/<?php echo $productID;?>/<?php echo seoUrl($productTitle);?>"><img src="images/buyNow.png" alt="Buy Now" width="130" height="40"/></a>
</div>
<div style="padding:5px 0; clear:both;
	color:#1173AC;
	text-transform:uppercase;
	font-size:12px;
	font-weight:bold;
	text-align:center;
	border-bottom:1px dotted #ccc;
	border-top:1px dotted #ccc;
	margin:0 0 8px 0;"></div>
</div>			
		<?php
	}
 }
 
 else
 {
 	echo('No Products Found..!');	
 }
 
 ?>           
