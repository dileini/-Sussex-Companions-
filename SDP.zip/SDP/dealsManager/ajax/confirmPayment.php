<?php
session_start();
require_once('../db_connector.php');

$memberShipPay = 200.00;

// getting the data from the url
$client     = mysql_real_escape_string($_POST ['client']);
$pdate      = mysql_real_escape_string($_POST ['pdate']);
 
$userInsertQuery = "INSERT INTO `membership_payment`(`member_id`, `payment_yeat`,`payed_amount`) VALUES($client,$pdate,$memberShipPay)";
$insertUserQ = mysql_query($userInsertQuery);
echo "01";

?>

