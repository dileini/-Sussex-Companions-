<?php
session_start();
require_once('../db_connector.php');

//$maxUserID = "";

// getting the data from the url
$enableOrDesable     = mysql_real_escape_string($_POST ['enableOrDesable']);
$id			 		 = mysql_real_escape_string($_POST ['id']);

$postVal=0;

//$selectQ = "SELECT * FROM `jobcats` where id=$id";
$selectQ = "SELECT * FROM `hobbie` WHERE `hid`=$id";
$selectQRes = mysql_query($selectQ);

if($enableOrDesable==1)
{
	$postVal = 0;
}
	else
	{
		$postVal = 1;
	}




if(mysql_num_rows($selectQRes) != 0)
{
//no recores.
//	echo('1');
 	$updateData = "UPDATE `hobbie` SET `status`=$postVal WHERE `hid`=$id";
	mysql_query($updateData);
	
	if(mysql_affected_rows() > 0)
	{
		//sucess
		echo('1');
	}
	
	else
	{
		//update problem
		echo('2');
	}
}

else 
{
	//3 - No recod found
	echo('3');
}

?>