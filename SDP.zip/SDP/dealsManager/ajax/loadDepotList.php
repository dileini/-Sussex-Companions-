<?php
session_start();
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );

$id = $_POST['region'];
$query = "select * from depots where region_id=" . $id . " order by depot_id,depot_txt";

$stmt = $conn->prepare ( $query );
$stmt->execute ();
$r = $stmt->fetchAll ( Doctrine::FETCH_ASSOC );
?>
<style>
/**
img {border: 2px solid transparent;}
img:hover {border: 2px solid #e0e0e0;}
*/
.classimg
{
	border: 2px solid transparent;
	filter:alpha(opacity=50);
	-moz-opacity: 0.7;
	opacity: 0.7
	/**
	//-moz-border-radius: 15px;
	//border-radius: 15px;
	*/
}
.classimg:hover
{
	border: 2px solid #c0c0c0;
	filter:alpha(opacity=100);
	-moz-opacity: 1.0;
	opacity: 1.0;
	-moz-border-radius: 15px;
	border-radius: 15px;
}

</style>
<div style="font-size: 16px;font-weight: bold;width:550px;"></div>
<table width="100%" border="0">
<?php

if (count ( $r ) > 0)
{
	$itemCount = 0;
	$columnCount = 0;
	$rowCount = (count ( $r ) / 4);

	for($i = 0; $i < $rowCount; $i ++)
	{
		?>
		<tr style="border: solid 2px #000000; padding-bottom: 5px;">
		<?php

		for($j = 0; $j < 4; $j ++)
		{

			?>
			<td style="border-bottom: thin dashed;" width="150px;" >
			<?php
			if ($r [$itemCount] ['depot_txt'] != "")
			{
				?>
		<table width="100%" style="padding-bottom: 19px;cursor:pointer;" >
			<tr>
				<td align="center"><img src="images/home.gif" width="57px" height="44px" onmouseover="" class="classimg" /></td>
			</tr>
			<tr>
				<td align="center" style="font-weight: bold">
				<?php
				echo $r [$itemCount] ['depot_txt'];
				?></td>
			</tr>
			<tr>
				<td align="center" style="font-weight: bold;color:#ff0000;">
				<?php
				echo $r [$itemCount] ['depot_id'];
				?></td>
			</tr>
		</table>
		<?php
			}
			?>
		</td>
		<?php
			$itemCount ++;
		}
		?>
		</tr>
		<?php
	}
}

?>
</table>
<?php 
	$conn-> close();
?>


