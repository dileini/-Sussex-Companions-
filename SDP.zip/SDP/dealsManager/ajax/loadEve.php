<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

$selectQ = "SELECT `event_id`, `event_title`, `event_cost`, `event_date`, `event_time`, `event_added_date`, `event_per_head_cost`
FROM `event` ORDER BY `event_id` DESC";


$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else 
{
	//1 - catgory or category text available
	
	?>
<table width="100%" border="1" cellspacing="1">
  <tr>
    <td width="6%"><em><strong>Count</strong></em></td>
    <td width="4%"><em><strong>#</strong></em></td>
    <td width="12%"><em><strong>Event Title</strong></em></td>
    <td width="12%"><em><strong>Event Date</strong></em></td>
    <td width="15%"><em><strong>Event Time</strong></em></td>
    <td width="35%"><em><strong>Event Cost</strong></em></td>
    <td width="5%"><em><strong>Perhead Cost</strong></em></td>
    <td width="5%"><em><strong>Modify Event</strong></em></td>
    
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
		
	
	?>
  <tr align="left" valign="top" class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['event_id']);?></td>
    <td><?php echo($row['event_title']);?></td>
    <td><?php echo($row['event_date']);?></td>
    <td><?php echo($row['event_time']);?></td>
    <td><?php echo($row['event_cost']);?></td>
    <td><?php echo($row['event_per_head_cost']);?></td>  
    <td>
   <a href="#" onclick="loadPage('editEvents.php',<?php echo $row['event_id'];?>);">Edit</a> 
   </td>
  </tr>	
	<?php
	}
	
	?>
</table> 
    <?php
}

?>