<?php
session_start();
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );
require_once('../db_connector.php');


$electorateCode = mysql_real_escape_string($_GET ['electorateCode']);

$query = "SELECT `electorateCode`, `electorateText` FROM `electorate` WHERE `districtCode`='$electorateCode'";



$optionString = "";
$mainQuery2  = $query;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['electorateCode'].'"'.">".$ro['electorateText']."</option>";
 }


echo $optionString;


?>
