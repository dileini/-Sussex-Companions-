<?php
session_start();
require_once('../db_connector.php');


$productId = $_GET['id'];


$selectQ = "SELECT `event_id`, `event_title`, `event_cost`, `event_date`, `event_time`, `event_added_date`, `event_per_head_cost`
FROM `event` WHERE `event_id`= $productId";
$selectQRes = mysql_query($selectQ);


$event_id            = "";
$event_title         = "";
$event_cost          = "";
$event_date          = "";
$event_time          = "";
$event_added_date    = "";
$event_per_head_cost = "";


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else
{
	while($row = mysql_fetch_array($selectQRes))
	{
		$event_id            = $row['event_id'];
		$event_title         = $row['event_title'];
		$event_cost          = $row['event_cost'];
		$event_date          = $row['event_date'];
		$event_time          = $row['event_time'];
		$event_added_date    = $row['event_added_date'];
		$event_per_head_cost = $row['event_per_head_cost'];
	}
}
?>

<script src="../js/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="../js/mootools.js"> </script>
<script type="text/javascript" src="../js/mootools-more.js"> </script>
<script type="text/javascript" src="../js/lang/en.js"> </script>
<script type="text/javascript" src="../js/empty.js"> </script>
<script type="text/javascript" src="../js/formcheck.js"> </script>
<script type="text/javascript" src="../js/autocomplete.js"> </script>
<!-- <script type="text/javascript" src="../js/addCategory/combo.js"> </script> -->
<script type="text/javascript" src="../js/addCategory/core_functions.js"> </script>

<link rel="stylesheet" href="../js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="../js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="../js/Source/Picker.js" type="text/javascript"></script>
<script src="../js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="../js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="../js/Source/datepicker.css" rel="stylesheet">
<link href="../js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">

<script>
    window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
</script>

<script type="text/javascript">
    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{showErrors:1});
    });

    function saveEvents()
	{
		if (formcheck.checkValidation()) 
		{
			var query = "event_id="+$('event_id').value
					   +"&event_title="+$('event_title').value
					   +"&event_cost="+ $('event_cost').value
					   +"&event_date="+ $('event_date').value
					   +"&event_time="+ $('event_time').value
					   +"&event_per_head_cost="+ $('event_per_head_cost').value;
			var url = 'updateEvents.php';

			var req = new Request({method: 'POST',
				data:query,
				url: url,
				onSuccess: function(result){
					hideImgContent('waitingDiv');
					//alert(result);
					
					if(result =='1')
					{
						alert('Event updated..!')
						//window.location.reload();
						window.close();
					}
					else if(result =='2')
					{
						alert('Inserting problem occor.')
						//window.location.reload();
					}
					else
					{
						alert('products not posted. Try again..!')
						//window.location.reload();
					}
					
				}});
			showImgContent('waitingDiv');
			req.send();
			
		}
		
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Modify Event</p>
<form enctype="multipart/form-data" id="grid_form" action="">
  <table width="400px" border="0" class="grid_head_tbl">
    <tr>
      <td>Event ID</td>
      <td><input name="event_id" type="text" class="validate['required','digit']" id="event_id" style="width:180px;" value="<?php echo $event_id; ?>" readonly="readonly"/></td>
    </tr>
    <tr>
    <td>Event Title : </td>
    <td><input type="text" name="event_title" id="event_title" style="width:180px;" class="validate['required']" value="<?php echo $event_title; ?>"/></td>
  </tr>
  
  <tr>
    <td>Event Date</td>
    <td><input type="text" name="event_date" id="event_date" style="width:180px;" class="validate['required']" value="<?php echo $event_date; ?>"/></td>
  </tr>

  <tr>
    <td>Event Start Time :</td>
    <td><input type="text" name="event_time" id="event_time" style="width:180px;" class="validate['required']" value="<?php echo $event_time; ?>"/></td>
  </tr>
  <tr>
    <td>Event Cost : </td>
    <td><input type="text" name="event_cost" id="event_cost" style="width:180px;" class="validate['required']" value="<?php echo $event_cost; ?>"/></td>
  </tr>
  <tr>
    <td>Per Head Cost :</td>
    <td><input type="text" name="event_per_head_cost" id="event_per_head_cost" style="width:180px;" class="validate['required']" value="<?php echo $event_per_head_cost; ?>"/></td>
  </tr>
</table>
<p>&nbsp;</p>
<table class="grid_head_tbl">

	<tr align="right">
		<td style="align:right;padding-left:200px;">
		<input type="button" value="Save Event" onclick="saveEvents()" />
		</td>
	</tr>

</table>


</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="../images/wait.gif" style="width:150px;height:40px;"/></div></center></div>