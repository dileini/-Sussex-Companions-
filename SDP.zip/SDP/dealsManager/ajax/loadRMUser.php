<?php
session_start();
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );

$id = $_GET['region'];
$regiontxt = $_GET['regiontxt'];

$query = "select * from depots
		  left join region on region.region_id= depots.region_id
		  where depots.region_id=" . $id . " and depots.priority ='0' order by depot_txt";

$stmt = $conn->prepare ( $query );
$stmt->execute ();
$r = $stmt->fetchAll ( Doctrine::FETCH_ASSOC );
?>
<style>
/**
img {border: 2px solid transparent;}
img:hover {border: 2px solid #e0e0e0;}
*/
.classimg 
{
	border: 2px solid transparent;
	filter:alpha(opacity=50);
	-moz-opacity: 0.7;
	opacity: 0.7
	/**
	//-moz-border-radius: 15px;
	//border-radius: 15px;
	*/
}
.classimg:hover
{
	border: 2px solid #c0c0c0;	
	filter:alpha(opacity=100);
	-moz-opacity: 1.0;
	opacity: 1.0;
	-moz-border-radius: 15px;
	border-radius: 15px;
}

</style>
	
<div style="font-size: 16px;font-weight: bold"><?php echo $r[0]['region_text'] ;?></div>
<table width="100%" border="0">
<?php
if (count ( $r ) > 0)
{
	$itemCount = 0;
	$columnCount = 0;
	$rowCount = (count ( $r ) / 4);
	
	for($i = 0; $i < $rowCount; $i ++)
	{
		?>
		<tr style="border: solid 2px #000000; padding-bottom: 5px;">
		<?php
		
		for($j = 0; $j < 4; $j ++)
		{
			
			?>
			<td style="border-bottom: thin dashed;" >
			<?php
			if ($r [$itemCount] ['depot_txt'] != "")
			{
				?>
		<table width="100%" style="padding-bottom: 19px;cursor:pointer;" onclick="javascript:viewDeportInfo('<?php echo $r[$itemCount]['depot_id'] ;?>','<?php echo $r[$itemCount]['depot_txt'] ;?>','<?php echo $id ;?>','<?php echo $r[$itemCount]['region_text'] ;?>')">
			<tr>
				<td align="center"><img src="images/home.gif" width="77px" height="64px" onmouseover="" class="classimg" /></td>
			</tr>
			<tr>
				<td align="center" style="font-weight: bold">
				<?php
				echo $r [$itemCount] ['depot_txt'];
				?></td>
			</tr>
		</table>
		<?php
			}
			?>
		</td>
		<?php
			$itemCount ++;
		}
		?>
		</tr>
		<?php
	}
}

?>	
</table>
<table width="100%" border="0">
  <tr>
    <td><?php include('announcement.php'); ?></td>
  </tr>
</table>
<?php
$conn->close();
?>
