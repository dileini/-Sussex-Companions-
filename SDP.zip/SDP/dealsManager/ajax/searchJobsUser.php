<?php
session_start();
require_once('../db_connector.php');

$searchCatoType = '';

$jobname = $_POST['jobname'];


if($jobname != '0')
{
	//$searchCatoType = " and jobCatid= $catoText ";
	$searchCatoType = " and `jobtitle` LIKE '%$jobname%' ";
}

?>

<div id="content-main">
      <!-- begin hotjobs panel -->
      <div id="hotjobs">
            
            <div class="header-bar"> 
                <div class="header-left"></div>
                <div class="header-mid">Hot Jobs: xxx new hot jobs and 1000+ more jobs </div>
                <div class="header-right"></div>
            </div>
            
 <?php
$jobsQs = "SELECT `jobs`.`jobid` AS jid, `jobs`.`jobidTxt` AS jbText, `jobs`.`jobtitle` AS jbTitle, `jobs`.`jobdescription` AS jbDesc, 
			`jobs`.`jobOffercompanyID` AS compID, 
			`jobs`.`jobimageURL` AS imgURL, `jobs`.`jobVisites` AS joVisi, `jobs`.`jobStatus` AS jobStat, `jobs`.`jobPostedBy`, 
			`jobs`.`jobStatus`, `jobs`.`jobPostedBy`, `jobs`.`jobPostedDate` AS postedDate, `jobs`.`jobModifyDate` AS modDate,
			`jobs`.`jobOpenDate` AS jbOpendate, `jobs`.`jobCloseDate` AS jbCloseDate, `jobs`.`numberofpossitions` AS numPoss, 
			`jobs`.`jobImage` AS jobImage, `jobcats`.`catoText` AS catText
			FROM `jobs`, `jobcats`
			WHERE `jobs`.`jobCatid`=`jobcats`.`id` and `jobStatus`<>0  $searchCatoType
			ORDER BY `jobid`desc
			";
 
 $jobsQsRes = mysql_query($jobsQs);
 
 if(mysql_num_rows($jobsQsRes) !=0)
 {
 	while($job = mysql_fetch_array($jobsQsRes))
	{
		$jobID        = $job['jid'];
		$jbText       = $job['jbText'];
		$jbDesc       = $job['jbDesc'];
		$imgURL       = $job['imgURL'];
		$jbOpendate   = $job['jbOpendate'];
		$jbCloseDate  = $job['jbCloseDate'];
		$numPoss      = $job['numPoss'];
		$jobImage     = $job['jobImage'];
		$catText      = $job['catText'];
		$compID       = $job['compID'];
		?>
<div class="job-column">		
		<div>
            <h5><?php echo $compID; ?></h5> 
 <span class="job-link"><a href="#" onclick="print_invoice(<?php echo $jobID; ?>);"><?php echo $jbText; ?></a></span>
        </div>
</div>		
		
		<?php
	}
 }
 
 else
 {
 	echo('No Jobs Found..!');	
 }
 
 ?>           
            
 
      
      </div>
    </div>