<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

// getting the data from the url
$event_name     = mysql_real_escape_string($_POST ['event_name']);
$event_date     = mysql_real_escape_string($_POST ['event_date']);
$event_time     = mysql_real_escape_string($_POST ['event_time']);
$event_cost     = mysql_real_escape_string($_POST ['event_cost']);
$event_perhead  = mysql_real_escape_string($_POST ['event_perhead']);

 
$userInsertQuery = "INSERT INTO `event`(`event_title`, `event_cost`, `event_date`, `event_time`, `event_per_head_cost`)
VALUES('$event_name',$event_cost,'$event_date','$event_time',$event_perhead)";

$insertUserQ = mysql_query($userInsertQuery);


echo "01";

?>

