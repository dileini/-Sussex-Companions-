<?php
session_start();
require_once('../db_connector.php');

$myUser = $_SESSION['user_id'];
$maxUserID = "";

// getting the data from the url
$productName        = mysql_real_escape_string($_POST ['productName']);
$productDesc        = mysql_real_escape_string($_POST ['productDesc']);
$productDisCount    = mysql_real_escape_string($_POST ['productDisCount']);
$productNormalPrice = mysql_real_escape_string($_POST ['productNormalPrice']);
$productSave        = mysql_real_escape_string($_POST ['productSave']);
$productFinalPrice  = mysql_real_escape_string($_POST ['productFinalPrice']);
$toDate             = mysql_real_escape_string($_POST ['toDate']);
$productItems       = mysql_real_escape_string($_POST ['productItems']);
$job                = mysql_real_escape_string($_POST ['job']);


$timestamp = strtotime($toDate);
$myNewDate = date("Y-m-d", $timestamp);


	$insertQuery = "INSERT INTO `products`(`catoID`,`productTitle`,`offPresent`,`originalPrice`,`discountAmnt`,`saveAmt`,`newAmnt`,`productDesc`,`productEndDate`,`availableProductsQTY`)
VALUES($job,'$productName', $productDisCount, $productNormalPrice, 0.00, $productSave, $productFinalPrice, '$productDesc', '$myNewDate', $productItems)";
	$insertQueryR = mysql_query($insertQuery);
	
	//echo $insertQuery;
	
	if(mysql_affected_rows()!= 0)
	{
		//3 - successfull..
		echo('1');
	}
	
	else
	{
		 //2 - no records added.
		echo('2');
	}	

?>