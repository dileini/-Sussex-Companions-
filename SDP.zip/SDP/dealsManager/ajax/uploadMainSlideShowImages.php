<?php
session_start();
require_once('../db_connector.php');

$id = 'slide_show';
$bname = $_POST['bname'];
$mytime = time();


$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);

if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts)) 
{
  if ($_FILES["file"]["error"] > 0) 
  {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
  } 
	  else 
	  {
			
			
			
			 if (file_exists("../../images/slideshowimages/$mytime".'-'."$id" . $_FILES["file"]["name"])) 
			 {
			  echo $_FILES["file"]["name"] . " already exists. ";
			 } 
				 else 
				 {
			     
			      move_uploaded_file($_FILES["file"]["tmp_name"], "../../images/slideshowimages/$mytime".'-'."$id" . $_FILES["file"]["name"]);
				  $filePath = 'slideshowimages/'.$mytime.'-'.$id.$_FILES["file"]["name"];
				  //$imageUpdateQ = "UPDATE `brands` SET `image1`='$filePath' WHERE `brandID`=$id";
				  
				  //$result = mysql_query($imageUpdateQ);
				  //header('Location: ../addBrand.php.php');
				  
				  $insertQ = "insert into slide_show(`Name`, `Image`) VALUES('$bname','$filePath')";
				  $result = mysql_query($insertQ);
				  header('Location: ../addMainSlideShowImages.php');
				  
			     }
	  }
} 
	else 
	{
	  echo "Invalid file";
	}



?>
