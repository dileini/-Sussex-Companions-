<?php
session_start();
require_once('../db_connector.php');

$id = $_GET ['id'];
$stmt = "select `productID`, `productTitle` from `products` where `catoID`=$id";

$optionString = "";
$mainQuery2  = $stmt;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['productID'].'"'.">".$ro['productTitle']."</option>";
 }


echo $optionString;
?>