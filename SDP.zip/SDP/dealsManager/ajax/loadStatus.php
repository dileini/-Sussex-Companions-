<?php
session_start();
require_once('../db_connector.php');

$stmt = "SELECT `id`, `status_test` FROM `order_status`";

$optionString = "";
$mainQuery2  = $stmt;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
{
		$optionString = $optionString . "<option value=".'"'.$ro['status_test'].'"'.">".$ro['status_test']."</option>";
}
echo $optionString;
?>