<?php
session_start();
require_once('../db_connector.php');

$stmt = "SELECT `depotID`, `depotText` FROM `depot`";

$optionString = "";
$mainQuery2   = $stmt;
$mainResult2  = mysql_query($mainQuery2);
$resCount     = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['depotID'].'"'.">".$ro['depotText']."</option>";
 }
echo $optionString;
?>