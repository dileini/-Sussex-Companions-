<?php
session_start();
require_once('../db_connector.php');

$id		= mysql_real_escape_string($_POST ['id']);
$status	= mysql_real_escape_string($_POST ['status']);

$updateQ = "UPDATE `product_comment` SET `status`=$status WHERE `comment_id`= $id";
mysql_query($updateQ);





















?>