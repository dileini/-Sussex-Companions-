<?php
session_start();
require_once('../db_connector.php');

$cato	= mysql_real_escape_string($_POST ['job']);
$product= mysql_real_escape_string($_POST ['product']);

$query ="
select `productID`, `productTitle`,`comment`, `person_name`, `catoID`, `status`, `comment_id`
from `products`, `product_comment`
where `products`.`productID`=`product_comment`.`producct_id`";

if($cato != '0'){
	$query = $query. " and `catoID`= $cato";
}

if($product != '0'){
	$query = $query. " and  `productID` = $product";
}

$res   = mysql_query($query);

if(mysql_num_rows($res) != 0){
	?>
<table width="70%" border="1">
  <tr>
    <th scope="col">#</th>
    <th scope="col">Product ID</th>
    <th scope="col">Product Text</th>
    <th scope="col">Commented by</th>
    <th scope="col">Comment</th>
    <th scope="col">Status</th>
    <th scope="col">Modify Status</th>
  </tr>
	<?php
	$count = 1;
	while($row = mysql_fetch_array($res)){
		
		?>
 <tr>
    <th scope="row"><?php echo $count; ?></th>
    <td><?php echo $row['catoID']; ?></td>
    <td><?php echo $row['productTitle']; ?></td>
    <td><?php echo $row['person_name']; ?></td>
    <td><?php echo $row['comment']; ?></td>
    <td><?php if($row['status'] == 1)
				{
					echo 'Active';
				}
				else {
					echo 'Deative';
				}
		?></td>
    <td><?php
    if($row['status'] == 1){
		?>
		<a href="#" onclick="modifyComment(<?php echo $row['comment_id']; ?>,'0')">Click to Deative</a>
<?php
	}else{
		?>
		<a href="#" onclick="modifyComment(<?php echo $row['comment_id']; ?>,'1')">Click to Enable</a><?php
	}
	
	
	
	
	?></td>
  </tr>
		<?php
	$count++;
	}
	?>
</table>
	<?php
}


?>