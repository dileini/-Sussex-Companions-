<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

// getting the data from the url
$catoText     = mysql_real_escape_string($_POST ['catoText']);
$catoCode     = mysql_real_escape_string($_POST ['catoCode']);

//check previously entered the same category
//$selectQ = "SELECT * FROM `jobcats` WHERE `catoCode`='$catoCode' OR `catoText`='$catoText'";
$selectQ = "SELECT * FROM `hobbie` WHERE `h_text`='$catoText' AND `h_code`='$catoCode'";
$selectQRes = mysql_query($selectQ);

//three options avilable
if(mysql_num_rows($selectQRes) == 0)
{
	//$insertQuery = "INSERT INTO `jobcats`(`catoCode`,`catoText`) VALUES('$catoCode','$catoText')";
	$insertQuery = "INSERT INTO `hobbie`(`h_text`, `h_code`) VALUES('$catoText','$catoCode')";
	$insertQueryR = mysql_query($insertQuery);
	
	if(mysql_affected_rows()== 0)
	{
		//2 - no records added.
		echo('2');
	}
	
	else
	{
		//3 - success fully added
		echo('3');
	}	
}

else 
{
	//1 - catgory or category text available
	echo '1';
}



?>