</table>
<table width="100%" border="0">
  <tr>
    <td>
      <?php include('announcement.php'); ?></td>
  </tr>
</table>

