<?php
session_start ();
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );

$id = $_GET['deportId'];
$deport_txt = $_GET['deporttxt'];
$regionid = $_GET['regionId'];
$region_txt = $_GET['region_txt'];

$query = "select first_name,last_name,Address,level_name,tel_no,deport_image,created_time,user_details.image_url,depot_txt,deport_tel,region_text from region_auth
		  LEFT JOIN user_details on region_auth.user_id = user_details.user_id
		  left join depots on depots.depot_id = region_auth.deport_id
		  left join region on region.region_id = region_auth.region_id
		  left join user_level on user_level.level_id = region_auth.user_level
                  left join users on users.user_id = user_details.user_id
	      where region_auth.deport_id='$id' and users.status=0";



//echo $query;
$stmt = $conn->prepare ( $query );
$stmt->execute ();
$r = $stmt->fetchAll ( Doctrine::FETCH_ASSOC );
//var_dump($r);
?>
<style>
/**
img {border: 2px solid transparent;}
img:hover {border: 2px solid #e0e0e0;}
*/
.classimg
{
	border: 2px solid transparent;
	filter:alpha(opacity=50);
	-moz-opacity: 0.7;
	opacity: 0.7
	/**
	//-moz-border-radius: 15px;
	//border-radius: 15px;
	*/
}
.classimg:hover
{
	border: 2px solid #c0c0c0;
	filter:alpha(opacity=100);
	-moz-opacity: 1.0;
	opacity: 1.0;
	-moz-border-radius: 15px;
	border-radius: 15px;
}
.th_font {
	font-weight: bold;
	font-size: 14px;
	font-family: Tahoma,Geneva,sans-serif;
}

.tr_font {
	font-weight: bold;
	font-size: 13px;
	font-family: Tahoma,Geneva,sans-serif;
}

.td_font {
	font-weight: bold;
	font-size: 12px;
	font-family: Tahoma,Geneva,sans-serif;
}
.userimg_class {
	
	border: 2px solid #000000;
    float: left;
    height: 70px;
    padding: 5px;
    width: 70px;
}

</style>
<div style="font-size: 16px;font-weight: bold"><?php echo $deport_txt ;?></div>
<table>
	<tr>
		<td>
		<table width="500" border="0">
			<!--tr style="">
				<td class="td_class">Operator Name :</td>
				<td class="td_class"><?php //echo $r[0]['first_name']." ".$r[0]['last_name']; ?></td>
			</tr>
			<tr>
				<td class="td_class">Address :</td>
				<td class="td_class"><?php ///echo $r[0]['Address'];?></td>
			</tr>
			<tr>
				<td class="td_class">Last Logged Time :</td>
				<td class="td_class"><?php //echo $r[0]['region_text'];?></td>
			</tr>
			<tr>
				<td class="td_class">Deport Tel No:</td>
				<td class="td_class"><?php //echo $r[0]['deport_tel']?></td>
			</tr>
			<tr>
				<td class="td_class">Created Time:</td>
				<td class="td_class"><?php //echo $r[0]['created_time']?></td>
			</tr-->

			<?php


				if(count($r)>0)
				{

					$j = 0;

					foreach ($r as $row )
					{
						if($j == 0){

						?>
						<tr>
							<td width="45%" class="th_font" height="25px;" style="padding-top:10px;">Region</td>
							<td width="55%" class="td_font" style="padding-top:10px;"><?php echo $row['region_text'];?></td>
						</tr>
						<tr>
							<td width="45%" class="th_font" height="25px;" style="border-bottom: thin dashed; padding-bottom: 15px;">Deport Telephone no</td>
							<td width="55%" class="td_font" style="border-bottom: thin dashed; padding-bottom: 15px;"><?php echo $row['deport_tel'];?></td>
						</tr>
				<?php
						}
						?>
						<tr style="padding-top:10px;">
							<td width="45%" class="th_font" height="25px;"><?php echo $row['level_name'];?></td>
							<td width="55%" class="td_font"><?php echo $row['first_name'];?>&nbsp;<?php echo $row['last_name'];?></td>
							<td width="17%" class="td_font" rowspan="3">
							<img class="userimg_class" src="<?php

								if($row['image_url'] == "")
								{?>
									images/nouser.jpg
								<?php }
								else
								{
									echo "images/users/".$row['image_url'];
								}
							
								?>
								" alt="User"	name="userImg" id="userImg" /></td>
						</tr>
						<tr>
							<td width="45%" class="th_font" height="25px;">Address</td>
							<td width="55%" class="td_font"><?php echo $row['Address'];?></td>
						</tr>
						<tr>
							<td width="45%" class="th_font" height="25px;">Telephone No</td>
							<td width="55%" class="td_font"><?php echo $row['tel_no'];?></td>
						</tr>
						<tr>
							<td width="45%" class="th_font" height="25px;" style="border-bottom: thin dashed; padding-bottom: 15px;">Account Created Date</td>
							<td width="55%" class="td_font" style="border-bottom: thin dashed; padding-bottom: 5px;"><?php echo $row['created_time'];?></td>
						</tr>
						<?php
						$j++;
					}
				}
	?>

		</table>
		</td>
		<td>
		<div style="padding-left:80px;"><img class="img_class" src="<?php

		if($r[0]['deport_image'] == "")
		{?>
			images/no_photo_available.jpg
		<?php }
		else
		{
			echo $r[0]['deport_image'];
		}

		?>
		" alt="deport"	name="deportimg" id="deportimg" />
		</div>
		</td>
	</tr>
</table>
<table width="100%">
<tr align="right"><td style="font-size: 12px;font-weight:bold;color:#ff0000;cursor:pointer"><span onclick="javascript:viewDeports('<?php echo $regionid ; ?>','<?php echo $region_txt ;?>')">Back To All Deports</span></td></tr>
</table>
