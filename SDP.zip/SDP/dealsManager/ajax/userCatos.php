<?php
session_start();
require_once('../db_connector.php');

$stmt = "SELECT `id`, `catoText` FROM `jobcats` WHERE `catStatus`=1";

$optionString = "";
$mainQuery2  = $stmt;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['id'].'"'.">".$ro['catoText']."</option>";
 }


echo $optionString;
?>