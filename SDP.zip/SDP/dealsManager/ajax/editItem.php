<?php
session_start();
require_once('../db_connector.php');


$productId = $_GET['id'];
/*
$selectQ = "SELECT 
`productID`, `catoID`, `productTitle`, `offPresent`, `originalPrice`, `discountAmnt`, `saveAmt`, `newAmnt`, `homepageImage`, 
`productDesc`, `itemOrder`, `productAddDate`, `productEndDate`, `availableProductsQTY`, productEnableDesable, 
`catoCode`, `catoText` ,catoID, `soteF`
FROM `products` 
LEFT JOIN `jobcats` ON `jobcats`.`id`= `products`.`catoID` 
where `productID`=$productId
order by productID DESC";
*/

$selectQ = "SELECT `id`,`firstName`, `lastName`, `gender`, `email`, `password`, `phone`, `address`, `nic`, 
	`hobie`, `interest`, `register_by`, `location`,`cus_image`,
	`h_text`, `i_text`, `location`,`iid`, `hid`, `l_text`, `lid`
FROM `customer`
LEFT JOIN `hobbie` ON `hobbie`.`hid` = `customer`.`hobie`
LEFT JOIN `interest` ON `interest`.`iid` = `customer`.`interest`
LEFT JOIN `office_location` ON `office_location`.`lid`=`customer`.`location`
where `id`=$productId
ORDER BY `id` DESC";
$selectQRes = mysql_query($selectQ);


$id        = "";
$firstName = "";
$lastName  = "";
$gender    = "";
$email     = "";
$password  = "";
$phone     = "";
$address   = "";
$nic       = "";
$hobie     = "";
$interest  = ""; 
$register_by  = "";
$location     = "";
$cus_image    = "";
$h_text       = "";
$i_text       = "";
$iid      = "";
$hid      = "";
$lid      = "";
$l_text   = "";


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else
{
	while($row = mysql_fetch_array($selectQRes))
	{
		$id        = $row['id'];
		$firstName = $row['firstName'];
		$lastName  = $row['lastName'];
		$gender    = $row['gender'];
		$email     = $row['email'];
		$password  = $row['password'];
		$phone     = $row['phone'];
		$address   = $row['address'];
		$nic       = $row['nic'];
		$hobie     = $row['hobie'];
		$interest  = $row['interest'];
		$register_by  = $row['register_by'];
		$location     = $row['location'];
		$cus_image    = $row['cus_image'];
		$h_text       = $row['h_text'];
		$i_text       = $row['i_text'];	
		$iid        = $row['iid'];	
		$hid        = $row['hid'];	
		$lid        = $row['lid'];	
		$l_text     = $row['l_text'];	
	}
}
?>

<script src="../js/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="../js/mootools.js"> </script>
<script type="text/javascript" src="../js/mootools-more.js"> </script>
<script type="text/javascript" src="../js/lang/en.js"> </script>
<script type="text/javascript" src="../js/empty.js"> </script>
<script type="text/javascript" src="../js/formcheck.js"> </script>
<script type="text/javascript" src="../js/autocomplete.js"> </script>
<!-- <script type="text/javascript" src="../js/addCategory/combo.js"> </script> -->
<script type="text/javascript" src="../js/addCategory/core_functions.js"> </script>

<link rel="stylesheet" href="../js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="../js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="../js/Source/Picker.js" type="text/javascript"></script>
<script src="../js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="../js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="../js/Source/datepicker.css" rel="stylesheet">
<link href="../js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">

<script>
    window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
</script>

<script type="text/javascript">
    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{showErrors:1});
		
		new Picker.Date($('toDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2020-10-01',
          	maxDate: '2022-10-01'
	    });
		
		load_catos();
    });

    function saveCatos()
	{
		if (formcheck.checkValidation()) 
		{

				if($('hb').value == '0')
				{
					alert('Please select hobbie');
					$('hb').focus();
				}
				else if($('inter').value == '0')
				{
					alert('Please select interest');
					$('inter').focus();
				}
				else if($('loc').value == '0')
				{
					alert('Please select office location');
					$('loc').focus();
				}
				
				else
				{
					var query = "clientID="+$('clientID').value
					           +"&first_name="+$('first_name').value
							   +"&last_name="+ $('last_name').value
							   +"&nic="+ $('nic').value
							   +"&Gender_1="+ $('Gender_1').value
							   +"&tel_no="+ $('tel_no').value
							   +"&email="+ $('email').value
							   +"&hb="+ $('hb').value
							   +"&inter="+ $('inter').value
							   +"&loc="+ $('loc').value
							   +"&address="+ $('address').value;
					var url = 'updateClients.php';
	
					var req = new Request({method: 'POST',
						data:query,
						url: url,
						onSuccess: function(result){
							hideImgContent('waitingDiv');
							//alert(result);
							
							if(result =='1')
							{
								alert('products sucessfully added..!')
								//window.location.reload();
								//window.close();
							}
							else if(result =='2')
							{
								alert('Inserting problem occor.')
								//window.location.reload();
							}
							else
							{
								alert('products not posted. Try again..!')
								//window.location.reload();
							}
							
						}});
					showImgContent('waitingDiv');
					req.send();
				
				}

			}
		
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Modify Client</p>
<form enctype="multipart/form-data" id="grid_form" action="">
  <table width="400px" border="0" class="grid_head_tbl">
    <tr>
      <td>Client ID</td>
      <td><input name="clientID" type="text" class="validate['required','digit']" id="clientID" style="width:180px;" value="<?php echo $id; ?>" readonly="readonly"/></td>
    </tr>
    <tr>
    <td>First Name : </td>
    <td><input type="text" name="first_name" id="first_name" style="width:180px;" class="validate['required','nodigit']" value="<?php echo $firstName; ?>"/></td>
  </tr>
  <tr>
    <td>Last Name : </td>
    <td><input type="text" name="last_name" id="last_name" style="width:180px;" class="validate['required','nodigit']" value="<?php echo $lastName; ?>"/></td>
  </tr>
  <tr>
    <td>NIC</td>
    <td><input type="text" name="nic" id="nic" style="width:180px;" class="validate['required']" value="<?php echo $nic; ?>"/></td>
  </tr>
  <tr>
    <td>Gender</td>
    <td><p>
      <label>
        <input name="Gender" type="radio" id="Gender_0" value="m"  <?php if($gender == 'm'){?>
		checked="checked" 
		<?php
		
		}?>/>
        Male</label>
      <label>
        <input type="radio" name="Gender" value="f" id="Gender_1" <?php if($gender == 'f'){?>
		checked="checked" 
		<?php
		
		}?>/>
        Female</label>
      <br />
    </p></td>
  </tr>
  <tr>
    <td>Telephone Number</td>
    <td><input type="text" name="tel_no" id="tel_no" style="width:180px;" class="validate['required','digit','length[10,-1]']" value="<?php echo $phone; ?>"/></td>
  </tr>
  <tr>
    <td>E-mail</td>
    <td><input type="text" name="email" id="email" style="width:180px;" class="validate['required','nodigit']" value="<?php echo $email; ?>"/></td>
  </tr>
  <tr>
    <td>Hobbie</td>
    <td>
<?php  
$stmt         = "SELECT `hid`, `h_text` FROM `hobbie` WHERE `status`=1";
$optionString = "";
$mainQuery2   = $stmt;
$mainResult2  = mysql_query($mainQuery2);
$resCount     = mysql_num_rows($mainResult2);

?>
	<select name="hb" id="hb"  style="width:180px;">
    <option value="<?php echo $hid;?>" selected="selected"><?php echo $h_text;?></option>
    <?php 
	 while($ro = mysql_fetch_array($mainResult2))
	 {
			echo $optionString . "<option value=".'"'.$ro['hid'].'"'.">".$ro['h_text']."</option>";
	 }
	 ?>
    </select>
	</td>
  </tr>
  <tr>
    <td>Interest</td>
    <td>
<?php  
$stmt         = "SELECT `iid`, `i_text` FROM `interest`";
$optionString = "";
$mainQuery2   = $stmt;
$mainResult2  = mysql_query($mainQuery2);
$resCount     = mysql_num_rows($mainResult2);

?>	
	
	<select name="inter" id="inter" style="width:180px;">
	<option value="<?php echo $iid;?>" selected="selected"><?php echo $i_text;?></option>
    <?php 
	 while($ro = mysql_fetch_array($mainResult2))
	 {
			echo $optionString . "<option value=".'"'.$ro['iid'].'"'.">".$ro['i_text']."</option>";
	 }
	 ?>
    </select>
	</td>
  </tr>
  <tr>
    <td>Location</td>
    <td>
<?php  
$stmt         = "SELECT `lid`, `l_text` FROM `office_location`";
$optionString = "";
$mainQuery2   = $stmt;
$mainResult2  = mysql_query($mainQuery2);
$resCount     = mysql_num_rows($mainResult2);

?>	
	<select name="loc" id="loc" style="width:180px;">
    <option value="<?php echo $lid;?>" selected="selected"><?php echo $l_text;?></option>
    <?php 
	 while($ro = mysql_fetch_array($mainResult2))
	 {
			echo $optionString . "<option value=".'"'.$ro['lid'].'"'.">".$ro['l_text']."</option>";
	 }
	 ?>
    </select></td>
  </tr>
  <tr>
    <td>Address : </td>
    <td><input type="text" name="address" id="address" style="width:180px;" class="validate['required']" value="<?php echo $address; ?>"/></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input type="password" name="pass" id="pass" style="width:180px;" class="validate['required']" value="<?php echo $offPresent; ?>"/></td>
  </tr>
</table>
<p>&nbsp;</p>
<table class="grid_head_tbl">

	<tr align="right">
		<td style="align:right;padding-left:200px;">
		<input type="button" value="Save Product" onclick="saveCatos()" />
		</td>
	</tr>

</table>


</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="../images/wait.gif" style="width:150px;height:40px;"/></div></center></div>