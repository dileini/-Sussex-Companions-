<?php
session_start();
require_once('../db_connector.php');
$id = $_SESSION['user_id'];

$query = "SELECT `religionCode`, `religionText` FROM `religions` ORDER BY `religionId`";

$optionString = "";
$mainQuery2  = $query;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['religionCode'].'"'.">".$ro['religionText']."</option>";
 }


echo $optionString;

?>