<?php
session_start();
require_once('../db_connector.php');

$memberShipPay = 200.00;

// getting the data from the url
$client     = mysql_real_escape_string($_POST ['client']);
$pdate      = mysql_real_escape_string($_POST ['pdate']);
 
$selectOverDue = "SELECT `mid`, `member_id`, `payed_amount`, `payment_yeat`, `payment_date` 
					FROM `membership_payment`
					WHERE `mid`=$client AND `payment_yeat`=$pdate";
					
$selectOverDueRes = mysql_query($selectOverDue);

if(mysql_num_rows($selectOverDueRes) == 0)
{
	
	$users    = "SELECT `id`, `firstName`, `lastName`, `email`, `address`, `phone`, `nic` FROM `customer`
				WHERE `id`=$client";
	
	$usersRes     = mysql_query($users);
	
	while($row = mysql_fetch_array($usersRes)){
		?>
<div style="font-size:15px; ">
  <p><?php echo $row['firstName'] .' '.$row['lastName']; ?></p>
  <p><br />
  </p>
  <p><?php echo $row['address']; ?></p>
  <p><br />
  </p>
  <p><?php echo date("Y/m/d");?><br />
  </p>
  <p>&nbsp;</p>
  <p>Dear Sirs,<br />
    <br>
  </p>
  <p>Our Ref: [<?php echo $row['firstName'] .' '.$row['lastName']; ?>]<br />
  </p>
  <p> It has come to our attention that your account is  overdue for payment. </p>
  <p><br />
  </p>
  <p>We are not aware of any disputes or   reason for non-payment, therefore we would respectfully remind you that   you have exceeded the trading terms for these outstanding amounts and we   would be grateful to receive your remittance as soon as possible.<br />
  </p>
  <p>&nbsp;</p>
  <p> The details of the outstanding invoices are as follows:</p>
  <p><br />
  </p>
  <p>&nbsp;</p>
  <table border="1">
    <tbody>
      <tr bgcolor="#999999">
        <th>Invoice No</th>
        <th>Invoice Date</th>
        <th>Due Date</th>
        <th>Amount</th>
      </tr>
      <tr bgcolor="#CCCCCC">
        <td>00001</td>
        <td>2021/01/01</td>
        <td>2021/01/31</td>
        <td><?php echo $memberShipPay; ?></td>
      </tr>
    </tbody>
  </table>
  <p><br>
    <br>
  </p>
  <p>We look forward to hearing from you.</p>
  <p><br />
  </p>
  <p> Yours sincerely</p>
  <p><br />
  </p>
  <p>On behalf of Sussex Companions</p>
  <p>&nbsp;</p>
</div>
	
		
		<?php
	}
	
}

else 
{
	echo "01";
}


?>

