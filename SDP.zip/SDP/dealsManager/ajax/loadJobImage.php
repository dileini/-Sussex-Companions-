<?php
session_start();
require_once('../db_connector.php');



// getting the data from the url
$jobmane         = mysql_real_escape_string($_POST ['jobid']);


$selectImageQ = "SELECT `homepageImage` FROM `products` WHERE `productID`='$jobmane'";
$selectImageQRes = mysql_query($selectImageQ);

if(mysql_num_rows($selectImageQRes) > 0)
{
	
	while($row = mysql_fetch_array($selectImageQRes))
	{
		
	?>
	<img src="../images/<?php echo $row['homepageImage'];?>" width="415" height="265" />
	
	<?php
	
	}
}

?>