<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

$selectQ = "SELECT `id`,`firstName`, `lastName`, `gender`, `email`, `password`, `phone`, `address`, `nic`, 
	`hobie`, `interest`, `register_by`, `location`,`cus_image`,
	`h_text`, `i_text`, `location`
FROM `customer`
LEFT JOIN `hobbie` ON `hobbie`.`hid` = `customer`.`hobie`
LEFT JOIN `interest` ON `interest`.`iid` = `customer`.`interest`
LEFT JOIN `depot` ON `depot`.`depotID`=customer.`location`
ORDER BY `id` DESC";


$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else 
{
	//1 - catgory or category text available
	
	?>
<table width="100%" border="1" cellspacing="1">
  <tr>
    <td width="6%"><em><strong>Count</strong></em></td>
    <td width="4%"><em><strong>#</strong></em></td>
    <td width="12%"><em><strong>First Name</strong></em></td>
    <td width="12%"><em><strong>Last Name</strong></em></td>
    <td width="15%"><em><strong>Gender</strong></em></td>
    <td width="35%"><em><strong>Phone</strong></em></td>
    <td width="5%"><em><strong>Address</strong></em></td>
    <td width="6%"><em><strong>Hobbie</strong></em></td>
    <td width="11%"><em><strong>Interests</strong></em></td>
    <td width="11%"><em><strong>Office Location</strong></em></td>
    <td width="5%"><em><strong>Image</strong></em></td>
    <td width="6%"><em><strong>Registed By</strong></em></td>
    <td width="8%"><em><strong>Modify</strong></em></td>
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
		
	
	?>
  <tr align="left" valign="top" class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['id']);?></td>
    <td><?php echo($row['firstName']);?></td>
    <td>
      <label for="catoCode"><?php echo($row['lastName']);?></label></td>
    <td><?php if($row['gender'] == 'm'){echo('Male');}
				else{
					echo('Female');
					}
					?></td>
    <td><?php echo($row['phone']);?></td>
    <td><?php echo($row['address']);?></td>
    <td><?php echo($row['h_text']);?></td>
    <td><?php echo($row['i_text']);?></td>
    <td><?php echo($row['location']);?></td>
    <td><?php echo($row['cus_image']);?></td>
    <td><?php echo($row['register_by']);?></td>
   
    <td>
   <a href="#" onclick="loadPage('editItem.php',<?php echo $row['id'];?>);">Edit</a> 
   </td>
  </tr>	
	<?php
	}
	
	?>
</table> 
    <?php
}

?>