<?php
session_start();
require_once('../db_connector.php');

//$maxUserID = "";

// getting the data from the url
$catoText     = mysql_real_escape_string($_POST ['catoText']);
$catoCode     = mysql_real_escape_string($_POST ['catoCode']);
$id			  = mysql_real_escape_string($_POST ['id']);

//$selectQ = "SELECT * FROM `jobcats` where id=$id";
$selectQ = "SELECT * FROM `hobbie` WHERE `hid`=$id";
$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) != 0)
{
//no recores.
//	echo('1');
 	$updateData = "UPDATE `hobbie` SET `h_code`='$catoCode', 
									   `h_text`='$catoText' 
										WHERE `hid`=$id";
	mysql_query($updateData);
	
	if(mysql_affected_rows() > 0)
	{
		//sucess
		echo('1');
	}
	
	else
	{
		//update problem
		echo('2');
	}
}

else 
{
	//3 - No recod found
	echo('3');
}

?>