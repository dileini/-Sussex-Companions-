<?php
session_start();
/**
 * this page contains all the functionalities for a new user
 *
 * created by thilina
 * date 2011 - 05 - 14
 */
require_once('../db_connector.php');
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );


$user_id = $_SESSION['user_id'];
//initial query string
$queryString = "SELECT
region.regionText,
depot.depotText,
user_details.first_name,
user_details.last_name,
depot.depotImageURL,
user_details.created_time,
user_details.image_url
FROM user_details
LEFT JOIN region_auth ON region_auth.user_id = user_details.user_id
LEFT JOIN region ON region.regionCode = region_auth.region_id
LEFT JOIN depot ON depot.`depotCorde` = region_auth.deport_id
WHERE user_details.user_id=".$user_id;

$queryStringRes = mysql_query($queryString);

$userResult = mysql_fetch_array($queryStringRes);

?>

<table>
	<tr>
		<td>
		<table width="580" border="0">
			<tr style="">
				<td class="td_class">Operator Name :</td>
				<td class="td_class"><?php echo $userResult[2]." ".$userResult[3]; ?></td>
				<td class="td_class" rowspan="5"><img class="img_class1" src="<?php

				if($userResult[7] == "")
				{?>
					images/nouser.jpg
				<?php }
				else
				{
					echo "images/users/".$userResult[7];
				}
		
				?>
				" alt="user" name="userimg" id="userimg" /></td>
			</tr>
			<tr>
				<td class="td_class">Deport :</td>
				<td class="td_class"><?php echo $userResult[1];?></td>
			</tr>
			<tr>
				<td class="td_class">Region :</td>
				<td class="td_class"><?php echo $userResult[0];?></td>
			</tr>
			<tr>
				<td class="td_class">Created date :</td>
				<td class="td_class"><?php echo $userResult[5]?></td>
			</tr>
		</table>
		</td>
		<td>
		<div style="padding-left:10px;"><img class="img_class" src="<?php

		if($userResult[4] == "")
		{?>
			images/no_photo_available.jpg
		<?php }
		else
		{
			echo $userResult[4];
		}

		?>
		" alt="deport"
			name="deportimg" id="deportimg" /></div>
		</td>
	</tr>
</table>
<table width="100%" border="0">
  <tr>
    <td><?php include('announcement.php'); ?></td>
  </tr>
</table>
