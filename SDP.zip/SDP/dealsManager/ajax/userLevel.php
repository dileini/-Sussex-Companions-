<?php
session_start();
require_once('../db_connector.php');

$stmt = "select `level_id`, `level_name` from user_level WHERE avalableUserLevel=1";

$optionString = "";
$mainQuery2  = $stmt;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['level_id'].'"'.">".$ro['level_name']."</option>";
 }


echo $optionString;
?>