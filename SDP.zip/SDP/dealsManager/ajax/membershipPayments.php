<?php
session_start();
require_once('../db_connector.php');


// getting the data from the url
$client     = mysql_real_escape_string($_POST ['client']);
$eventSum   = 0.00;

$clientWhere = "";
$eventWhere  = "";

if($client != '0'){
	$clientWhere = " AND `client_id`= $client  ";
}

$selectQ = "SELECT `mid`, `member_id`, `payed_amount`, `payment_yeat`, `payment_date`, `firstName`, `lastName`
FROM `membership_payment` 
LEFT JOIN `customer` ON `customer`.`id`=`membership_payment`.`member_id`
where `mid` <> 0 $clientWhere
";


$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('01');
}

else 
{
	//1 - catgory or category text available
	
	?>
<table width="100%" border="1" cellspacing="1">
  <tr>
    <td width="7%"><em><strong>Count</strong></em></td>
    <td width="13%"><em><strong>Client First Name</strong></em></td>
    <td width="9%"><em><strong>Last Name</strong></em></td>
    <td width="12%"><em><strong>Payed for Year</strong></em></td>
    <td width="10%"><em><strong>Payed Ammount</strong></em></td>
    <td width="21%"><em><strong>Payed Date</strong></em></td>
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
			$eventSum = $eventSum + $row['payed_amount'];
	
	?>
  <tr align="left" valign="top" class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['firstName']);?></td>
    <td><?php echo($row['lastName']);?></td>
    <td><?php echo($row['payment_yeat']);?></td>
    <td><?php echo($row['payed_amount']);?></td>
    <td><?php echo($row['payment_date']);?></td>
  </tr>	
	<?php
	}
	
	?>
	<tr align="left" valign="top" class="border_bottom">
    <td colspan="4" align="right"><strong>Total per head cost</strong></td>
    <td colspan="3"><strong><?php echo number_format($eventSum, 2); ?></strong></td>
  </tr>	
</table> 
    <?php
}

?>