<?php
session_start();
require_once('../db_connector.php');

$myUser = $_SESSION['user_id'];
$maxUserID = "";

// getting the data from the url
$clientID    = mysql_real_escape_string($_POST ['clientID']);
$first_name  = mysql_real_escape_string($_POST ['first_name']);
$last_name   = mysql_real_escape_string($_POST ['last_name']);
$nic         = mysql_real_escape_string($_POST ['nic']);
$Gender_1    = mysql_real_escape_string($_POST ['Gender_1']);
$tel_no      = mysql_real_escape_string($_POST ['tel_no']);
$email       = mysql_real_escape_string($_POST ['email']);
$hb          = mysql_real_escape_string($_POST ['hb']);
$inter       = mysql_real_escape_string($_POST ['inter']);
$loc         = mysql_real_escape_string($_POST ['loc']);
$address     = mysql_real_escape_string($_POST ['address']);


$updateQuery = "UPDATE `customer` SET
`firstName`='$first_name', 
`lastName`='$last_name', 
`gender`='$Gender_1', 
`email`='$email',
`phone`='$tel_no',
`address`='$address',
`nic`='$nic',
`hobie`='$hb',
`interest`='$inter',
`location`='$loc'
WHERE `id`=$clientID";

//echo($updateQuery);

mysql_query($updateQuery);

	//echo $insertQuery;
	
	if(mysql_affected_rows()!= 0)
	{
		//2 - no records added.
		echo('1');
	}
	
	else
	{
		//3 - success full..
		echo('2');
	}	

?>