		<?php
		
		session_start ();
		require_once ('../bootstrap.php');
		require_once ('../db_connector.php');
		Doctrine_Core::loadModels ( '../models' );
		
		?>
		
		<html>
		
		
		<style>
		/**
		img {border: 2px solid transparent;}
		img:hover {border: 2px solid #e0e0e0;}
		*/
		.container1{
		background:#dfffe4;
		border-radius:4px;
		padding:10px;
		font-family:Tahoma;
		}
		.container{
		background:#c1ffed;
		border-radius:4px;
		padding:10px;
		font-family:Tahoma;
		}
		.container2{
		background:#f2fffb;
		border-radius:4px;
		padding:10px;
		font-family:Tahoma;
		}
		.space{
		padding:10px;
		clear:both;
		}
		.body{
		margin:auto;
		width:80%;
		}
		.classimg {
		border: 2px solid transparent;
		filter: alpha(opacity =   50);
		-moz-opacity: 0.7;
		opacity: 0.7 /*
		-moz-border-radius: 15px;
		border-radius: 15px;
		*/
		}
		
		.classimg:hover {
		border: 2px solid #c0c0c0;
		filter: alpha(opacity =   100);
		-moz-opacity: 1.0;
		opacity: 1.0;
		-moz-border-radius: 15px;
		border-radius: 15px;
		}
		body {
		font-family: Verdana, Geneva, sans-serif;
		font-size: 11px;
		}
		
		td {
		font-size: 11px;
		}
		
		th {
		font-size: 12px;
		}
		
		.itemGrid {
		border: 2px solid black;
		margin: 0;
		}
		
		.item {
		border: 1px solid black;
		padding: 4px;
		margin: 0;
		text-align: left;
		}
		</style>

<body>


		<?php
		
		$epf         = mysql_real_escape_string($_GET['epf']);
		
		echo $mySelectQ = "SELECT `personalInfoId`, `personalinfo`.`epfNo` as myEPF, `fileNumber`, `surName`, `initials`, 
		currentStatus, statuscodes.statusText as statText,
		`initialsDiscription`, `email`, `nidNo`, `dob`,
		`bloodGroup`, `gender`, `nationality`, `religion`, `maritalStatus`, `nameWithInitials`, `emergencyPersonName`,`emergencyAddressLine1`,
		`emergencyAddressLine2`, `emergencyAddressLine3`, `emergencyAddressLine4`, `emergencyAddressLine5`, `emergencyTel`,`highestEducation`,
		`mobileNumber`, `landPhoneNumber`, `recordProcessedDate`, 
		`trasportMethod`, `transportmethods`.`transportText` as trasportMethodTxt,
		 `distancetoHome`, `dateOfMarried`, `passportNumber`,
		`drivingLicenNumber`, `currentWorkStation`, 
		`depotCorde`, `depotText` as depText, 
		`region`.`regionCode`,
		`region`.`regionText` as regText
		
		,`addressline1`, `addressLine2`, `addressLine3`, `addressLine4`, `addressLine5`
		,postalCode, 
		district, district.DistrictText as distText, 
		province, provinces.provincesText as provText,
		addressinfo.electorate as electroCode, electorate.electorateText as electrText,
		
		`gradings`.`gradeText` AS curGrade
		,`designation`.`DesignationText` AS curDes
		,`nationality`.`nationalityText` AS naText 
		,`religions`.`religionText` AS regionText
		
		FROM `personalinfo`
		
		LEFT JOIN `depot` 
		ON `personalinfo`.`currentWorkStation`=`depot`.`depotCorde`
		
		LEFT JOIN statuscodes 
		ON personalinfo.currentStatus=statuscodes.statusCode
		
		LEFT JOIN `addressinfo` 
		ON `addressinfo`.`epfNo`= `personalinfo`.`epfNo`
		
		LEFT JOIN district 
		ON addressinfo.district=district.DistrictCode
		
		LEFT JOIN provinces 
		ON addressinfo.province = provinces.provincesCode	
		
		LEFT JOIN electorate 
		ON addressinfo.electorate=electorate.electorateCode 					
		
		LEFT JOIN `region`
		ON `region`.`regionCode` = `depot`.`regionCode`
		
		LEFT JOIN `gradings`
		ON `gradings`.`gradeCode` = `personalinfo`.`currentGrade`
		
		LEFT JOIN `designation`
		ON `designation`.`DesignationCode`= `personalinfo`.`currentDesignation`
		
		LEFT JOIN `religions`
		ON `religions`.`religionCode`= `personalinfo`.`religion`
		
		LEFT JOIN `nationality`
		ON `nationality`.`nationalityCode` = `personalinfo`.`nationality`
		
		LEFT JOIN transportmethods
		ON personalinfo.trasportMethod=transportmethods.transportCode
		
		
		WHERE `personalInfoId`<>0 
		AND `addressinfo`.`addressType`='present' 
		AND `personalinfo`.`epfNo`=$epf;
		";
		
		
		$mySelectQ1 = "SELECT 
		addressinfo.electorate as electroCode, electorate.electorateText as electrText
		LEFT JOIN `addressinfo` 
		ON `addressinfo`.`epfNo`= `personalinfo`.`epfNo`
		LEFT JOIN electorate 
		ON addressinfo.electorate=electorate.electorateCode 
		WHERE `personalInfoId`<>0 
		AND `addressinfo`.`addressType`='permanent' 
		AND `personalinfo`.`epfNo`=$epf;
		";
		
		
		$mySelectQRes = mysql_query($mySelectQ);
		
		$mySelectQRes1 = mysql_query($mySelectQ1);
		
		
		if(mysql_num_rows($mySelectQRes)== 0)
		{
		echo('No recores foud..!');
		}
		
		else
		{
		while(
		($myRecords = mysql_fetch_array($mySelectQRes))
		|| ($myRecords1 = mysql_fetch_array($mySelectQRes1))
		)
		
		{
		
		?>
        
					<!--   basic info woth the image -->
                    
		<div class="space" > </div>
		<table class="container1" width="80%" align="center">
		
		<tr>
		<th width="24%" rowspan="6"><img src="../image/demo001.jpg" width="75%" height="100%" /></th>
		<td width="76%" height="36"><h4>&nbsp;</h4></td>
		</tr>		
		
		<tr>
		<td height="36"><h4><h2><?php echo $myRecords['surName']." ".$myRecords['initialsDiscription'];?></h2></h4></td>
		</tr>
		<tr>
		<td height="36"><h4><?php echo "EPF Number : ".$myRecords['myEPF'];?></h4></td>
		</tr>
		<tr>
		<td height="36"><h4><?php echo $myRecords['addressline1']." ".$myRecords['addressLine2']." ".$myRecords['addressLine3']." ".$myRecords['addressLine4']
		." ".$myRecords['addressLine5'];?></h4></td>
		</tr>
		<tr>
		<td height="36"><h4><?php echo $myRecords['mobileNumber']." ".$myRecords['landPhoneNumber'];?></h4></td>
		</tr>
		<tr>
		<td height="36"><h4>&nbsp;</h4></td>
		</tr>
		
		</table>
		
		<div class="space" > </div>
		
		
		

						<!--  basic information -->
								
								
								
	<table class="container2" width="80%" align="center">
		<tr>
		<td colspan='4' height="26"><hr><b>Basic Informations</b><hr></td>
		</tr>
			  
	  
		<tr>
		<td width="16%" height="17">EPF Number : </td>
		<td width="36%" height="17"><?php if ($myRecords['myEPF']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['myEPF'];?></td>
		<td width="19%" height="16">File Number : </td>
		<td width="29%" height="16"><?php if ($myRecords['fileNumber']=='') 
		echo 'NOT AVAILABLE'; else echo $myRecords['fileNumber'];?></td>
		</tr>				
		
		<tr>
		<td>Surname : </td>
		<td><?php echo $myRecords['surName'];?></td>
		<td>Initials : </td>
		<td><?php echo $myRecords['initials'];?></td>
		</tr>
		
		<tr>
		<td>Full Name : </td>
		<td><?php echo $myRecords['surName']." ".$myRecords['initialsDiscription'];?></td>
		<td>Telephone Number : </td>
		<td><?php if ($myRecords['mobileNumber']=='' AND $myRecords['landPhoneNumber']=='') 
		echo 'NOT AVAILABLE'; 
		else echo $myRecords['mobileNumber']. " ".$myRecords['landPhoneNumber'];?>
		</td>
		</tr>
		
		<tr>
		<td>Email Address : </td>
		<td><?php if ($myRecords['email']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['email'];?></td>
		<td>NIC Number : </td>
		<td><?php if ($myRecords['nidNo']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['nidNo'];?></td>
		</tr>
		
		<tr>
		<td>Address : </td>
		<td><?php if ($myRecords['addressline1']!='') echo $myRecords['addressline1'];
					else echo 'NOT AVAILABLE';?></td>
		<td>Date of Birth : </td>
		<td><?php if ($myRecords['dob']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['dob'];?></td>
		</tr>
		
		<tr>
		<td>&nbsp;</td>
		<td><?php echo $myRecords['addressLine2'];?></td>
		<td>Blood Group : </td>
		<td><?php if ($myRecords['bloodGroup']=='') echo 'NOT AVAILABLE'; 
		elseif ($myRecords['bloodGroup']=='NON') echo 'NOT AVAILABLE';
		else echo $myRecords['bloodGroup'];?></td>
		</tr>
		
		<tr>
		<td>&nbsp;</td>
		<td><?php echo $myRecords['addressLine3'];?></td>
		<td>Gender : </td>
		<td><?php if($myRecords['gender']=='M') echo 'Male'; 
		elseif($myRecords['gender']=='F') echo 'Female'; else echo 'NOT AVAILABLE'; ?></td>
		</tr>
		
		<tr>
		<td>&nbsp;</td>
		<td><?php echo $myRecords['addressLine4'];?></td>
		<td>Nationality : </td>
		<td><?php if ($myRecords['naText']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['naText'];?></td>
		</tr>
		
		<tr>
		<td>&nbsp;</td>
		<td><?php echo $myRecords['addressLine5'];?></td>
		<td>Religion : </td>
		<td><?php if ($myRecords['regionText']=='') echo 'NOT AVAILABLE';
		 else echo $myRecords['regionText'];?></td>
		</tr>
		
		<tr>
		<td>Postal Code : </td>
		<td><?php if ($myRecords['postalCode']=='') echo 'NOT AVAILABLE'; 
		elseif ($myRecords['postalCode']==0) echo 'NOT AVAILABLE';
		else echo $myRecords['postalCode'];?></td>
		<td>District : </td>
		<td><?php if ($myRecords['distText']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['distText'];?></td>
		</tr>
		
		<tr>
		<td>Province : </td>
		<td><?php if ($myRecords['provText']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['provText'];?></td>
		
		<td>Electorate : </td>
		<td><?php if ($myRecords1['electroCode']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords1['electrText'];?></td>
		</tr>
		
		<tr>
		<td>Marital Status : </td>
		<td><?php if($myRecords['maritalStatus'] == 'S') echo 'Single'; 
						elseif ($myRecords['maritalStatus'] == 'M') echo 'Married';
						elseif ($myRecords['maritalStatus'] == 'D') echo 'Divorced';
						elseif ($myRecords['maritalStatus'] == 'W') echo 'Widow';
						elseif ($myRecords['maritalStatus'] == 'L') echo 'Legally Separated';
						elseif ($myRecords['maritalStatus'] == 'N') echo 'None';
						elseif ($myRecords['maritalStatus'] == '') echo 'NOT AVAILABLE';?></td>
		<td>Highest Education : </td>
		<td><?php if ($myRecords['highestEducation']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['highestEducation'];?></td>
		</tr>
		<tr>
		<td>Passport Number : </td>
		<td><?php if ($myRecords['passportNumber']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['passportNumber'];?></td>
		<td>Driving Licen Number : </td>
		<td><?php if ($myRecords['drivingLicenNumber']=='') echo 'NOT AVAILABLE';
		 else echo $myRecords['drivingLicenNumber'];?></td>
		</tr>
		<tr>
		<td>Current Work Station : </td>
		<td><?php if ($myRecords['depText']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['depText'];?></td>
		<td>Current Status : </td>
		<td><?php if ($myRecords['statText']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['statText'];?></td>
		</tr>
		<tr>
		<td>Current Grade : </td>
		<td><?php if ($myRecords['curGrade']=='') echo 'NOT AVAILABLE';
		 else echo $myRecords['curGrade'];?></td>
		<td>Current Designation : </td>
		<td><?php if ($myRecords['curDes']=='') echo 'NOT AVAILABLE';
		 else echo $myRecords['curDes'];?></td>
		</tr>
		
		<tr>
		<td>Trasport Method : </td>
		<td><?php if ($myRecords['trasportMethod']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['trasportMethodTxt'];?></td>
		
		<td>Distance to Home : </td>
		<td><?php if ($myRecords['distancetoHome']=='') echo 'NOT AVAILABLE';
		 else echo $myRecords['distancetoHome'];?></td>
		</tr>
		
		<tr>
		<td height="18">Date Of Married : </td>
		<td height="18"><?php if ($myRecords['dateOfMarried']=='') echo 'NOT AVAILABLE';
		else echo $myRecords['dateOfMarried'];?></td>
		<td height="18"></td>
		<td height="18"></td>
		</tr>
  		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
   

			 
 
			 
			  			<!--   Person to be informed in an Emergency -->
								
								
			  
		<tr>
		<td colspan="4" height="18"><b>Person to be informed in an Emergency</b></td>
		</tr>
		<tr>
		    <td height="18">Name of the Person : </td>
		<td height="18"><?php if ($myRecords['emergencyPersonName']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['emergencyPersonName'];?></td>
		<td height="18"></td>
		<td height="18"></td>
		</tr>
		<tr>
		    <td height="18">Telephone Number : </td>
		<td height="18"><?php if ($myRecords['emergencyTel']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['emergencyTel'];?></td>
		<td height="18"></td>
		<td height="18"></td>
		</tr>
		<tr>
		    <td height="18">Address : </td>
		<td height="18"><?php if ($myRecords['emergencyAddressLine1']=='') echo 'NOT AVAILABLE'; 
		else echo $myRecords['emergencyAddressLine1']." ".$myRecords['emergencyAddressLine2']." ".
		$myRecords['emergencyAddressLine3']." ".$myRecords['emergencyAddressLine4']." ".$myRecords
		['emergencyAddressLine5'];?></td>
		<td height="18"></td>
		<td height="18"></td>
		</tr>
		
		
		<?php
		}
		}
		?>
		
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>				
							
							
				<!--   Service Information -->
				
				
				
								
								
		<?php					
		$epf=mysql_real_escape_string($_GET['epf']);
		
		$serviceInfoQ = "SELECT
		trasferCountID, 
		gradingCord, gradings.gradeText as gradeTxt,
		serviceinfo.designationCode, designation.DesignationText as desText,
		dateOfAppointment, dateOfRelease, dateOfDutyReport, dateOfDutyEnded, 
		startingWorkStationCode, depot.depotText as startingWrkStText,
		previousWorkStationCode,
		workRegionCode, region.regionText as regionTxt,
		natureOfEmployeement, natureofemployement.natureOfEmpText as natureOfEmpTxt,
		methodOfRequirment, methodofrequirment.methodOfRequirmentText as methodOfReqTxt, 
		workedYears, workedMonths, serviceChangeTyep
		from 
		serviceinfo
		
		LEFT JOIN gradings
		ON serviceinfo.gradingCord=gradings.gradeCode
		
		LEFT JOIN designation
		ON serviceinfo.designationCode=designation.DesignationCode
		
		LEFT JOIN depot
		ON serviceinfo.startingWorkStationCode=depot.depotCorde
		
		LEFT JOIN natureofemployement
		ON serviceinfo.natureOfEmployeement=natureofemployement.natureOfEmpCode
		
		LEFT JOIN methodofrequirment
		ON serviceinfo.methodOfRequirment=methodofrequirment.methodOfRequirmentCode
		
		LEFT JOIN region
		ON depot.regionCode=region.regionCode
		
		where appoinmentID <> 0
		AND serviceinfo.epfNo=$epf
		order by trasferCountID;
		";
		
		$serviceInfoQ2 = "SELECT
		previousWorkStationCode, depot.depotText as previousWrkStText,
		previousDesignationCode, designation.DesignationText as previousDesText
		from 
		serviceinfo
		
		LEFT JOIN depot
		ON serviceinfo.previousWorkStationCode=depot.depotCorde
		
		LEFT JOIN designation
		ON serviceinfo.previousDesignationCode=designation.DesignationCode
		
		where appoinmentID <> 0
		AND serviceinfo.epfNo=$epf
		order by trasferCountID;
		";
		
		
		$serviceInfoQRes = mysql_query($serviceInfoQ);
		
		$serviceInfoQRes2 = mysql_query($serviceInfoQ2);
		
		if ((mysql_num_rows($serviceInfoQRes) != 0) AND (mysql_num_rows($serviceInfoQRes2) != 0) )
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Service Information</b><hr></td>
		</tr>
		
		<tr>
		<td colspan="4">
		<table width="100%" border="1">
		<tr class="container">
		<td width="3%">Count</td>
		<td width="7%">Grade</td>
		<td width="8%"><div align="center">Current Dessignation</div></td>
		<td width="8%"><div align="center">Previous Dessignation</div></td>
		<td width="7%"><div align="center">Date Of Appointment</div></td>
		<td width="5%"><div align="center">Date Of Released</div></td>
		<td width="6%"><div align="center">Date Of Duty Reported</div></td>
		<td width="6%"><div align="center">Date Of Duty Ended</div></td>
		<td width="7%"><div align="center">Starting Work Station</div></td>
		<td width="7%"><div align="center">Previous Work Station</div></td>
		<td width="6%">Region</td>
		<td width="8%"><div align="center">Nature Of Employeement</div></td>
		<td width="6%"><div align="center">Method Of Requirment</div></td>
		<td width="5%"><div align="center">Worked Years</div></td>
		<td width="4%"><div align="center">Worked Months</div></td>
		<td width="7%"><div align="center">Service Change Type</div></td>
		</tr>
		
		<?php					
		while (($serviceInfoRecords = mysql_fetch_array($serviceInfoQRes)) 
		AND ($serviceInfoRecords2 = mysql_fetch_array($serviceInfoQRes2)))
		{
		?>
		
		<tr>
		<td><?php echo $serviceInfoRecords['trasferCountID'];?></td>
		<td><?php echo $serviceInfoRecords['gradeTxt'];?></td>
		<td><?php echo $serviceInfoRecords['desText'];?></td>
		<td><?php echo $serviceInfoRecords2['previousDesText'];?></td>
		<td><?php echo $serviceInfoRecords['dateOfAppointment'];?></td>
		<td><?php echo $serviceInfoRecords['dateOfRelease'];?></td>
		<td><?php echo $serviceInfoRecords['dateOfDutyReport'];?></td>
		<td><?php echo $serviceInfoRecords['dateOfDutyEnded'];?></td>
		<td><?php echo $serviceInfoRecords['startingWrkStText'];?></td>
		<td><?php echo $serviceInfoRecords2['previousWrkStText'];?></td>
		<td><?php echo $serviceInfoRecords['regionTxt'];?></td>
		<td><?php echo $serviceInfoRecords['natureOfEmpTxt'];?></td>
		<td><?php echo $serviceInfoRecords['methodOfReqTxt'];?></td>
		<td><?php echo $serviceInfoRecords['workedYears'];?></td>
		<td><?php echo $serviceInfoRecords['workedMonths'];?></td>
		<td>
		<?php if($serviceInfoRecords['serviceChangeTyep']=='AP') echo 'First Appointment';
		elseif($serviceInfoRecords['serviceChangeTyep']=='PR') echo 'Promotion';
		elseif($serviceInfoRecords['serviceChangeTyep']=='TR') echo 'Transfer';
		elseif($serviceInfoRecords['serviceChangeTyep']=='PT') echo 'Promotion with Transfer';
		elseif($serviceInfoRecords['serviceChangeTyep']=='ER-emptyAll') 
		echo 'Error(All fields are empty)';
		elseif($serviceInfoRecords['serviceChangeTyep']=='ER-emptyEvenOne') 
		echo 'Error(One or more fields are empty';
		elseif($serviceInfoRecords['serviceChangeTyep']=='ER-sameAll') 
		echo 'Error(All fields are equal';
		?>
		</td>
		</tr>							  
		
		<?php						
		}
		?>
		
		</table>
		</td>
		</tr>
		
		<?php
		}
		?>
		
		<tr>
		<td height="18" colspan="4"></td>
		</tr>
        

							  
						<!--   Dependents -->
							 
						<!--   Spouse -->		
						
						
							  
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$spouseSelectQ = "SELECT
		dateOfMarried, spouseName, spouseNic, isEmployed, employerName, 
		employerAddressLine1, employerAddressLine2,
		employerAddressLine3, employerAddressLine4, employerAddressLine5, employerTel, statusCorde
		from 
		spouse 
		WHERE
		spouseId <> 0
		AND statusCorde <> 'S'
		AND spouse.epfNo=$epf;
		";
		$spouseSelectQRes = mysql_query($spouseSelectQ);
		
		if(mysql_num_rows($spouseSelectQRes) != 0)
		{
		
		while($spouseRecords = mysql_fetch_array($spouseSelectQRes))
		{
		
		?>
		<tr>
		<td colspan="4" height="26"><hr><b>Dependents</b><hr></td>
		</tr>
		
		<tr>
		<td colspan="4" height="18"><b>Spouse</b></td>
		</tr>
		
		<tr>
		<td colspan="4">
		
		<table width="100%" >
		<tr>
		<td width="29%" height="18">Name : </td>
		<td colspan="3" width="71%" height="18"><?php echo $spouseRecords['spouseName'];?></td>
		</tr>
		
		<tr>
		<td height="18">Date Of Married : </td>
		<td colspan="3" height="18"><?php echo $spouseRecords['dateOfMarried'];?></td>
		</tr>
		
		<tr>
		<td height="18">NIC Number : </td>
		<td colspan="3" height="18"><?php if($spouseRecords['spouseNic']=='') echo 'NOT AVAILABLE'; 
		else echo $spouseRecords['spouseNic'];?></td>
		</tr>
		
		<tr>
		<td height="18">If spouse is employed : </td>
		<td colspan="3" height="18"><?php echo $spouseRecords['isEmployed'];?></td>
		</tr>
		
		<?php
		if ($spouseRecords['isEmployed']=='YES')
		{
		?>
		
		<tr>
		<td height="18">Name of the employer : </td>
		<td colspan="3" height="18"><?php echo $spouseRecords['employerName'];?></td>
		</tr>
		
		<tr>
		<td height="18">Address of the employer : </td>
		<td colspan="3" height="18"><?php echo $spouseRecords['employerAddressLine1'];?></td>
		</tr>
		
		<tr>
		<td height="18">Telephone number of the employer : </td>
		<td colspan="3" height="18"><?php echo $spouseRecords['employerTel'];?></td>
		</tr>
		</table>
		
		</td>
		</tr>
		
		
		<?php
		}
		}
		}
		?>




							  					<!--   Children -->
								
								
								
								
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$childreninfoSelectQ = "SELECT
		childCount, childName, childBday, gender				
		from 
		childreninfo WHERE
		childreninfoId <> 0
		AND childreninfo.epfNo=$epf;
		";
		$childreninfoSelectQRes = mysql_query($childreninfoSelectQ);
		
		
		if(mysql_num_rows($childreninfoSelectQRes) != 0)
		{
		?>
        <tr>
		<td colspan="4" height="18"><b>Children</b></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="60%"  border="1" >
		<tr class="container">
		<td width="6%" >Count </td>
		<td width="68%">Name of the child </td>
		<td width="17%">Birthday </td>
		<td width="9%">Gender </td>
		</tr>
		
		<?php
		while($childreninfoRecords = mysql_fetch_array($childreninfoSelectQRes))
		{
		
		?>
		<tr>
		<td width="6%" ><?php echo $childreninfoRecords['childCount'];?></td>
		<td width="68%"><?php echo $childreninfoRecords['childName'];?></td>
		<td width="17%"><?php echo $childreninfoRecords['childBday'];?></td>
		<td width="9%"><?php echo $childreninfoRecords['gender'];?></td>
		</tr>
		
		
		<?php
		}
		?>
		
		</table>			  	
		</td>
		</tr>
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>	
		
		<?php
		}
		?>
		
                  
							  
					
					
						<!-- Education Qualifications -->
												
												
												

						
						<!-- Ordinary Level Results First-->
						
						
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$olresultsSelectQ = "SELECT
		olSubjectCountId, olSubject, gceolsubjects.gceolSubjectText as olSubTxt, olGrade
		from
		olresults
		
		LEFT JOIN gceolsubjects
		ON olresults.olSubject=gceolsubjects.gceolSubjectCode
		
		where 
		olResultsId <> 0
		AND olSitting = 1
		AND olresults.epfNo = $epf
		order by olSubjectCountId;
		";
		
		$olresultsSelectQ2 = "SELECT
		olType, olYear, olSitting, olIndexNumber
		from
		olresults
		where 
		olResultsId <> 0
		AND olSitting = 1
		AND olresults.epfNo = $epf;
		";
		
		$olresultsSelectQRes = mysql_query($olresultsSelectQ);
		
		$olresultsSelectQRes2 = mysql_query($olresultsSelectQ2);
		
		if(mysql_num_rows($olresultsSelectQRes) != 0 AND mysql_num_rows($olresultsSelectQRes2) != 0)
		{		
		$olresultsRecords2 = mysql_fetch_array($olresultsSelectQRes2)
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Ordinary Level Results</b><hr></td>
		</tr>
        
		<tr>
		<td height="18">Sitting : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olSitting']=='') echo 'NOT AVAILABLE'; else echo 'First Term';?></td>
		</tr>
        
		<tr>
		<td height="18">Year : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olYear']=='') echo 'NOT AVAILABLE'; else echo $olresultsRecords2['olYear'];?></td>
		</tr>
		
		<tr>
		<td height="18">Index Number : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olIndexNumber']=='' || $olresultsRecords2['olIndexNumber']==0) echo 'NOT AVAILABLE'; 
		else echo $olresultsRecords2['olIndexNumber'];?></td>
		</tr>
        
		<tr>
		<td colspan="4">
		<table width="55%" border="1" >
        
		<tr class="container">
		<td width="8%" >Count</td>
		<td width="82%">Subject</td>
		<td width="10%">Grade</td>
		</tr>
		
		<?php
		while($olresultsRecords = mysql_fetch_array($olresultsSelectQRes))
		{
		if(($olresultsRecords['olSubject']!='') || ($olresultsRecords['olGrade']!=''))
		{
		
		?>
		<tr>
		<td width="8%" ><?php echo $olresultsRecords['olSubjectCountId'];?></td>
		<td width="82%"><?php echo $olresultsRecords['olSubTxt'];?></td>
		<td width="10%"><?php echo $olresultsRecords['olGrade'];?></td>
		</tr>
		
		<?php
		}
		}
		?>
		
		</table>			  
		</td>
		</tr> 
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
		
		<?php
		}
		?>
		
       
        
        				<!-- Ordinary Level Results Second -->
						
						
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$olresultsSelectQ = "SELECT
		olSubjectCountId, olSubject, gceolsubjects.gceolSubjectText as olSubTxt, olGrade
		from
		olresults
		
		LEFT JOIN gceolsubjects
		ON olresults.olSubject=gceolsubjects.gceolSubjectCode
		
		where 
		olResultsId <> 0
		AND olSitting = 2
		AND olresults.epfNo = $epf
		order by olSubjectCountId;
		";
		
		$olresultsSelectQ2 = "SELECT
		olType, olYear, olSitting, olIndexNumber
		from
		olresults
		where 
		olResultsId <> 0
		AND olSitting = 2
		AND olresults.epfNo = $epf;
		";
		
		$olresultsSelectQRes = mysql_query($olresultsSelectQ);
		
		$olresultsSelectQRes2 = mysql_query($olresultsSelectQ2);
		
		if(mysql_num_rows($olresultsSelectQRes) != 0 AND mysql_num_rows($olresultsSelectQRes2) != 0)
		{		
		$olresultsRecords2 = mysql_fetch_array($olresultsSelectQRes2)
		?>
			
        <tr>
		<td height="18">Sitting : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olSitting']=='') echo 'NOT AVAILABLE'; else echo 'Second Term';?></td>
		</tr>
        
		<tr>
		<td height="18">Year : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olYear']=='') echo 'NOT AVAILABLE'; else echo $olresultsRecords2['olYear'];?></td>
		</tr>
		
		<tr>
		<td height="18">Index Number : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olIndexNumber']=='' || $olresultsRecords2['olIndexNumber']==0) echo 'NOT AVAILABLE'; 
		else echo $olresultsRecords2['olIndexNumber'];?></td>
		</tr>
        
		<tr>
		<td colspan="4">
		<table width="55%" border="1" >
        
		
		<tr class="container">
		<td width="8%" >Count</td>
		<td width="82%">Subject</td>
		<td width="10%">Grade</td>
		</tr>
		
		<?php
		while($olresultsRecords = mysql_fetch_array($olresultsSelectQRes))
		{
		if(($olresultsRecords['olSubject']!='') || ($olresultsRecords['olGrade']!=''))
		{
		
		?>
		<tr>
		<td width="8%" ><?php echo $olresultsRecords['olSubjectCountId'];?></td>
		<td width="82%"><?php echo $olresultsRecords['olSubTxt'];?></td>
		<td width="10%"><?php echo $olresultsRecords['olGrade'];?></td>
		</tr>
		
		<?php
		}
		}
		?>
		
		</table>			  
		</td>
		</tr> 
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
		
		<?php
		}
		?>
		
       
        
        				<!-- Ordinary Level Results Thurd -->
						
						
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$olresultsSelectQ = "SELECT
		olSubjectCountId, olSubject, gceolsubjects.gceolSubjectText as olSubTxt, olGrade
		from
		olresults
		
		LEFT JOIN gceolsubjects
		ON olresults.olSubject=gceolsubjects.gceolSubjectCode
		
		where 
		olResultsId <> 0
		AND olSitting = 3
		AND olresults.epfNo = $epf
		order by olSubjectCountId;
		";
		
		$olresultsSelectQ2 = "SELECT
		olType, olYear, olSitting, olIndexNumber
		from
		olresults
		where 
		olResultsId <> 0
		AND olSitting = 3
		AND olresults.epfNo = $epf;
		";
		
		$olresultsSelectQRes = mysql_query($olresultsSelectQ);
		
		$olresultsSelectQRes2 = mysql_query($olresultsSelectQ2);
		
		if(mysql_num_rows($olresultsSelectQRes) != 0 AND mysql_num_rows($olresultsSelectQRes2) != 0)
		{		
		$olresultsRecords2 = mysql_fetch_array($olresultsSelectQRes2)
		?>
		
		<tr>
		<td height="18">Sitting : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olSitting']=='') echo 'NOT AVAILABLE'; else echo 'Thurd Term';?></td>
		</tr>
        
        <tr>
		<td height="18">Year : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olYear']=='') echo 'NOT AVAILABLE'; else echo $olresultsRecords2['olYear'];?></td>
		</tr>
		
		<tr>
		<td height="18">Index Number : </td>
		<td colspan="3" height="18"><?php if($olresultsRecords2['olIndexNumber']=='' || $olresultsRecords2['olIndexNumber']==0) echo 'NOT AVAILABLE'; 
		else echo $olresultsRecords2['olIndexNumber'];?></td>
		</tr>
        
		<tr>
		<td colspan="4">
		<table width="55%" border="1" >
        
		<tr class="container">
		<td width="8%" >Count</td>
		<td width="82%">Subject</td>
		<td width="10%">Grade</td>
		</tr>
		
		<?php
		while($olresultsRecords = mysql_fetch_array($olresultsSelectQRes))
		{
		if(($olresultsRecords['olSubject']!='') || ($olresultsRecords['olGrade']!=''))
		{
		
		?>
		<tr>
		<td width="8%" ><?php echo $olresultsRecords['olSubjectCountId'];?></td>
		<td width="82%"><?php echo $olresultsRecords['olSubTxt'];?></td>
		<td width="10%"><?php echo $olresultsRecords['olGrade'];?></td>
		</tr>
		
		<?php
		}
		}
		?>
		
		</table>			  
		</td>
		</tr> 
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
		
		<?php
		}
		?>
		
       
        
        
        							  
						<!-- Advance Level Results First -->
		
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$alresultsSelectQ = "SELECT
		alSubjectCountId, alSubject, gcealsubjects.gcealText as alSbTxt, alGrade
		from
		alresults
		
		LEFT JOIN gcealsubjects
		ON alresults.alSubject=gcealsubjects.gcealCode
		
		where 
		alresultsId <> 0
		AND alSitting = 1
		AND alresults.epfNo = $epf
		
		order by alSubjectCountId;
		";
		
		$alresultsSelectQ2 = "SELECT
		alYear, alSitting, alIndexNumber, alStream
		from
		alresults
		where 
		alresultsId <> 0
		AND alSitting = 1
		AND alresults.epfNo = $epf;
		";
		
		$alresultsSelectQRes = mysql_query($alresultsSelectQ);
		
		$alresultsSelectQRes2 = mysql_query($alresultsSelectQ2);
		
		if(mysql_num_rows($alresultsSelectQRes) != 0 AND mysql_num_rows($alresultsSelectQRes2) != 0)
		{		
		$degreeInfoRecords2 = mysql_fetch_array($alresultsSelectQRes2)
		?>
		
		
		<tr>
		<td colspan="4" height="26"><hr><b>Advance Level Results</b><hr></td>
		</tr>
		
        
		<tr>
		<td height="18">Sitting : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alSitting']=='') echo 'NOT AVAILABLE'; else echo 'First Term';?></td>
		</tr>
        
        <tr>
		<td height="18">Year : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alYear']=='') echo 'NOT AVAILABLE'; else echo $degreeInfoRecords2['alYear'];?></td>
		</tr>
		
		<tr>
		<td height="18">Index Number : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alIndexNumber']=='' || $alresultsSelectQ2['alIndexNumber']==0) echo 'NOT AVAILABLE'; 
		else echo $degreeInfoRecords2['alIndexNumber'];?></td>
		</tr>
		<tr>
		<td height="18">Stream : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alStream']=='') echo 'NOT AVAILABLE'; else echo $degreeInfoRecords2['alStream'];?></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="55%" border="1" >
		<tr class="container">
		<td width="8%" >Count</td>
		<td width="82%">Subject</td>
		<td width="10%">Grade</td>
		</tr>
		
		<?php
		while($alresultsRecords = mysql_fetch_array($alresultsSelectQRes))
		{
		if(($alresultsRecords['alSubject']!='') || ($alresultsRecords['alGrade']!=''))
		{
		?>
		<tr>
		<td width="8%" ><?php echo $alresultsRecords['alSubjectCountId'];?></td>
		<td width="82%"><?php echo $alresultsRecords['alSbTxt'];?></td>
		<td width="10%"><?php echo $alresultsRecords['alGrade'];?></td>
		</tr>
		
		
		<?php
		}	
		}
		?>
		
		
		</table>			  
		</td>
		</tr> 
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
		
		<?php
		}
		?> 
		

		
		
        
        							  
						<!-- Advance Level Results Second -->
		
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$alresultsSelectQ = "SELECT
		alSubjectCountId, alSubject, gcealsubjects.gcealText as alSbTxt, alGrade
		from
		alresults
		
		LEFT JOIN gcealsubjects
		ON alresults.alSubject=gcealsubjects.gcealCode
		
		where 
		alresultsId <> 0
		AND alSitting = 2
		AND alresults.epfNo = $epf
		
		order by alSubjectCountId;
		";
		
		$alresultsSelectQ2 = "SELECT
		alYear, alSitting, alIndexNumber, alStream
		from
		alresults
		where 
		alresultsId <> 0
		AND alSitting = 2
		AND alresults.epfNo = $epf;
		";
		
		$alresultsSelectQRes = mysql_query($alresultsSelectQ);
		
		$alresultsSelectQRes2 = mysql_query($alresultsSelectQ2);
		
		if(mysql_num_rows($alresultsSelectQRes) != 0 AND mysql_num_rows($alresultsSelectQRes2) != 0)
		{		
		$degreeInfoRecords2 = mysql_fetch_array($alresultsSelectQRes2)
		?>
		
        
		<tr>
		<td height="18">Sitting : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alSitting']=='') echo 'NOT AVAILABLE';  else echo 'Second Term';?></td>
		</tr>
        <tr>
		<td height="18">Year : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alYear']=='') echo 'NOT AVAILABLE'; else echo $degreeInfoRecords2['alYear'];?></td>
		</tr>
		<tr>
		<td height="18">Index Number : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alIndexNumber']=='' || $alresultsSelectQ2['alIndexNumber']==0) echo 'NOT AVAILABLE'; 
		else echo $degreeInfoRecords2['alIndexNumber'];?></td>
		</tr>
		<tr>
		<td height="18">Stream : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alStream']=='') echo 'NOT AVAILABLE'; else echo $degreeInfoRecords2['alStream'];?></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="55%" border="1" >
		<tr class="container">
		<td width="8%" >Count</td>
		<td width="82%">Subject</td>
		<td width="10%">Grade</td>
		</tr>
		
		<?php
		while($alresultsRecords = mysql_fetch_array($alresultsSelectQRes))
		{
		if(($alresultsRecords['alSubject']!='') || ($alresultsRecords['alGrade']!=''))
		{
		?>
		<tr>
		<td width="8%" ><?php echo $alresultsRecords['alSubjectCountId'];?></td>
		<td width="82%"><?php echo $alresultsRecords['alSbTxt'];?></td>
		<td width="10%"><?php echo $alresultsRecords['alGrade'];?></td>
		</tr>
		
		
		<?php
		}	
		}
		?>
		
		
		</table>			  
		</td>
		</tr> 
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
		
		<?php
		}
		?> 
		

		
		
        
        							  
						<!-- Advance Level Results Thurd -->
		
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$alresultsSelectQ = "SELECT
		alSubjectCountId, alSubject, gcealsubjects.gcealText as alSbTxt, alGrade
		from
		alresults
		
		LEFT JOIN gcealsubjects
		ON alresults.alSubject=gcealsubjects.gcealCode
		
		where 
		alresultsId <> 0
		AND alSitting = 3
		AND alresults.epfNo = $epf
		
		order by alSubjectCountId;
		";
		
		$alresultsSelectQ2 = "SELECT
		alYear, alSitting, alIndexNumber, alStream
		from
		alresults
		where 
		alresultsId <> 0
		AND alSitting = 3
		AND alresults.epfNo = $epf;
		";
		
		$alresultsSelectQRes = mysql_query($alresultsSelectQ);
		
		$alresultsSelectQRes2 = mysql_query($alresultsSelectQ2);
		
		if(mysql_num_rows($alresultsSelectQRes) != 0 AND mysql_num_rows($alresultsSelectQRes2) != 0)
		{		
		$degreeInfoRecords2 = mysql_fetch_array($alresultsSelectQRes2)
		?>
		
		
        <tr>
		<td height="18">Sitting : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alSitting']=='') echo 'NOT AVAILABLE';  else echo 'Thurd Term';?></td>
		</tr>
        
		<tr>
		<td height="18">Year : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alYear']=='') echo 'NOT AVAILABLE'; else echo $degreeInfoRecords2['alYear'];?></td>
		</tr>
		
		<tr>
		<td height="18">Index Number : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alIndexNumber']=='' || $alresultsSelectQ2['alIndexNumber']==0) echo 'NOT AVAILABLE'; 
		else echo $degreeInfoRecords2['alIndexNumber'];?></td>
		</tr>
		<tr>
		<td height="18">Stream : </td>
		<td colspan="3" height="18"><?php if($alresultsSelectQ2['alStream']=='') echo 'NOT AVAILABLE'; else echo $degreeInfoRecords2['alStream'];?></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="55%" border="1" >
		<tr class="container">
		<td width="8%" >Count</td>
		<td width="82%">Subject</td>
		<td width="10%">Grade</td>
		</tr>
		
		<?php
		while($alresultsRecords = mysql_fetch_array($alresultsSelectQRes))
		{
		if(($alresultsRecords['alSubject']!='') || ($alresultsRecords['alGrade']!=''))
		{
		?>
		<tr>
		<td width="8%" ><?php echo $alresultsRecords['alSubjectCountId'];?></td>
		<td width="82%"><?php echo $alresultsRecords['alSbTxt'];?></td>
		<td width="10%"><?php echo $alresultsRecords['alGrade'];?></td>
		</tr>
		
		
		<?php
		}	
		}
		?>
		
		
		</table>			  
		</td>
		</tr> 
        
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
		
		<?php
		}
		?> 
		

		
		
		
		
						<!-- Degree Courses -->
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$degreeInfoSelectQ = "SELECT 
		nameofDegree, currentDegreeStatus, nameofUniversity, commencingYear, degreeCommencingDate, degreeDescription, degreeNumber
		from 
		degreeinfo
		where degreeId <> 0 AND degreeinfo.epfNo = $epf;
		";
		
		$degreeInfoSelectQRes = mysql_query($degreeInfoSelectQ);
		
		if(mysql_num_rows($degreeInfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Degree Courses</b><hr></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1" >
		<tr class="container">
		<td width="4%" >Count</td>
		<td width="27%">Name of the Degree </td>
		<td width="15%"><div align="center">Current Status of the Degree </div></td>
		<td width="16%">Name of University </td>
		<td width="8%"><div align="center">Commencing Year</div></td>
		<td width="9%"><div align="center">Commencing Date</div></td>
		<td width="21%">Description </td>
		</tr>
		
		<?php
		
		while($degreeInfoRecords = mysql_fetch_array($degreeInfoSelectQRes))
		{
		
		?>
		<tr>
		<td width="4%" ><?php echo $degreeInfoRecords['degreeNumber'];?></td>
		<td width="27%"><?php echo $degreeInfoRecords['nameofDegree'];?></td>
		<td width="15%"><?php echo $degreeInfoRecords['currentDegreeStatus'];?></td>
		<td width="16%"><?php echo $degreeInfoRecords['nameofUniversity'];?></td>
		<td width="8%"><?php echo $degreeInfoRecords['commencingYear'];?></td>
		<td width="9%"><?php echo $degreeInfoRecords['degreeCommencingDate'];?></td>
		<td width="9%"><?php echo $degreeInfoRecords['degreeDescription'];?></td>
		</tr>
		
		
		<?php
		}
		?>
		
		
		</table>			  
		</td>
		</tr> 
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?> 
		
		
		
		
       
		
					
					<!-- Post Graduate Courses -->
		
		
		
		<?php		
		
		$epf = mysql_real_escape_string($_GET['epf']);			
		$postgraduateinfoSelectQ = "SELECT
		nameofPostGraduate, currentPostGraduateStatus, nameofPGUniversity, pgCommencingYear,
		postGraduateCommencingDate, postGraduateDescription, postGraduateCountId, postGraduateType
		from
		postgraduateinfo
		where postGraduateID <> 0 AND postgraduateinfo.epfNo = $epf;
		";
		
		$postgraduateinfoSelectQRes = mysql_query($postgraduateinfoSelectQ);
		
		if(mysql_num_rows($postgraduateinfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Post Graduate Courses</b><hr></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1" >
		<tr class="container">
		<td width="4%">Count</td>
		<td width="27%">Name of the Post Graduate Course</td>
		<td width="15%"><div align="center">Current Status of the Course</div></td>
		<td width="15%">Name of University</td>
		<td width="8%"><div align="center">Commencing Year</div></td>
		<td width="8%"><div align="center">Commencing Date</div></td>
		<td width="7%"><div align="center">Graduate Type</div></td>
		<td width="16%">Description</td>
		</tr>
		
		<?php
		
		while($postgraduateinfoRecords = mysql_fetch_array($postgraduateinfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $postgraduateinfoRecords['postGraduateCountId'];?></td>
		<td><?php echo $postgraduateinfoRecords['nameofPostGraduate'];?></td>
		<td><?php echo $postgraduateinfoRecords['currentPostGraduateStatus'];?></td>
		<td><?php echo $postgraduateinfoRecords['nameofPGUniversity'];?></td>
		<td><?php echo $postgraduateinfoRecords['pgCommencingYear'];?></td>
		<td><?php echo $postgraduateinfoRecords['postGraduateCommencingDate'];?></td>
		<td><?php echo $postgraduateinfoRecords['postGraduateType'];?></td>
		<td><?php echo $postgraduateinfoRecords['postGraduateDescription'];?></td>
		</tr>
		
		<?php
		}
		?>
		
		
		</table>			  
		</td>
		</tr> 
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
		
		
		
					<!-- Vocational Qualifications -->
					

		
		
					<!-- Certificate Courses & Diploma -->
		
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$certificateDiplomaInfoQ = "SELECT
		nameofCertificateDiploma, offerdInstitute, completedYear, 
		courseDiplomaDuration, completedDate, courseOrDiploma, courseDiplomaNumber, courseDiplomaDescription
		from
		certificatediplomainfo
		WHERE
		certificateDiplomaInfoID <> 0
		AND certificatediplomainfo.epfNo=$epf;
		";
		
		$certificateDiplomaInfoQRes = mysql_query($certificateDiplomaInfoQ);
		
		
		if(mysql_num_rows($certificateDiplomaInfoQRes) != 0)
		{
		
		?>
		
		
		<tr>
		<td colspan="4" height="26"><hr><b>Certificate Courses & Diploma</b><hr></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="25%">Name of the Diploma</td>
		<td width="20%">Institute</td>
		<td width="6%"><div align="center">Completed Year</div></td>
		<td width="7%"><div align="center">Completed Date</div></td>
		<td width="15%">Duration</td>
		<td width="10%"><div align="center">Certificate Courses Or Diploma</div></td>
		<td width="13%">Description</td>
		</tr>
		
		
		<?php
		
		while($certificateDiplomaInfoRecords = mysql_fetch_array($certificateDiplomaInfoQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $certificateDiplomaInfoRecords['courseDiplomaNumber'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['nameofCertificateDiploma'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['offerdInstitute'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['completedYear'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['completedDate'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['courseDiplomaDuration'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['courseOrDiploma'];?></td>
		<td><?php echo $certificateDiplomaInfoRecords['courseDiplomaDescription'];?></td>
		</tr>
		
		<?php
		}
		?>
		
		</table>				
		</td>
		</tr>
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>			
		
		
        
        
        
		
					<!-- Examinations Passed -->
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$ExamPassedSelectQ = "SELECT examCountId,examName,institute,examYear,description from exampassed WHERE
		exampassedId <> 0
		AND exampassed.epfNo=$epf;
		";
		
		$ExamPassedSelectQRes = mysql_query($ExamPassedSelectQ);
		
		
		if(mysql_num_rows($ExamPassedSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Examinations Passed</b><hr></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%" >Count</td>
		<td width="25%" >Name </td>
		<td width="31%">Institute </td>
		<td width="11%">Completed Year </td>
		<td width="29%">Discription </td>
		</tr>
		<?php
		
		while($ExamPassedRecords = mysql_fetch_array($ExamPassedSelectQRes))
		{
		
		?>
		<tr>
		<td width="3%" ><?php echo  $ExamPassedRecords['examCountId'] ;?></td>
		<td width="30%" ><?php echo  $ExamPassedRecords['examName'] ;?></td>
		<td width="27%"><?php echo  $ExamPassedRecords['institute'] ;?></td>
		<td width="11%"><?php echo  $ExamPassedRecords['examYear'] ;?></td>
		<td width="29%"><?php echo  $ExamPassedRecords['description'] ;?></td>
		</tr>
		
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
        
		<?php
		}
		?>
		
		
        
		
					<!-- Training Courses -->
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$traininginfoSelectQ = "select
		trainingInfoId, epfNo, trainingCountId, trainingCourseName, instituteName, countryName, period, discription
		from
		traininginfo WHERE
		trainingInfoId <> 0
		AND traininginfo.epfNo=$epf;
		";
		
		$traininginfoSelectQRes = mysql_query($traininginfoSelectQ);
		
		
		if(mysql_num_rows($traininginfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Training Courses</b><hr></td>
		</tr>
        
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="29%">Name</td>
		<td width="25%">Institute</td>
		<td width="14%">Country</td>
		<td width="9%">Period</td>
		<td width="19%">Description</td>
		</tr>
		
		<?php
		
		while($traininginfoRecords = mysql_fetch_array($traininginfoSelectQRes))
		{
		
		?>
			
		<tr>
		<td><?php echo $traininginfoRecords['trainingCountId'];?></td>
		<td><?php echo $traininginfoRecords['trainingCourseName'];?></td>
		<td><?php echo $traininginfoRecords['instituteName'];?></td>
		<td><?php echo $traininginfoRecords['countryName'];?></td>
		<td><?php echo $traininginfoRecords['period'];?></td>
		<td><?php echo $traininginfoRecords['discription'];?></td>
		</tr>
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
		<tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
        
        
        
						<!-- Institutions where hold membership -->
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$membershipinfoSelectQ = "SELECT
		membershipCountId, instituteName, membershipType, startYear, description
		from membershipinfo WHERE
		membershipInfoId <> 0
		AND membershipinfo.epfNo=$epf;
		";
		
		$membershipinfoSelectQRes = mysql_query($membershipinfoSelectQ);
		
		
		if(mysql_num_rows($membershipinfoSelectQRes) != 0)
		{
		
		?>
		
		
		<tr>
		<td colspan="4" height="26"><hr><b>Institutions where hold membership</b><hr></td>
		</tr>
        			  
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="36%">Name of the Institute</td>
		<td width="12%">Membership Type</td>
		<td width="9%">Started Year</td>
		<td width="39%">Description</td>
		</tr>
		
		<?php
		
		while($membershipinfoRecords = mysql_fetch_array($membershipinfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $membershipinfoRecords['membershipCountId'];?></td>
		<td><?php echo $membershipinfoRecords['instituteName'];?></td>
		<td><?php echo $membershipinfoRecords['membershipType'];?></td>
		<td><?php echo $membershipinfoRecords['startYear'];?></td>
		<td><?php echo $membershipinfoRecords['description'];?></td>
		</tr>
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
		
        
		
					<!-- Details of workshop/conference attend -->
		
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$workshopconferenceinfoSelectQ = "SELECT
		workshopConferenceInfoId, epfNo, workshopCountId, workshopName, 
		institute, workshopDate, duration, country, description
		from
		workshopconferenceinfo WHERE
		workshopConferenceInfoId <> 0
		AND workshopconferenceinfo.epfNo=$epf;
		";
		
		$workshopconferenceinfoSelectQRes = mysql_query($workshopconferenceinfoSelectQ);

																					
		if(mysql_num_rows($workshopconferenceinfoSelectQRes) != 0)
		{
		
		?>		
		
		<tr>
		<td colspan="4" height="26"><hr><b>Details of workshop/conference attend</b><hr></td>
		</tr>
        			  
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="25%">Name of the workshop/conference</td>
		<td width="21%">Institute</td>
		<td width="8%">Date</td>
		<td width="9%">Duration</td>
		<td width="13%">Country</td>
		<td width="20%">Discription</td>
		</tr>
		
		<?php
		
		while($workshopconferenceinfoRecords = mysql_fetch_array($workshopconferenceinfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $workshopconferenceinfoRecords['workshopCountId'];?></td>
		<td><?php echo $workshopconferenceinfoRecords['workshopName'];?></td>
		<td><?php echo $workshopconferenceinfoRecords['institute'];?></td>
		<td><?php echo $workshopconferenceinfoRecords['workshopDate'];?></td>
		<td><?php echo $workshopconferenceinfoRecords['duration'];?></td>
		<td><?php echo $workshopconferenceinfoRecords['country'];?></td>
		<td><?php echo $workshopconferenceinfoRecords['description'];?></td>
		</tr>
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
		
		
					<!-- Details of Previous employing -->
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$previousworkinfoSelectQ = "SELECT
		preWorkCountId, depCorpName, designation, grade, periodFromDate, 
		periodToDate, serviceYears, serviceMonths, discription
		FROM
		previousworkinfo WHERE
		previousWorkInfoId <> 0
		AND previousworkinfo.epfNo=$epf;
		";
		
		$previousworkinfoSelectQRes = mysql_query($previousworkinfoSelectQ);
		
		
		if(mysql_num_rows($previousworkinfoSelectQRes) != 0)
		{
		
		?>
		
		
		<tr>
		<td colspan="4" height="26"><hr><b>Details of Previous employing</b><hr></td>
		</tr>	
        		  
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="27%">Name of the Corporation/Department</td>
		<td width="20%">Designation</td>
		<td width="9%"><div align="center">Work started date</div></td>
		<td width="9%"><div align="center">Work ended date</div></td>
		<td width="5%"><div align="center">Service Years</div></td>
		<td width="5%"><div align="center">Service Months</div></td>
		<td width="21%">Discription</td>
		</tr>
		
		<?php
		
		while($previousworkinfoRecords = mysql_fetch_array($previousworkinfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $previousworkinfoRecords['preWorkCountId'];?></td>
		<td><?php echo $previousworkinfoRecords['depCorpName'];?></td>
		<td><?php echo $previousworkinfoRecords['designation'];?></td>
		<td><?php echo $previousworkinfoRecords['periodFromDate'];?></td>
		<td><?php echo $previousworkinfoRecords['periodToDate'];?></td>
		<td><?php echo $previousworkinfoRecords['serviceYears'];?></td>
		<td><?php echo $previousworkinfoRecords['serviceMonths'];?></td>
		<td><?php echo $previousworkinfoRecords['discription'];?></td>
		</tr>
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
		
        
        
		
					<!--   Leave Informations -->
		
		
	
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$nopayleaveinfoSelectQ = "SELECT
		leaveCountId, leaveFromDate, leaveToDate, reason, description
		FROM
		nopayleaveinfo WHERE
		noPayLeaveInfoId <> 0
		AND nopayleaveinfo.epfNo=$epf;
		";
		
		$nopayleaveinfoSelectQRes = mysql_query($nopayleaveinfoSelectQ);
		
		
		if(mysql_num_rows($nopayleaveinfoSelectQRes) != 0)
		{
		
		?>		
		
		
		
		<tr>
		<td colspan="4" height="26"><hr><b>No Pay Leaves</b><hr></td>
		</tr>		
        	  
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="12%">No Pay From</td>
		<td width="12%">No Pay To</td>
		<td width="49%">Reason</td>
		<td width="23%">Discription</td>
		</tr>
		
		<?php
		
		while($nopayleaveinfoRecords = mysql_fetch_array($nopayleaveinfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $nopayleaveinfoRecords['leaveCountId'];?></td>
		<td><?php echo $nopayleaveinfoRecords['leaveFromDate'];?></td>
		<td><?php echo $nopayleaveinfoRecords['leaveToDate'];?></td>
		<td><?php echo $nopayleaveinfoRecords['reason'];?></td>
		<td><?php echo $nopayleaveinfoRecords['description'];?></td>
		</tr>
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
        <tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>	  
	
    	
	
					
                    
                    <!--   Injury & Accident Information -->
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$injuryaccidentinfoSelectQ = "SELECT
		typeOfInjury, injuryCountId, injuryDate, compensationAmount, details
		from
		injuryaccidentinfo WHERE
		injuryAccidentInfoId <> 0
		AND injuryaccidentinfo.epfNo=$epf;
		";
		
		$injuryaccidentinfoSelectQRes = mysql_query($injuryaccidentinfoSelectQ);
		
		
		if(mysql_num_rows($injuryaccidentinfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Injury & Accident Information</b><hr></td>
		</tr>
					  
		<tr>
		<td colspan="4">
        
		<table width="100%" border="1">
		<tr class="container">
		<td width="3%">Count</td>
		<td width="39%">Type Of Injury</td>
		<td width="9%">Injury Date</td>
		<td width="15%">Compensation Amount</td>
		<td width="34%">Discription</td>
		</tr>
		
		<?php
		
		while($injuryaccidentinfoRecords = mysql_fetch_array($injuryaccidentinfoSelectQRes))
		{
		
		?>
		<tr>
		<td><?php echo $injuryaccidentinfoRecords['injuryCountId'];?></td>
		<td><?php echo $injuryaccidentinfoRecords['typeOfInjury'];?></td>
		<td><?php echo $injuryaccidentinfoRecords['injuryDate'];?></td>
		<td><?php echo $injuryaccidentinfoRecords['compensationAmount'];?></td>
		<td><?php echo $injuryaccidentinfoRecords['details'];?></td>
		</tr>
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
		<tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
        
        
					<!--   Disciplinary Action Information -->
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$ctioninfoSelectQ = "SELECT
		actionCountId, disciplineAction, actionFromDate, actionToDate, 
		actionDetails
		from
		disciplineactioninfo WHERE
		disciplineactioninfoId <> 0
		AND disciplineactioninfo.epfNo=$epf;
		";
		
		$ctioninfoSelectQRes = mysql_query($ctioninfoSelectQ);
		
		
		if(mysql_num_rows($ctioninfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Disciplinary Action Information</b><hr></td>
		</tr>	
				  
		<tr>
		<td colspan="4">
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="42%">Disciplinary Action Type</td>
		<td width="10%">Action From Date</td>
		<td width="8%">Action To Date</td>
		<td width="36%">Discription</td>
		</tr>
		
		<?php
		
		while($ctioninfoRecords = mysql_fetch_array($ctioninfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $ctioninfoRecords['actionCountId'];?></td>
		<td><?php echo $ctioninfoRecords['disciplineAction'];?></td>
		<td><?php echo $ctioninfoRecords['actionFromDate'];?></td>
		<td><?php echo $ctioninfoRecords['actionToDate'];?></td>
		<td><?php echo $ctioninfoRecords['actionDetails'];?></td>
		</tr>
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
		<tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
        
        
		
					<!--   Maternity Leave Information -->
					
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$maternityleaveinfoSelectQ = "SELECT
		maternityCountId, paidLeaveDateFrom, paidLeaveDateTo, 
		halfPaidLeaveDateFrom, halfPaidLeaveDateTo, noPaidLeaveDateFrom,
		noPaidLeaveDateTo, description
		from
		maternityleaveinfo WHERE
		maternityLeaveId <> 0
		AND maternityleaveinfo.epfNo=$epf;
		";
		
		$maternityleaveinfoSelectQRes = mysql_query($maternityleaveinfoSelectQ);
		
		
		if(mysql_num_rows($maternityleaveinfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Maternity Action Information</b><hr></td>
		</tr>	
					  
		<tr>
		<td colspan="4">
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="12%">Paid Leave Date From</td>
		<td width="12%">Paid Leave Date To</td>
		<td width="14%">Half Paid Leave Date From</td>
		<td width="13%">Half Paid Leave Date To</td>
		<td width="13%">No Paid Leave Date To</td>
		<td width="15%">No Paid Leave Date From</td>
		<td width="17%">Discription</td>
		</tr>
		
		<?php
		
		while($maternityleaveinfoRecords = mysql_fetch_array($maternityleaveinfoSelectQRes))
		{
		
		?>
		<tr>
		<td><?php echo $maternityleaveinfoRecords['maternityCountId'];?></td>
		<td><?php echo $maternityleaveinfoRecords['paidLeaveDateFrom'];?></td>
		<td><?php echo $maternityleaveinfoRecords['paidLeaveDateTo'];?></td>
		<td><?php echo $maternityleaveinfoRecords['halfPaidLeaveDateFrom'];?></td>
		<td><?php echo $maternityleaveinfoRecords['halfPaidLeaveDateTo'];?></td>
		<td><?php echo $maternityleaveinfoRecords['noPaidLeaveDateFrom'];?></td>
		<td><?php echo $maternityleaveinfoRecords['noPaidLeaveDateTo'];?></td>
		<td><?php echo $maternityleaveinfoRecords['description'];?></td>
		</tr>
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
		<tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
        
		
		
						<!--   Loan Information -->
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$loaninfoSelectQ = "SELECT
		loanCountId, loanType, `loans`.`loanText` AS lnText, loanNumber, 
		loanAmount, loanDate, guarantor1, guarantor1Epf, guarantor2, 
		guarantor2Epf, discription
		from
		loaninfo 
				
		LEFT JOIN `loans`
		ON `loaninfo`.`loanType` = `loans`.`loanCode`
		
		WHERE
		loanInfoId <> 0
		AND loaninfo.epfNo=$epf;
		";
		
		$loaninfoSelectQRes = mysql_query($loaninfoSelectQ);
		
		
		if(mysql_num_rows($loaninfoSelectQRes) != 0)
		{
		
		?>
		<tr>
		<td colspan="4" height="26"><hr><b>Loan Information</b><hr></td>
		</tr>
		<tr>
		<td colspan="4">
		<table width="100%" border="1">
		<tr class="container">
		<td width="3%">Count</td>
		<td width="17%">Loan Type</td>
		<td width="7%">Loan Number</td>
		<td width="7%">Loan Amount</td>
		<td width="7%">Loan Date</td>
		<td width="15%">Name of the first Guarantor</td>
		<td width="6%"><div align="center">Epf of the first Guarantor</div></td>
		<td width="16%">Name of the second Guarantor</td>
		<td width="6%"><div align="center">Epf of the second Guarantor</div></td>
		<td width="16%">Discription</td>
		</tr>
		
		<?php
		
		while($loaninfoRecords = mysql_fetch_array($loaninfoSelectQRes))
		{
		
		?>
		<tr>
		<td><?php echo $loaninfoRecords['loanCountId'];?></td>
		<td><?php echo $loaninfoRecords['lnText'];?></td>
		<td><?php echo $loaninfoRecords['loanNumber'];?></td>
		<td><?php echo $loaninfoRecords['loanAmount'];?></td>
		<td><?php echo $loaninfoRecords['loanDate'];?></td>
		<td><?php echo $loaninfoRecords['guarantor1'];?></td>
		<td><?php echo $loaninfoRecords['guarantor1Epf'];?></td>
		<td><?php echo $loaninfoRecords['guarantor2'];?></td>
		<td><?php echo $loaninfoRecords['guarantor2Epf'];?></td>
		<td><?php echo $loaninfoRecords['discription'];?></td>
		</tr>
		
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
        
		<tr>
		<td height="18" colspan="4"></td>
		</tr>
        
		<?php
		}
		?>
		
		
		
						<!--   Bank Information -->
		
		
		
		<?php
		
		$epf = mysql_real_escape_string($_GET['epf']);
		
		$bankinfoSelectQ = "SELECT
		bankCountId, bankName, branchName, branchCode, accountNumber
		from
		bankinfo 
		WHERE
		bankInfoId <> 0
		AND bankinfo.epfNo=$epf;
		";
		
		$bankinfoSelectQRes = mysql_query($bankinfoSelectQ);
		
		
		if(mysql_num_rows($bankinfoSelectQRes) != 0)
		{
		
		?>
		
		<tr>
		<td colspan="4" height="26"><hr><b>Details About The Bank</b><hr></td>
		</tr>
		<tr>
		<td colspan="4">
		<table width="100%" border="1">
		<tr class="container">
		<td width="4%">Count</td>
		<td width="26%">Name of the Bank</td>
		<td width="25%">Name of the Branch</td>
		<td width="24%">Code of the Branch</td>
		<td width="21%">Account Number</td>
		</tr>
		
		<?php
		
		while($bankinfoRecords = mysql_fetch_array($bankinfoSelectQRes))
		{
		
		?>
		
		<tr>
		<td><?php echo $bankinfoRecords['bankCountId'];?></td>
		<td><?php echo $bankinfoRecords['bankName'];?></td>
		<td><?php echo $bankinfoRecords['branchName'];?></td>
		<td><?php echo $bankinfoRecords['branchCode'];?></td>
		<td><?php echo $bankinfoRecords['accountNumber'];?></td>
		</tr>
		<?php
		}
		?>
		</table>	  	   
		</td>
		</tr>
		
		<?php
		}
		?>
			
		
			
	
	
	</table>
			
			
			
		
			
			
	</body>
			
			

			
			
	</html>
