<?php
	error_reporting(0); 
include('../db-config.php');

$timezone_offset = +5.5; // us central time (gmt-6) for me
$date = gmdate('d-m-Y ,h.i a ', time()+$timezone_offset*60*60);
$datee = gmdate('MdYhia', time()+$timezone_offset*60*60);
$date2 = gmdate('Y/m/d', time()+$timezone_offset*60*60);//like --- 2011/03/12 --
$ip=$_SERVER['REMOTE_ADDR'];

$reigon=$_GET['reigon'];
$depot=$_GET['depot'];
$reason=$_GET['reason'];
$nopay=$_GET['nopay'];
$remark=mysql_real_escape_string($_GET['remark']);
//$theDate2=mysql_real_escape_string($_POST['theDate2']);
//$reason=mysql_real_escape_string($_POST['reason']);
//$remark=mysql_real_escape_string($_POST['remark']);
	
$rand=rand(1,100000000);
//$username=$_SESSION['user_name'];
	

	  
	  //no pay leave times
		$viewcount=mysql_query("SELECT leaveCountId FROM  nopayleaveinfo WHERE epfNo='".$epf."' ORDER BY leaveCountId DESC LIMIT 1") or die("SELECT ERROR:".mysql_error());
		
		$viewcount_info=mysql_fetch_array($viewcount);
		//$dateviewcount=$viewcount_info['ho_date'];
		$downloadc=$viewcount_info['leaveCountId'];

		$downloadc=++$downloadc;

	//$insertreg=mysql_query("UPDATE nopayleaveinfo SET reason='$reason'  WHERE noPayLeaveInfoId='236' ") or die ("insert error".mysql_error());
	
		$insertreg=mysql_query("INSERT INTO nopayleaveinfo (leaveCount,reason,description,leaveCountId) VALUES ('$nopay','$reigon','$depot','$downloadc')") or die ("insert error".mysql_error());
		
								echo "sucsessfull";

	  
?>