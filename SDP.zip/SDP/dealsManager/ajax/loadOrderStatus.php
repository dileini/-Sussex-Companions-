<?php
session_start();
require_once('../db_connector.php');

$fromDate	= mysql_real_escape_string($_POST ['fromDate']);
$toDate		= mysql_real_escape_string($_POST ['toDate']);
$job		= mysql_real_escape_string($_POST ['job']);

$query = "SELECT `id`, `user_id`, `firstName`, `lastName`, `email`, `current_status`
			FROM `order_head` WHERE `id` <>0 ";

if($fromDate != "" and $toDate != ""){
	$query = $query. " AND DATE(`ordere_date`) BETWEEN  DATE('". $fromDate ."') and DATE('".$toDate."') ";
}

if($fromDate != "" and $toDate == ""){
	$query = $query. " AND DATE(`ordere_date`) = DATE('".$fromDate."') ";
}

if($fromDate == "" and $toDate != ""){
	$query = $query. " AND DATE(`ordere_date`) = DATE('".$toDate."') ";
}

if($job != "0"){
	$query = $query. " AND `current_status`='".$job."'";
}

$res = mysql_query($query);


if(mysql_num_rows($res) == 0){
	echo 'No records found';
}

else{
	?>
<div id="print_div" class="page" style="background-color:#ccc">

<div id="divPrintReportHead2">
<CENTER><h2> Current Statust of the Order Report </h2> <?php echo date("Y/m/d");?></CENTER><br>
</div>

<div id="divPrintReportBody2">		
	
<table width="90%" border="1">
  <tr>
    <th scope="col">No</th>
    <th scope="col">Order No</th>
    <th scope="col">User Id</th>
    <th scope="col">First Name </th>
    <th scope="col">Last Name</th>
    <th scope="col">E-mail</th>
    <th scope="col">Current Statust of the Order</th>
  </tr>
	
	<?php
	$count = 1;
	while($row = mysql_fetch_array($res)){
		?>
<tr>
    <th scope="row"><?php echo $count; ?></th>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['user_id']; ?></td>
    <td><?php echo $row['firstName']; ?></td>
    <td><?php echo $row['lastName']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['current_status']; ?></td>
</tr>
		<?php
		$count++;
	}
	
	?>
	</table>
</div>
</div>
</br>
<input type="button" name = "btn_Print" value="Print Report" 
onclick="javascript:printContent('divPrintReportHead2','divPrintReportBody2','A4');" id="btn_Print" 
style="width:160px; height:25px; margin:0px; background-color:#6BAAF8; border-radius: 3px; border: 2px solid gray;"/>
 
	<?php
}























?>