<?php
session_start();
require_once('../db_connector.php');

$id = $_POST['client'];
$mytime = time();
$filePath = 'frontImage/default.jpg';

$selectFileForDelete = "SELECT `event_pic` FROM `event` WHERE `event_id`=$id";
$selectFileForDeleteRes = mysql_query($selectFileForDelete);
$delImageName = '';


if(mysql_num_rows($selectFileForDeleteRes) == 1)
{
	while($deleteFileName = mysql_fetch_array($selectFileForDeleteRes))
	{
		$delImageName = $deleteFileName['event_pic'];
	}
}



$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);

if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts)) 
{
  if ($_FILES["file"]["error"] > 0) 
  {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
  } 
	  else 
	  {
		  	if($delImageName !='default.jpg')
			{
				$filename = "../../images/".$delImageName;
				
				if (file_exists($filename)) 
				{
				    unlink($filename);
				}
			}
			 if (file_exists("../../images/$mytime".'-'."$id" . $_FILES["file"]["name"])) 
			 {
			  echo $_FILES["file"]["name"] . " already exists. ";
			 } 
				 else 
				 {
			      move_uploaded_file($_FILES["file"]["tmp_name"], "../../images/$mytime".'-'."$id" . $_FILES["file"]["name"]);
				  $filePath = '/'.$mytime.'-'.$id.$_FILES["file"]["name"];
				  $imageUpdateQ = "UPDATE `event` SET `event_pic`='$filePath' WHERE `event_id`=$id";
				  $result = mysql_query($imageUpdateQ);
				  header('Location: ../addImageEvent.php');
				  
			     }
	  }
} 
	else 
	{
	  echo "Invalid file";
	}



?>