<?php
session_start();
require_once('../db_connector.php');
$id = $_SESSION['user_id'];


$query = "select region.regionText,region.regionCode 
 from region 
 left join region_auth on 
 region_auth.region_id = region.region_id 
 LEFT JOIN users on users.user_id = region_auth.user_id 
 where users.user_id=$id";

$change = $_GET['change'];

if($change != "")
{
	$query = "select `regionText`,`regionCode` FROM region ORDER BY `regionId`";
}


$optionString = "";
$mainQuery2  = $query;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['regionCode'].'"'.">".$ro['regionText']."</option>";
 }


echo $optionString;

?>