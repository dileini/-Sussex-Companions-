<?php
session_start();
require_once('../db_connector.php');

$cato	  = mysql_real_escape_string($_POST ['job']);
$product = mysql_real_escape_string($_POST ['product']);
$toDate  = mysql_real_escape_string($_POST ['toDate']);
$fromDate= mysql_real_escape_string($_POST ['fromDate']);
$profit  = 0.00;
$totlaProfit = 0.00;
$grandTot = 0.00;

$query = "select `order_head`.`id` as invoce_no, `odr_date`, `item_id`, `order_items`.`total_price` as tot,  `unit_price`, `qty`, `productTitle`, `buyingRate`
from `order_head`, `order_items`, `products`
where `order_head`.id = `order_items`.`head_id` and `order_items`.`item_id`=`products`.`productID` ";

if($cato != '0'){
	$query = $query. " and `catoID`= $cato";
}

if($product != '0'){
	$query = $query. " and  `productID` = $product";
}


if($fromDate != "" and $toDate != ""){
	$query = $query. " AND DATE(`odr_date`) BETWEEN  DATE('". $fromDate ."') and DATE('".$toDate."') ";
}

if($fromDate != "" and $toDate == ""){
	$query = $query. " AND DATE(`odr_date`) = DATE('".$fromDate."') ";
}

if($fromDate == "" and $toDate != ""){
	$query = $query. " AND DATE(`odr_date`) = DATE('".$toDate."') ";
}

$res   = mysql_query($query);

if(mysql_num_rows($res) != 0){
	?>
<table width="85%" border="1">
  <tr>
    <th scope="col">#</th>
    <th scope="col">Invoice No</th>
    <th scope="col">Order Date</th>
    <th scope="col">Item ID</th>
    <th scope="col">Item Name</th>
    <th scope="col">Unit Price</th>
    <th scope="col">QTY</th>
    <th scope="col">Total</th>
    <th scope="col">Profit form Single Item</th>
    <th scope="col">Total Profit</th>
  </tr>
	<?php
	$count = 1;
	while($row = mysql_fetch_array($res)){
		$profit      = $row['unit_price'] - $row['buyingRate'];
		$totlaProfit = $profit *  $row['qty'];
		$grandTot = $grandTot + $totlaProfit;
		
		?>
 <tr>
    <th scope="row"><?php echo $count; ?></th>
    <td><?php echo $row['invoce_no']; ?></td>
    <td><?php echo $row['odr_date']; ?></td>
    <td><?php echo $row['item_id']; ?></td>
    <td><?php echo $row['productTitle']; ?></td>
    <td><?php echo $row['unit_price']; ?></td>
    <td><?php echo $row['qty']; ?></td>
    <td><?php echo $row['tot'];?></td>
    <td><?php echo $profit;?></td>
    <td><?php echo $totlaProfit;?></td>
  </tr>
 
		<?php
	$count++;
	}
	?>
    <tr>
   <th colspan="9" align="right" scope="row">Total Profit</th>
   <td><?php echo $grandTot;?></td>
 </tr>
</table>
	<?php
}

?>