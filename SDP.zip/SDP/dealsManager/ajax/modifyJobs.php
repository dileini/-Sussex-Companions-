<?php
session_start();
require_once('../db_connector.php');

//$maxUserID = "";

// getting the data from the url
//$catoText     = mysql_real_escape_string($_POST ['catoText']);
//$catoCode     = mysql_real_escape_string($_POST ['catoCode']);
$id			  = mysql_real_escape_string($_POST ['id']);


$catoCode      = mysql_real_escape_string($_POST ['catoCode']);
$catoText      = mysql_real_escape_string($_POST ['catoText']);
$jobTitle      = mysql_real_escape_string($_POST ['jobTitle']);
$JobDesc       = mysql_real_escape_string($_POST ['JobDesc']);
$jobOpenDate   = mysql_real_escape_string($_POST ['jobOpenDate']);
$jobCloseDate  = mysql_real_escape_string($_POST ['jobCloseDate']);
$companyName   = mysql_real_escape_string($_POST ['companyName']);
$noPoss        = mysql_real_escape_string($_POST ['noPoss']);
$jobCatID      = mysql_real_escape_string($_POST ['jobCatID']);






$selectQ = "SELECT * FROM `jobs` where `jobid`=$id";
$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) != 0)
{
//no recores.
//	echo('1');





 	$updateData = "UPDATE `jobs` SET  
										`jobTitle`='$jobTitle', 
										`jobidTxt`='$jobTitle', 
										`jobdescription`='$JobDesc', 
										`jobOpenDate`='$jobOpenDate', 
										`jobCloseDate`='$jobCloseDate', 
										`jobOffercompanyID`='$companyName', 
										`numberofpossitions`=$noPoss, 
										`jobCatid`=$jobCatID 
										 WHERE `jobid`=$id";
	mysql_query($updateData);
	
	if(mysql_affected_rows() > 0)
	{
		//sucess
		echo('1');
	}
	
	else
	{
		//update problem
		echo('2');
	}
}

else 
{
	//3 - No recod found
	echo('3');
}

?>