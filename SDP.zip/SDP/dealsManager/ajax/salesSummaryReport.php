<?php
session_start();
require_once('../db_connector.php');

$totalProductSale = 0.00;
$totalShipping    = 0.00;
$totalTotal       = 0.00;
$toDate  = mysql_real_escape_string($_POST ['toDate']);
$fromDate= mysql_real_escape_string($_POST ['fromDate']);

$query = "SELECT `id`, `ordere_date`, `product_cost`, `shipping`, `total_price`,`odr_date`, `firstName`, `lastName` 
FROM `order_head` where `id`<>0 ";

if($fromDate != "" and $toDate != ""){
	$query = $query. " AND DATE(`odr_date`) BETWEEN  DATE('". $fromDate ."') and DATE('".$toDate."') ";
}

if($fromDate != "" and $toDate == ""){
	$query = $query. " AND DATE(`odr_date`) = DATE('".$fromDate."') ";
}

if($fromDate == "" and $toDate != ""){
	$query = $query. " AND DATE(`odr_date`) = DATE('".$toDate."') ";
}
$res   = mysql_query($query);

if(mysql_num_rows($res) != 0){
	?>
<table width="80%" border="1">
  <tr>
    <th scope="col">#</th>
    <th scope="col">Invoice No</th>
    <th scope="col">Order Date</th>
    <th scope="col">Product Sale Price</th>
    <th scope="col">Shipping</th>
    <th scope="col">Total Price</th>
    <th scope="col">Customer Fitst name</th>
    <th scope="col">Customer Last name</th>
  </tr>
	<?php
	$count = 1;
	while($row = mysql_fetch_array($res)){
		
		?>
 <tr>
    <th scope="row"><?php echo $count; ?></th>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['odr_date']; ?></td>
    <td align="right"><?php echo $row['product_cost']; ?></td>
    <td align="right"><?php echo $row['shipping']; ?></td>
    <td align="right"><?php echo $row['total_price']; ?></td>
    <td><?php echo $row['firstName']; ?></td>
    <td><?php echo $row['lastName'];?></td>
  </tr>
 
		<?php
	$count++;
	$totalProductSale = $totalProductSale + $row['product_cost'];
	$totalShipping    = $totalShipping + $row['shipping'];
	$totalTotal       = $totalTotal + $row['total_price'];
	}
	?>
    <tr>
   <th colspan="3" scope="row" align="right">Total</th>
   <td align="right"><?php echo number_format($totalProductSale, 2);?></td>
   <td align="right"><?php echo number_format($totalShipping, 2);?></td>
   <td align="right"><?php echo number_format($totalTotal, 2);?></td>
   <td>&nbsp;</td>
   <td>&nbsp;</td>
 </tr>
</table>
	<?php
}

?>