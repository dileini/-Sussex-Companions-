<?php
session_start();
require_once('../db_connector.php');

$myUser = $_SESSION['user_id'];
$maxUserID = "";

// getting the data from the url
$event_id     = mysql_real_escape_string($_POST ['event_id']);
$event_title  = mysql_real_escape_string($_POST ['event_title']);
$event_cost   = mysql_real_escape_string($_POST ['event_cost']);
$event_date   = mysql_real_escape_string($_POST ['event_date']);
$event_time   = mysql_real_escape_string($_POST ['event_time']);
$event_per_head_cost = mysql_real_escape_string($_POST ['event_per_head_cost']);


$updateQuery = "UPDATE `event` SET `event_title`='$event_title', `event_cost`=$event_cost, `event_date`='$event_date', `event_time`='$event_time', `event_per_head_cost`=$event_per_head_cost
WHERE `event_id`=$event_id";

//echo($updateQuery);

mysql_query($updateQuery);

	//echo $insertQuery;
	
	if(mysql_affected_rows()!= 0)
	{
		//2 - no records added.
		echo('1');
	}
	
	else
	{
		//3 - success full..
		echo('2');
	}	

?>