<?php
session_start();
require_once('../db_connector.php');


$maxUserID = "";

// getting the data from the url
//$catoText     = mysql_real_escape_string($_POST ['catoText']);
//$catoCode     = $_POST ['catoCode'];


$selectQ = "SELECT 
`productID`, `catoID`, `productTitle`, `offPresent`, `originalPrice`, `discountAmnt`, `saveAmt`, `newAmnt`, `homepageImage`, 
`productDesc`, `itemOrder`, `productAddDate`, `productEndDate`, `availableProductsQTY`, productEnableDesable, 
`catoCode`, `catoText`, `soteF`, `reorder_level`
FROM `products` 
LEFT JOIN `jobcats` ON `jobcats`.`id`= `products`.`catoID` order by soteF, productID DESC";
$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else 
{
	//1 - catgory or category text available
	
	?>
<div id="print_div" class="page" style="background-color:#ccc">

<div id="divPrintReportHead2">
<CENTER><h2> Reorder Level of Stock </h2> <?php echo date("Y/m/d");?></CENTER><br>
</div>

<div id="divPrintReportBody2">


<table width="100%" border="1" cellspacing="1">
  <tr>
    <td width="6%"><em><strong>Count</strong></em></td>
    <td width="4%"><em><strong>#</strong></em></td>
    <td width="12%"><em><strong>Category</strong></em></td>
    <td width="15%"><em><strong>Product Name</strong></em></td>
    <td width="11%"><em><strong>Closing Date</strong></em></td>
    <td width="9%"><em><strong>Avable QTY</strong></em></td>
    <td width="8%"><em><strong>Reorder Level</strong></em></td>
    <td width="8%">&nbsp;</td>
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
		
	
	?>
  <tr align="left" valign="top" class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['productID']);?></td>
    <td>
      <label for="catoCode"><?php echo($row['catoText']);?></label></td>
    <td><?php echo($row['productTitle']);?></td>
    <td><?php echo($row['productEndDate']);?></td>
    <td><?php echo($row['availableProductsQTY']);?></td>
    <td><?php 
	echo($row['reorder_level']);
	
	?></td>
    <td>
	<?php
	if($row['availableProductsQTY'] <= $row['reorder_level']){
		?>
		<p style="color:#F00; font-weight:bold;">  low </p>
		<?php
	}
	else{
		?>
		<p style="color:#0F0; font-weight:bold;">  Normal </p>
		<?php
	}
	
	?>
	</td>
  </tr>	
	<?php
	}
	
	?>
</table> 

</div>
</div>
</br>
<input type="button" name = "btn_Print" value="Print Report" 
onclick="javascript:printContent('divPrintReportHead2','divPrintReportBody2','A4');" id="btn_Print" 
style="width:160px; height:25px; margin:0px; background-color:#6BAAF8; border-radius: 3px; border: 2px solid gray;"/>
    <?php
}

?>