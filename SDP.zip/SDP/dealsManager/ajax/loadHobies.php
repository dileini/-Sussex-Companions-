<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

// getting the data from the url


//$selectQ = "SELECT * FROM `jobcats`";
$selectQ = "SELECT * FROM `hobbie`";
$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else 
{
	//1 - catgory or category text available
	
	?>
<table width="100%" border="0" cellspacing="1">
  <tr>
    <td width="8%">Count</td>
    <td width="4%">#</td>
    <td width="14%">Hobbie Code</td>
    <td width="35%">Hobbie Text</td>
    <td width="11%">Added Date</td>
    <td width="17%">Status</td>
    <td width="11%">Modify</td>
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
		
	
	?>
  <tr class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['hid']);?></td>
    <td>
      <label for="catoCode"></label>
    <input name="catoCode<?php echo $row['hid'];?>" type="text" id="catoCode<?php echo $row['hid'];?>" value="<?php echo($row['h_code']);?>" size="4" maxlength="3" /></td>
    <td>
    <input name="catoText<?php echo $row['hid'];?>" type="text" id="catoText<?php echo $row['hid'];?>" value="<?php echo($row['h_text']);?>" size="30" /></td>
    <td>
    <input name="textfield3" type="text" id="textfield3" value="<?php echo($row['addDate']);?>" size="15" readonly="readonly"/></td>
    <td align="left">
	<?php 
	if($row['status'] ==1)
	{
		echo('Enabled');
	}
	else
	{
		echo('Desabled');
	}
	
	?></td>
    <td align="left">
   <a href="#" onclick="modifyCato(<?php echo $row['hid'];?>,'m','1');">Edit</a> / <a href="#" onclick="modifyCato2(<?php echo $row['hid'];?>,'d','<?php echo $row['status'];?>');">
   <?php
   if($row['status'] ==1)
   {
	   echo 'Disable';
   }
   
	   else
	   {
		   echo 'Enable';
	   }
   ?>
   </a></td>
  </tr>	
	<?php
	}
	
	?>
</table> 
    <?php
}

?>