<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

// getting the data from the url
$first_name     = mysql_real_escape_string($_POST ['first_name']);
$last_name      = mysql_real_escape_string($_POST ['last_name']);
$nic            = mysql_real_escape_string($_POST ['nic']);
$Gender         = mysql_real_escape_string($_POST ['Gender']);
$tel_no         = mysql_real_escape_string($_POST ['tel_no']);
$email          = mysql_real_escape_string($_POST ['email']);
$hb             = mysql_real_escape_string($_POST ['hb']);
$inter          = mysql_real_escape_string($_POST ['inter']);
$loc            = mysql_real_escape_string($_POST ['loc']);
$address        = mysql_real_escape_string($_POST ['address']);
$pass           = mysql_real_escape_string($_POST ['pass']);
$md5Pass        = md5($pass);

 
$userInsertQuery = "INSERT INTO `customer`(`firstName`, `lastName`, `gender`, `email`, `password`, `phone`, `address`, `nic` ,`hobie`, `interest`, `register_by`, `location`)
					VALUES('$first_name','$last_name','$Gender','$email','$md5Pass','$tel_no','$address','$nic',$hb,$inter,'admin','$loc')";

$insertUserQ = mysql_query($userInsertQuery);


echo "01";

?>

