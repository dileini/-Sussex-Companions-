<?php
session_start();
require_once('../db_connector.php');

//$stmt = "SELECT `depotID`, `depotText` FROM `depot`";
$stmt = "SELECT `event_id`, `event_title` FROM `event`";

$optionString = "";
$mainQuery2   = $stmt;
$mainResult2  = mysql_query($mainQuery2);
$resCount     = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['event_id'].'"'.">".$ro['event_title']."</option>";
 }
echo $optionString;
?>