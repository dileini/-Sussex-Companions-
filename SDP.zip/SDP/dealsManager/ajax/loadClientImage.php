<?php
session_start();
require_once('../db_connector.php');



// getting the data from the url
$clientID         = mysql_real_escape_string($_POST ['clientID']);

$selectImageQ    = "SELECT `cus_image` FROM `customer` WHERE `id`=$clientID";
$selectImageQRes = mysql_query($selectImageQ);

if(mysql_num_rows($selectImageQRes) > 0)
{
	
	while($row = mysql_fetch_array($selectImageQRes))
	{
		
	?>
	<img src="../images/<?php echo $row['cus_image'];?>" width="300" height="300" />
	
	<?php
	
	}
}

?>