<?php
session_start();
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );
require_once('../db_connector.php');


$districtCode = mysql_real_escape_string($_GET ['gradingCode']);

$query = "SELECT `DistrictCode`, `DistrictText` FROM `district` WHERE `provinceCode`='$districtCode'";



$optionString = "";
$mainQuery2  = $query;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['DistrictCode'].'"'.">".$ro['DistrictText']."</option>";
 }


echo $optionString;


?>
