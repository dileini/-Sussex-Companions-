<?php
session_start();
require_once('../db_connector.php');

$fromDate	= mysql_real_escape_string($_POST ['fromDate']);
$toDate		= mysql_real_escape_string($_POST ['toDate']);
$job		= mysql_real_escape_string($_POST ['job']);

$query = "SELECT `id`, `user_id`, `firstName`, `lastName`, `email`, `current_status`
			FROM `order_head` WHERE `id` <>0 ";

if($fromDate != "" and $toDate != ""){
	$query = $query. " AND DATE(`ordere_date`) BETWEEN  DATE('". $fromDate ."') and DATE('".$toDate."') ";
}

if($fromDate != "" and $toDate == ""){
	$query = $query. " AND DATE(`ordere_date`) = DATE('".$fromDate."') ";
}

if($fromDate == "" and $toDate != ""){
	$query = $query. " AND DATE(`ordere_date`) = DATE('".$toDate."') ";
}

if($job != "0"){
	$query = $query. " AND `current_status`='".$job."'";
}

$res = mysql_query($query);


if(mysql_num_rows($res) == 0){
	echo 'No records found';
}

else{
	
//Generate order Status list box
$listQuery = "SELECT `status_test` FROM `order_status`";
$listQueryR = mysql_query($listQuery);
$headofList = "";
$middleList = "";
$tailList = "</select>";

while($litstRow = mysql_fetch_array($listQueryR)){
	$middleList = $middleList. "<option value='".$litstRow['status_test']."'>".$litstRow['status_test']."</option>";
}

	?>
<table width="90%" border="1">
  <tr>
    <th scope="col">No</th>
    <th scope="col">Order No</th>
    <th scope="col">User Id</th>
    <th scope="col">First Name </th>
    <th scope="col">Last Name</th>
    <th scope="col">E-mail</th>
    <th scope="col">Current Statust of the Order</th>
    <th scope="col">New Status</th>
    <th scope="col">Modify</th>
  </tr>
	
	<?php
	$count = 1;
	while($row = mysql_fetch_array($res)){
		?>
<tr>
    <th scope="row"><?php echo $count; ?></th>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['user_id']; ?></td>
    <td><?php echo $row['firstName']; ?></td>
    <td><?php echo $row['lastName']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['current_status']; ?></td>
    <td><?php
	$headofList = "<select id='stat_".$row['id']."'>";
	echo $headofList. $middleList . $tailList;
	
	
	?></td>
    <td><a href="#" onclick="modifyStatus(<?php echo $row['id'];?>);">Modify</a></td>
</tr>
		<?php
		$count++;
	}
	
	?>
	</table>
	<?php
}























?>