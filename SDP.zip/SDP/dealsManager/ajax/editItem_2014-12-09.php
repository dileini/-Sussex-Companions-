<?php
session_start();
require_once('../db_connector.php');


$productId = $_GET['id'];

$selectQ = "SELECT 
`productID`, `catoID`, `productTitle`, `offPresent`, `originalPrice`, `discountAmnt`, `saveAmt`, `newAmnt`, `homepageImage`, 
`productDesc`, `itemOrder`, `productAddDate`, `productEndDate`, `availableProductsQTY`, productEnableDesable, 
`catoCode`, `catoText` ,catoID
FROM `products` 
LEFT JOIN `jobcats` ON `jobcats`.`id`= `products`.`catoID` 
where `productID`=$productId
order by productID DESC";
$selectQRes = mysql_query($selectQ);


$productID			  = '';
$catoID				  = '';
$productTitle 		  = '';
$offPresent 		  = '';
$originalPrice		  = '';
$discountAmnt		  = '';
$saveAmt			  = '';
$newAmnt 			  = '';
$homepageImage		  = '';
$productDesc          = '';
$itemOrder            = ''; 
$productAddDate       = ''; 
$productEndDate       = '';
$availableProductsQTY = ''; 
$productEnableDesable = '';
$catoCode			  = '';
$catoText			  = '';

if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else
{
	while($row = mysql_fetch_array($selectQRes))
	{
		$productID			  = $row['productID'];
		$catoID				  = $row['catoID'];
		$productTitle 		  = $row['productTitle'];
		$offPresent 		  = $row['offPresent'];
		$originalPrice		  = $row['originalPrice'];
		$discountAmnt		  = $row['discountAmnt'];
		$saveAmt			  = $row['saveAmt'];
		$newAmnt 			  = $row['newAmnt'];
		$homepageImage		  = $row['homepageImage'];
		$productDesc          = $row['productDesc'];
		$itemOrder            = $row['itemOrder']; 
		$productAddDate       = $row['productAddDate']; 
		$productEndDate       = $row['productEndDate'];
		$availableProductsQTY = $row['availableProductsQTY']; 
		$productEnableDesable = $row['productEnableDesable'];
		$catoCode			  = $row['catoCode'];
		$catoText			  = $row['catoText'];
		$catoID			      = $row['catoID'];
		
	
	}
}
?>

<script src="../js/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="../js/mootools.js"> </script>
<script type="text/javascript" src="../js/mootools-more.js"> </script>
<script type="text/javascript" src="../js/lang/en.js"> </script>
<script type="text/javascript" src="../js/empty.js"> </script>
<script type="text/javascript" src="../js/formcheck.js"> </script>
<script type="text/javascript" src="../js/autocomplete.js"> </script>
<!-- <script type="text/javascript" src="../js/addCategory/combo.js"> </script> -->
<script type="text/javascript" src="../js/addCategory/core_functions.js"> </script>

<link rel="stylesheet" href="../js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="../js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="../js/Source/Picker.js" type="text/javascript"></script>
<script src="../js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="../js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="../js/Source/datepicker.css" rel="stylesheet">
<link href="../js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">

<script>
    window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
</script>

<script type="text/javascript">
    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{showErrors:1});
		
		new Picker.Date($('toDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2014-11-30',
          	maxDate: '2016-10-01'
	    });
		
		load_catos();
    });

    function saveCatos()
	{
		if (formcheck.checkValidation()) 
		{

				if($('job').value == '0')
				{
					alert('Please select job category');
					$('job').focus();
				}
				
				else
				{
					//alert($('productDesc').value);
					//alert($$('body[class$=cke_contents_ltr]').getFirst().get('text'));
					var desValue = CKEDITOR.instances.productDesc.getData();
					var productID = "<?php echo $productId;?>";
					var query = "productName="+$('productName').value
					           +"&productDesc="+ desValue
							   +"&productDisCount="+ $('productDisCount').value
							   +"&productNormalPrice="+ $('productNormalPrice').value
							   +"&productSave="+ $('productSave').value
							   +"&productFinalPrice="+ $('productFinalPrice').value
							   +"&toDate="+ $('toDate').value
							   +"&job="+ $('job').value
							   +"&proID="+productID
							   +"&productItems="+ $('productItems').value;
					var url = 'updateSaveJobs.php';
	
					var req = new Request({method: 'POST',
						data:query,
						url: url,
						onSuccess: function(result){
							hideImgContent('waitingDiv');
							//alert(result);
							
							if(result =='1')
							{
								alert('Job sucessfully added..!')
								//window.location.reload();
								window.close();
							}
							if(result =='2')
							{
								alert('Inserting problem occor.')
								//window.location.reload();
							}
							else
							{
								alert('Job not posted. Try again..!')
								//window.location.reload();
							}
							
						}});
					showImgContent('waitingDiv');
					req.send();
				
				}

			}
		
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Modify Product</p>
<form enctype="multipart/form-data" id="grid_form" action="">
<table width="637" border="0" class="grid_head_tbl">
  <tr>
    <td width="76" align="left" valign="top"><strong>Product Name : </strong></td>
    <td width="551"><input  name="productName" type="text" class="validate['required']" id="productName" style="width:450px;" value="<?php echo $productTitle; ?>" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Product Description:</strong></td>
    <td><textarea name="productDesc" rows="30" class="ckeditor" id="productDesc" style="width:450px;"><?php echo $productDesc; ?></textarea></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Product Category:</strong></td>
    <td>
<?php  
$stmt         = "SELECT `id`, `catoText` FROM `jobcats` WHERE `catStatus`=1";
$optionString = "";
$mainQuery2   = $stmt;
$mainResult2  = mysql_query($mainQuery2);
$resCount     = mysql_num_rows($mainResult2);

?>
    
    
    
    <select name="job" id="job" style="width:180px;">
      <option value="<?php echo $catoID;?>" selected="selected"><?php echo $catoText;?></option>
     <?php 
	 while($ro = mysql_fetch_array($mainResult2))
	 {
			//echo $optionString = $optionString . "<option value=".'"'.$ro['id'].'"'.">".$ro['catoText']."</option>";
			echo $optionString . "<option value=".'"'.$ro['id'].'"'.">".$ro['catoText']."</option>";
	 }

	 ?>
    </select>
    </td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Off Percentage: </strong></td>
    <td><input  name="productDisCount" type="text" class="validate['required']" id="productDisCount" style="width:25px;" value="<?php echo $offPresent; ?>" maxlength="2"/>
    %</td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Original Price: </strong></td>
    <td><input  name="productNormalPrice" type="text" class="validate['required']" id="productNormalPrice" style="width:100px;" value="<?php echo $originalPrice; ?>" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>You Save:</strong></td>
    <td><input  name="productSave" type="text" class="validate['required']" id="productSave" style="width:100px;" value="<?php echo $saveAmt; ?>" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Final Price:</strong></td>
    <td><input  name="productFinalPrice" type="text" class="validate['required']" id="productFinalPrice" style="width:100px;" value="<?php echo $newAmnt; ?>" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Closing Date:</strong></td>
    <td><input type="text" value="<?php echo $productEndDate; ?>"  name="toDate" id="toDate" style="width:180px;" class="validate['required']"/> 
    Eg: 2014-11-30</td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Number Items on stock:</strong></td>
    <td><input  name="productItems" type="text" class="validate['required','number']" id="productItems" style="width:180px;" value="<?php echo $availableProductsQTY; ?>" size="3" maxlength="2"/></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td><label for="fileField"></label></td>
  </tr>
  
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td style="align:right;padding-left:200px;">
		<input type="button" value="Save Product" onclick="saveCatos()" />
		</td>
	</tr>

</table>


</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="../images/wait.gif" style="width:150px;height:40px;"/></div></center></div>