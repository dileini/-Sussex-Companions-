<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

// getting the data from the url
$first_name     = mysql_real_escape_string($_POST ['first_name']);
$last_name      = mysql_real_escape_string($_POST ['last_name']);
$nic            = mysql_real_escape_string($_POST ['nic']);
$Gender         = mysql_real_escape_string($_POST ['Gender']);
$tel_no         = mysql_real_escape_string($_POST ['tel_no']);
$hb             = mysql_real_escape_string($_POST ['hb']);
$inter          = mysql_real_escape_string($_POST ['inter']);
$loc            = mysql_real_escape_string($_POST ['loc']);

$firstNameWhere = "";
$last_nameWhere = "";
$nicWhere       = "";
$GenderWhere    = "";
$tel_noWhere    = "";
$email          = "";
$hbWhere        = "";
$interWhwre     = "";
$locWhere     	= "";

if($first_name !=""){
	$firstNameWhere = " and `firstName` LIKE '%". $first_name . "%'";
}
if($last_name !=""){
	$last_nameWhere = " and `lastName` LIKE '%". $last_name . "%'";
}
if($nic !=""){
	$nicWhere = " and `nic` LIKE '%". $nic . "%'";
}
if($tel_no !=""){
	$tel_noWhere = " and `phone` LIKE '%". $tel_no . "%'";
}
if($hb !="0"){
	$hbWhere = " and `hobie`=$hb";
}
if($inter !="0"){
	$interWhwre = " and `interest`=$inter";
}
if($loc !="0"){
	$locWhere = " and `location`=$loc";
}

$userInsertQuery = "SELECT `id`,`firstName`, `lastName`, `gender`, `email`, `password`, `phone`, `address`, `nic`, 
	`hobie`, `interest`, `register_by`, `location`,`cus_image`,
	`h_text`, `i_text`, `location`, depotText
FROM `customer`
LEFT JOIN `hobbie` ON `hobbie`.`hid` = `customer`.`hobie`
LEFT JOIN `interest` ON `interest`.`iid` = `customer`.`interest`
LEFT JOIN `depot` ON `depot`.`depotID`=customer.`location`
where `id`<> 0 and gender='$Gender' $firstNameWhere $last_nameWhere $nicWhere $hbWhere $interWhwre
ORDER BY `id` DESC";

$selectQRes = mysql_query($userInsertQuery);

if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('1');
}

else 
{

	?>
<table width="100%" border="1" cellspacing="1">
  <tr>
    <td width="6%"><em><strong>Count</strong></em></td>
    <td width="4%"><em><strong>#</strong></em></td>
    <td width="12%"><em><strong>First Name</strong></em></td>
    <td width="12%"><em><strong>Last Name</strong></em></td>
    <td width="15%"><em><strong>Gender</strong></em></td>
    <td width="35%"><em><strong>Phone</strong></em></td>
    <td width="5%"><em><strong>Address</strong></em></td>
    <td width="6%"><em><strong>Hobbie</strong></em></td>
    <td width="11%"><em><strong>Interests</strong></em></td>
    <td width="11%"><em><strong>Office Location</strong></em></td>
    <td width="5%"><em><strong>Image</strong></em></td>
    <td width="6%"><em><strong>Registed By</strong></em></td>
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
		
	
	?>
  <tr align="left" valign="top" class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['id']);?></td>
    <td><?php echo($row['firstName']);?></td>
    <td>
      <label for="catoCode"><?php echo($row['lastName']);?></label></td>
    <td><?php if($row['gender'] == 'm'){echo('Male');}
				else{
					echo('Female');
					}
					?></td>
    <td><?php echo($row['phone']);?></td>
    <td><?php echo($row['address']);?></td>
    <td><?php echo($row['h_text']);?></td>
    <td><?php echo($row['i_text']);?></td>
    <td><?php echo($row['depotText']);?></td>
    <td><img src="../images/<?php echo($row['cus_image']);?>" width="50" height="50" /></td>
    <td><?php echo($row['register_by']);?></td>
  </tr>	
	<?php
	}
	
	?>
</table> 
    <?php

}
?>

