<?php
//session_start();
	
require_once('../db-config.php');
//$id = $_SESSION['user_id'];


//$query = "SELECT  * FROM  region  ORDER BY regionText ASC";

$change = $_GET['change'];

if($change != "")
{
	$query = "SELECT  epfNo FROM personalinfo  ORDER BY epfNo ASC";
}


$optionString = "";
$mainQuery2  = $query;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['epfNo'].'"'.">".$ro['epfNo']."</option>";
 }


echo $optionString;

?>