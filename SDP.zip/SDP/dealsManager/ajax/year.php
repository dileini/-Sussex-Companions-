<?php
session_start();
require_once ('../bootstrap.php');
Doctrine_Core::loadModels ( '../models' );


$year_txt="";
$year_id="";
$yearItems = array ();
$yearIt = array ();



$cyear= date("Y");


$k=0;
for($i=2013; $i<=$cyear; $i++){
	$yearIte[$k]=$i;

	$k++;
	
}

//var_dump($yearItems);
foreach ( $yearIte as $yearItem ){
$arrObj = array ('year_id' => $yearItem,  'year_txt' => $yearItem);
					
				array_push ( $yearItems, $arrObj );
}






//echo $yearItems;
//var_dump($yearItems);

 




$json = new Doctrine_Parser_Json ();
echo $json->dumpData ( $yearItems );


$conn-> close();
?>