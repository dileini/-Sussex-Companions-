<?php
session_start();
//require_once ('../bootstrap.php');
//Doctrine_Core::loadModels ( '../models' );
require_once('../db_connector.php');


$id = $_GET ['id'];
//$active = $_GET ['active'];

$query = "";
$deport_id="";

//checking whether if region id value is sent
if ($id == "")
{
	$id = $_SESSION ['user_region'];
	$deport_id = $_SESSION ['user_deport'];
}
if ($deport_id == "")
{
	$query = "select `depotID`, `depotCorde`, `depotText`, `depotPhone`, `depotImageURL`, `depotTotalEmp`, `regionCode` 
	from depot where regionCode='$id' order by regionCode";
}
else
{
	$query = "select * from depot where depot_id='" . $deport_id . "' and region_id=" . $id . " and priority in (0,1)";
}


$optionString = "";
$mainQuery2  = $query;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);

while($ro = mysql_fetch_array($mainResult2))
 {
		$optionString = $optionString . "<option value=".'"'.$ro['depotCorde'].'"'.">".$ro['depotText']."</option>";
 }


echo $optionString;


?>
