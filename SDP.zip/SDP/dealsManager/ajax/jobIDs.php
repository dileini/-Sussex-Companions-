<?php
session_start();
require_once('../db_connector.php');

$jobCatoID         = mysql_real_escape_string($_GET['id']);
/*
$stmt = "SELECT `jobid`, `jobidTxt`, `jobCatid`, `jobtitle`,`jobdescription`, `jobOffercompanyID`, `jobimageURL`, `jobVisites`, `jobStatus`, 
`jobPostedBy`, `jobPostedDate`, `jobModifyDate`, `jobOpenDate`, `jobCloseDate`, `numberofpossitions`, `jobImage`
 FROM jobs 
 WHERE `jobCatid`=$jobCatoID  AND `jobStatus`=1";
*/
$stmt = "SELECT `productID`, `catoID`, `productTitle`, `offPresent`, `originalPrice`, `discountAmnt`, `saveAmt`, `newAmnt`, `homepageImage`, 
`productDesc`, `itemOrder`, `productAddDate`, `productEndDate`, `availableProductsQTY`
FROM `products` WHERE `catoID`= $jobCatoID AND `productEnableDesable`=1
order by productID DESC";




$optionString = "";
$mainQuery2  = $stmt;
$mainResult2 = mysql_query($mainQuery2);
$resCount   = mysql_num_rows($mainResult2);



if($resCount > 0)
{
	 while($ro = mysql_fetch_array($mainResult2))
	 {
			$optionString = $optionString . "<option value=".'"'.$ro['productID'].'"'.">".$ro['productTitle'].'-'.$ro['offPresent']."% off </option>";
	 }

	echo $optionString;
}

else
{
	echo('<option value="noitemsfound">No Items Found</option>');
}


?>