<?php
session_start();
require_once('../db_connector.php');



// getting the data from the url
$jobmane         = mysql_real_escape_string($_POST ['jobid']);


//$selectImageQ = "SELECT `imageURLOne`, `imageURLTwo`, `imageURLThree`, `imageURLFour`, `imageURLFive` FROM `productimages` WHERE `productID`='$jobmane'";
$selectImageQ = "SELECT `image1` FROM `products` WHERE `productID`='$jobmane'";
$selectImageQRes = mysql_query($selectImageQ);

if(mysql_num_rows($selectImageQRes) > 0)
{
	
	while($row = mysql_fetch_array($selectImageQRes))
	{
		
	?>
	<hr>
	<img src="../images/<?php echo $row['image1'];?>" width="415" height="265" />
	<hr>
	
	<?php
	
	}
}

else
{
	echo('No Images(1) Found for this product.');
}

?>