<?php
session_start();
require_once('../db_connector.php');

$joID = $_GET['jobID'];

$jobsQs = "SELECT `jobs`.`jobid` AS jid, `jobs`.`jobidTxt` AS jbText, `jobs`.`jobtitle` AS jbTitle, `jobs`.`jobdescription` AS jbDesc, 
			`jobs`.`jobOffercompanyID` AS compID, 
			`jobs`.`jobimageURL` AS imgURL, `jobs`.`jobVisites` AS joVisi, `jobs`.`jobStatus` AS jobStat, `jobs`.`jobPostedBy`, 
			`jobs`.`jobStatus`, `jobs`.`jobPostedBy`, `jobs`.`jobPostedDate` AS postedDate, `jobs`.`jobModifyDate` AS modDate,
			`jobs`.`jobOpenDate` AS jbOpendate, `jobs`.`jobCloseDate` AS jbCloseDate, `jobs`.`numberofpossitions` AS numPoss, 
			`jobs`.`jobImage` AS jobImage, `jobcats`.`catoText` AS catText
			FROM `jobs`, `jobcats`
			WHERE `jobs`.`jobCatid`=`jobcats`.`id` and `jobs`.`jobid`=$joID";
 
 $jobsQsRes = mysql_query($jobsQs);
 
 if(mysql_num_rows($jobsQsRes) !=0)
 {
 	while($job = mysql_fetch_array($jobsQsRes))
	{
		$jobID        = $job['jid'];
		$jbText       = $job['jbText'];
		$jbDesc       = $job['jbDesc'];
		$imgURL       = $job['imgURL'];
		$jbOpendate   = $job['jbOpendate'];
		$jbCloseDate  = $job['jbCloseDate'];
		$numPoss      = $job['numPoss'];
		$jobImage     = $job['jobImage'];
		$catText      = $job['catText'];
		$compID       = $job['compID'];
		
	}
 }
 
 else
 {
 	echo('No Jobs Found..!');	
 }



?>

<table width="900" border="1" bgcolor="#6097f2">
  <tr>
    <td width="399"><table width="100%" border="0">
      <tr>
        <td colspan="2"><img src="../../images/logo rakeya.jpg" width="232" height="76" /></td>
        </tr>
      <tr align="left" valign="middle">
        <td><h5>Company Name</h5></td>
        <td><h5><?php echo $compID; ?></h5></td>
      </tr>
      <tr align="left" valign="middle">
        <td width="26%"><h5>Job Title</h5></td>
        <td width="74%"><h5><?php echo $jbText; ?></h5></td>
      </tr>
      <tr align="left" valign="middle">
        <td><h5>Job Description</h5></td>
        <td><h5><?php echo $jbDesc; ?></h5></td>
      </tr>
      <tr align="left" valign="middle">
        <td><h5>Details</h5></td>
        <td>     
        <img src="../images/<?php echo $jobImage;?>"/></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40662664-9', 'auto');
  ga('send', 'pageview');

</script>