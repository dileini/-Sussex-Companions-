<?php
session_start();
require_once('../db_connector.php');


// getting the data from the url
$client     = mysql_real_escape_string($_POST ['client']);
$event      = mysql_real_escape_string($_POST ['event']);
$eventSum   = 0.00;

$clientWhere = "";
$eventWhere  = "";

if($client != '0'){
	$clientWhere = " AND `client_id`= $client  ";
}

if($event != '0'){
	$eventWhere = " AND `assign_event`.`event_id`=$event ";
}

$selectQ = "SELECT `assign_event_id`, `client_id`, `assign_event`.`event_id` AS evid, `assign_date`,
`firstName`, `lastName`, `email`, `address`, 
`event_title`, `event_cost`, `event_date`, `event_time`, event_per_head_cost
FROM `assign_event`
LEFT JOIN `customer` ON `customer`.`id`=assign_event.`client_id`
LEFT JOIN `event` ON event.`event_id`=assign_event.`event_id`
WHERE `assign_event_id` <> 0 $clientWhere $eventWhere
ORDER BY `client_id`";


$selectQRes = mysql_query($selectQ);


if(mysql_num_rows($selectQRes) == 0)
{
//no recores.
	echo('01');
}

else 
{
	//1 - catgory or category text available
	
	?>
<table width="100%" border="1" cellpadding="2" cellspacing="2">
  <tr bgcolor="#999999">
    <td width="7%"><em><strong>Count</strong></em></td>
    <td width="13%"><em><strong>Event Title</strong></em></td>
    <td width="9%"><em><strong>Event Date</strong></em></td>
    <td width="12%"><em><strong>Event Time</strong></em></td>
    <td width="10%"><em><strong>Perhead Cost</strong></em></td>
    <td width="21%"><em><strong>Client First Name</strong></em></td>
    <td width="22%"><em><strong>Client Last Name</strong></em></td>
  </tr>

	<?php
	$count = 1;
	while($row = mysql_fetch_array($selectQRes))
	{
			$eventSum = $eventSum + $row['event_per_head_cost'];
	
	?>
  <tr align="left" valign="top" bgcolor="#CCCCCC" class="border_bottom">
    <td><?php echo $count++; ?></td>
    <td><?php echo($row['event_title']);?></td>
    <td><?php echo($row['event_date']);?></td>
    <td><?php echo($row['event_time']);?></td>
    <td><?php echo($row['event_per_head_cost']);?></td>
    <td><?php echo($row['firstName']);?></td>
    <td><?php echo($row['lastName']);?></td> 
  </tr>	
	<?php
	}
	
	?>
	<tr align="left" valign="top" bgcolor="#CCCCCC" class="border_bottom">
    <td colspan="4" align="right"><strong>Total per head cost</strong></td>
    <td colspan="3"><strong><?php echo number_format($eventSum, 2); ?></strong></td>
  </tr>	
</table> 
    <?php
}

?>