<?php
session_start();
require_once('../db_connector.php');

$maxUserID = "";

// getting the data from the url
$client     = mysql_real_escape_string($_POST ['client']);
$event      = mysql_real_escape_string($_POST ['event']);
 
$userInsertQuery = "INSERT INTO `assign_event`(`client_id`, `event_id`) VALUE($client,$event)";
$insertUserQ = mysql_query($userInsertQuery);
echo "01";

?>

