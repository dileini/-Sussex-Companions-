
<style type="text/css">

/* CSS Document */

* {
margin: 0px;
padding: 0px;
border: 0px;
}

body,html {
	background-image:url(image/body.gif), url(image/footer.png);
	background-position:top left, bottom left;
	background-repeat: repeat-x, repeat-x;
	background-attachment: scroll, scroll;
	margin:0 auto 0 auto;
	background-color:#FFF;
	
	border-bottom-width: 2px;
	border-bottom-style: solid;
	border-bottom-color: #000000;
	}

/*body,html {
	background-color: #F3F2F4;
	background-image: url(image/body.gif);
	background-repeat: repeat-x;
}*/
#wrapper {
	width: auto;
	margin-top: 2px;
	margin-right: auto;
	margin-left: auto;
}

#body {
	float: left;
	width: 100%;
	height: auto;
	padding-left: 30px;

}
#header {
	float: left;
	width: 100%;
	height: 110px;
	background-image: url(image/logo.png);
	background-repeat: no-repeat;	/*background-color: #FFFFFF;*/
}
#unheader {
	float: left;
	width: 100%;
	height: 38px;
}
#unheader-left {
	float: left;
	width: 65%;
	height: 38px;
}
#unheader-right {
	float: right;
	width: 25%px;
	height: 38px;
	/*background-color: #FFFFFF;*/
	text-align: right;
	line-height: 38px;
	font-family: "Times New Roman", Times, serif;
	font-size: 15px;
}

</style>


<div id="header">

</div>
<div id="unheader">
	<div id="unheader-left">
    
    </div>
    <div id="unheader-right">
    Control panel <font color="#CC3300" style="font-style:italic; font-size:16px;"><?php echo $_SESSION['username']; ?> </font>
    </div>
</div>