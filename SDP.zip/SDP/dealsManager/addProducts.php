<?php
session_start();
include("templates/header.php");
require_once 'sessionCK.php';
// Check user logged in or not
	
?>
<div>
<div class="right" style="float:left;clear:both;width:120px;"><?php add_module('menu'); ?></div>
<div class="content" style="padding-left:80px;margin-left: 130px;">
	<div class="left"> <?php add_module('addProducts'); ?></div>
</div>
</div>
<?php
include("templates/footer.php");
?>
