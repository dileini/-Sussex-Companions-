<?php
session_start();
//include("accessLog.php");
unset($_SESSION['user_id']);
unset($_SESSION['username']);
unset($_SESSION['logged_in']);

session_unset();
session_destroy();
session_commit();
include("templates/header_index.php");

?>
<link rel="stylesheet" type="text/css" href="css/index.css" />
<div id="index_content">

    <?php
    add_module('login');
    ?>

</div>

<?php
    include("templates/footer.php");
?>


