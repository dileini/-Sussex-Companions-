<?php
session_start ();
//ob_end_flush();
//ob_start();

include("templates/header.php");

	
?>
<div>
<div class="right" style="float:left;clear:both;width:120px;"> <?php add_module('menu'); ?> </div>
<div class="content" style="padding-left:80px;margin-left: 130px;">
	<div class="left"> <?php add_module('profile'); ?> </div>
</div>
</div>



<?php
include("templates/footer.php");
?>

	


