<?php
//**************************************
//     Page load dropdown results     //
//**************************************

function getTierOne2()
{
	$machine_number=$_SESSION['user_machine_number'];
	$result = mysql_query("SELECT  epfNo FROM personalinfo  ORDER BY epfNo ASC") 
	or die(mysql_error());

	  while($tier = mysql_fetch_array( $result )) 
  
		{
		   echo '<option value="'.$tier['epfNo'].'">'.$tier['epfNo'].'</option>';
		}

}

//**************************************
//     First selection results     //
//**************************************
if($_GET['func'] == "drop_1" && isset($_GET['func'])) { 
   drop_1($_GET['drop_var']); 
}

function drop_1($drop_var)
{  
    include_once('../../db-config.php');
	$result = mysql_query("SELECT * FROM personalinfo WHERE epfNo='$drop_var'") 
	or die(mysql_error());
	
	
	 while($drop_2 = mysql_fetch_array( $result ))  {
			
	echo '<input type="text" name="fulname" size="60" style="text-decoration:underline;" value="'.$drop_2['initials'].$drop_2['surName'].'" />';
	?>
	<br />
	 <img src="images/<?php echo  $drop_2['image']; ?>" class="img" align="bottom"  width="150" height="195" />
	 
<?php
	}
  //  echo '<input type="submit" name="submit" value="Submit" />';
}
?> 