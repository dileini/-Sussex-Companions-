<?php
//**************************************
//     Page load dropdown results     //
//**************************************

function getTierOne4()
{
	$machine_number=$_SESSION['user_machine_number'];
	$result = mysql_query("SELECT  epfNo FROM personalinfo  ORDER BY epfNo ASC") 
	or die(mysql_error());

	  while($tier = mysql_fetch_array( $result )) 
  
		{
		   echo '<option value="'.$tier['epfNo'].'">'.$tier['epfNo'].'</option>';
		}

}

//**************************************
//     First selection results     //
//**************************************
if($_GET['func'] == "drop_4" && isset($_GET['func'])) { 
   drop_4($_GET['drop_var']); 
}

function drop_4($drop_var)
{  
    include_once('../../db-config.php');
	$result = mysql_query("SELECT * FROM personalinfo WHERE epfNo='$drop_var'") 
	or die(mysql_error());
	
	
	 while($drop_44 = mysql_fetch_array( $result ))  {
			
	echo '<input type="text" name="gepf1name" id="gepf1name" size="60" style="text-decoration:underline;" value="'.$drop_44['initials'].$drop_44['surName'].'" />';
	?>
	
<?php
	}
  //  echo '<input type="submit" name="submit" value="Submit" />';
}
?> 