<?php
//**************************************
//     Page load dropdown results     //
//**************************************

function getTierOne5()
{
	$machine_number=$_SESSION['user_machine_number'];
	$result = mysql_query("SELECT  epfNo FROM personalinfo  ORDER BY epfNo ASC") 
	or die(mysql_error());

	  while($tier = mysql_fetch_array( $result )) 
  
		{
		   echo '<option value="'.$tier['epfNo'].'">'.$tier['epfNo'].'</option>';
		}

}

//**************************************
//     First selection results     //
//**************************************
if($_GET['func'] == "drop_5" && isset($_GET['func'])) { 
   drop_5($_GET['drop_var']); 
}

function drop_5($drop_var)
{  
    include_once('../../db-config.php');
	$result = mysql_query("SELECT * FROM personalinfo WHERE epfNo='$drop_var'") 
	or die(mysql_error());
	
	
	 while($drop_55 = mysql_fetch_array( $result ))  {
			
	echo '<input type="text" name="gepf2name" id="gepf2name" size="60" style="text-decoration:underline;" value="'.$drop_55['initials'].$drop_55['surName'].'" />';
	?>
	
<?php
	}
  //  echo '<input type="submit" name="submit" value="Submit" />';
}
?> 