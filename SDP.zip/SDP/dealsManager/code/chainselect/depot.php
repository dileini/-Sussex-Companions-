<?php
//**************************************
//     Page load dropdown results     //
//**************************************

function getTierOne()
{
	//$machine_number=$_SESSION['user_machine_number'];
	$result = mysql_query("SELECT  * FROM  region  ORDER BY regionText ASC") 
	or die(mysql_error());

	  while($tier = mysql_fetch_array( $result )) 
  
		{
		   echo '<option value="'.$tier['regionCode'].'">'.$tier['regionText'].'</option>';
		}

}

//**************************************
//     First selection results     //
//**************************************
if($_GET['func'] == "drop_2" && isset($_GET['func'])) { 
   drop_2($_GET['drop_var']); 
}

function drop_2($drop_var)
{  
    include_once('../../db-config.php');
	$result = mysql_query("SELECT * FROM depot WHERE regionCode='$drop_var'") 
	or die(mysql_error());
	
	echo '<select name="depocode" id="depocode" class="select">
	      <option value="-Select Depot-">-Select Depot-</option>';
	
	 while($drop_2 = mysql_fetch_array( $result )) 
			{

			echo '<option value="'.$drop_2['depotCorde'].'" id="division">'.$drop_2['depotText'].'</option>';

			}
			echo '</select> ';
  //  echo '<input type="submit" name="submit" value="Submit" />';
}
?> 