<?php

function add_module($module){
		include("modules/".$module."/index.php");
}


?>
