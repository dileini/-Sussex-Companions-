<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/addCategory/combo.js"> </script>
<script type="text/javascript" src="js/addCategory/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">
    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{showErrors:1});
		
		new Picker.Date($('fromDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2020-10-01',
         	maxDate: '2022-10-01'
	    });
		
		new Picker.Date($('toDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2020-10-01',
         	maxDate: '2022-10-01'
	    });
		
		load_catos();
    });

    function saveCatos()
	{
		if (formcheck.checkValidation()) 
		{

				var query = "jobmane="+$('jobmane').value
				           +"&companyName="+ $('companyName').value
						   +"&desc="+ $('desc').value
						   +"&fromDate="+ $('fromDate').value
						   +"&toDate="+ $('toDate').value
						   +"&jobCat="+ $('job').value
						   +"&poss="+ $('poss').value;
				var url = 'ajax/saveJobs.php';

				alert($('job').value);
				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						alert(result);
						
						if(result =='1')
						{
							alert('Job sucessfully added..!')
							window.location.reload();
						}
						if(result =='2')
						{
							alert('Inserting problem occor.')
							//window.location.reload();
						}
						else
						{
							alert('Job not posted. Try again..!')
							//window.location.reload();
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

			}
		
    }
	
	function loadImage(myImage)
	{
		
		var query = "jobid="+myImage;
				var url = 'ajax/loadMainJobImage.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result)
					{
						
						hideImgContent('waitingDiv');
						
						$('adImage').style.display = "inline";
						$('adImage').innerHTML = result;			
					}});
				showImgContent('waitingDiv');
				req.send();

	}
	
function loadSales()
 {
 	var query = "job="+$('job').value
				  +"&product="+$('product').value
				  +"&fromDate="+$('fromDate').value
				  +"&toDate="+$('toDate').value;
	var url = 'ajax/profitReport.php';

	var req = new Request({method: 'POST',
		data:query,
		url: url,
		onSuccess: function(result){
			hideImgContent('waitingDiv');
			//alert(result);
			if(result.trim() =='1')
			{
				alert('No recores found')
			}
			else
			{
				$('res').innerHTML = result;
			}
			
		}});
	showImgContent('waitingDiv');
	req.send();
 }
 
 function modifyStatus(id)
 {
	var boxID = "stat_"+id;
 	var query = "id="+id
				  +"&status="+$(boxID).value;
	var url = 'ajax/chageOrderStatus.php';

	var req = new Request({method: 'POST',
		data:query,
		url: url,
		onSuccess: function(result){
			hideImgContent('waitingDiv');
			alert('record sucessfully updated..');
			LoadAllOrders();
			
		}});
	showImgContent('waitingDiv');
	req.send();
 }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Profit Detail Report</p>
<form action="./ajax/upload_main_file.php" method="post" enctype="multipart/form-data">
<table width="611" border="0" class="grid_head_tbl">
  <tr>
    <td>From Date</td>
    <td><label for="fromDate"></label>
      <input type="text" name="fromDate" id="fromDate" /></td>
  </tr>
  <tr>
    <td>To Date</td>
    <td><label for="toDate"></label>
      <input type="text" name="toDate" id="toDate" /></td>
  </tr>
  <tr>
    <td>Category</td>
    <td><label for="fromDate"></label>
      <select name="job" id="job" style="width:180px;" onchange="load_products(this);">
        <option value="any" selected="selected">Any</option>
      </select></td>
  </tr>
  
    <td>Product</td>
    <td><select name="product" id="product" style="width:180px;" >
      <option value="0" selected="selected">Any</option>
    </select></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="#" onclick="loadSales();">Load Proft Calculation Report</a></td>
  </tr>
  <tr>
    <td colspan="2"></td>
    </tr>

</table>
<div id='res'> </div>
</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>