

<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/person/combo.js"> </script>
<script type="text/javascript" src="js/person/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css"
	type="text/css" media="screen" />
<link href="css/textStyles.css" rel="stylesheet">

<script src="js/Source/Locale.en-US.DatePicker.js"
	type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css"
	rel="stylesheet">

<script type="text/javascript">
var formcheck;

window.addEvent('domready', function() {
    
    formcheck = new FormCheck('grid_form',{showErrors:1});
    

    new Picker.Date($('fromDate'), {
        positionOffset: {x: 5, y: 0},
        format : '%d/%m/%Y',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    });

    new Picker.Date($('toDate'), {
        positionOffset: {x: 5, y: 0},
        format : '%d/%m/%Y',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    });
	
	 new Picker.Date($('dateofbirth'), {
        positionOffset: {x: 5, y: 0},
        //format : '%d/%m/%Y',
		format : '%Y-%m-%d',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    });

	new Picker.Date($('joinFrom'), {
        positionOffset: {x: 5, y: 0},
        //format : '%d/%m/%Y',
		format : '%Y-%m-%d',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    });
	
	new Picker.Date($('joinTo'), {
        positionOffset: {x: 5, y: 0},
        //format : '%d/%m/%Y',
		format : '%Y-%m-%d',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    });


	$$('form input').addEvent('keydown', function(event)
	
	{
		if(event.key == "enter") 
		{
			load_stock_paper();
		}
	});
    
    load_combo_data('ajax/regions.php','reigon','region_text','region_id','change=true');
	
	load_combo_data('ajax/gradings.php','grading','gradeText','gradeCode','change=true');
	
	//load_combo_data('ajax/religion.php','religion','gradeText','gradeCode','change=true');
	
	load_combo_data('ajax/provinces.php','provinces','provincesText','provincesCode','change=true');
	
	load_combo_data('ajax/religions.php','religion','religionText','religionCode','change=true');
	
    load_combo_data('ajax/nationality.php','nationality','nationalityText','nationalityCode','change=true');
	
	
	//loading the species combo data
           
});

function clearField(ele)
{
	ele.value = "";
}


  
	
function load_stock_paper(page){

/*
    	if(document.getElementById('reigon').value == 0 || document.getElementById('reigon').value == "")
		{
			alert("Please select a Region");	
			return false;
				
		}

    	
		if(document.getElementById('depot').value == "" || document.getElementById('depot').value == 0)
		{
			alert("Please select a Deport");	
			return false;
						
		}
*/    	
		    
	  	  var query ="epf="+$('epf').value
	  	  			+"&surename="+    $('surename').value
					+"&nic="+         $('nic').value 
					+"&filenumber="+  $('filenumber').value
					+"&dateofbirth="+ $('dateofbirth').value
					+"&reigon="+      $('reigon').value
					+"&depot="+       $('depot').value 
					+"&grading="+     $('grading').value 
					+"&designation="+ $('designation').value
					+"&sex="+         $('sex').value 
					+"&order_by="+    $('order_by').value
					+"&order_by2="+   $('order_by2').value
					+"&religion="+    $('religion').value
					+"&nationality="+ $('nationality').value
					+"&showImages="+  $('showImages').value
					+"&joinFrom="+    $('joinFrom').value
					+"&joinTo="+      $('joinTo').value;

	
			//+"&sellDate="+document.getElementById('document_date').value; 
			var url = 'ajax/personSummary.php';
					
	        var req = new Request({method: 'GET',
	            data:query,
	            url: url,
	            onSuccess: function(result){
	            	hideImgContent('waitingDiv');
	                document.getElementById('div_content').innerHTML = result;
	            }});
	        showImgContent('waitingDiv');
	        req.send();
    	
    }



function doc_print(query)
{
	window.open('./ajax/profileSummary.php?epf='+query,'Print','left=20,top=20,width=950,height=500,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	
}


	
</script>
<style>
@media print {
   thead {display: table-header-group;}
}
</style>
<style>
.comboBox {
	width: 200px;
}
.advcomboBox {
	width: 150px;
}
</style>


<div class="box_header">
<form id="grid_form">
<input type="hidden" name="advSch" id="advSch" value="0" /> 
<div >
<h1>Search Employee</h1>
<table width="95%" height="208" class="grid_head_tbl">


	<tr>
	  <td>E.P.F.</td>
	  <td><label for="epf"></label>
	    <input type="text" name="epf" id="epf" /></td>
	  <td colspan="2">Comma Separated. Eg: xxxxa,xxxxb,xxxxc</td>
	  <td style="padding-right:5px;">&nbsp;</td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>Surename</td>
	  <td><input type="text" name="surename" id="surename" /></td>
	  <td colspan="3" rowspan="7"><h3><strong>Search Employee Options
	    </strong></h3>
	    <br/>      
	    User can search any combination offered by form.
	    <br />
  <br/> 
	    Province/District/Electorate options are functioning according to present address unless select Province/District/Electorate
<br />
  <br/>         
        Use one of the join date From/To to get join exact date. By setting both dates you can search with in a rage of dates. 
  <br/><br/>         
Note: FROM date &lt; TO date

	   </td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>NIC</td>
	  <td><input type="text" name="nic" id="nic" /></td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>File Number</td>
	  <td><input type="text" name="filenumber" id="filenumber" /></td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>Date of Birth</td>
	  <td><input type="text" name="dateofbirth" id="dateofbirth" onclick="clearField(this)"/></td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>Sex</td>
	  <td><select name="sex" id="sex"
			
			class="comboBox">
	    <option value="0" selected="selected">Any</option>
	    <option value="M">Male</option>
	    <option value="F">Female</option>
	    </select></td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>Religion</td>
	  <td><select name="religion" id="religion"
			
			class="comboBox">
	    <option></option>
	    </select></td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td>Nationality</td>
	  <td><select name="nationality" id="nationality"
			
			class="comboBox">
	    <option></option>
	    </select></td>
	  <td >&nbsp;</td>
	  </tr>
	<tr>
	  <td colspan="6"><table width="100%" border="0">
	    <tr>
	      <td width="8%">Provinces</td>
	      <td width="23%"><select name="provinces" id="provinces"
			
			onChange="load_district();"
			class="comboBox">
	    <option></option>
        </select>
        </td>
	      <td width="9%">District</td>
	      <td width="23%"><select name="district" id="district" class="comboBox" onChange="load_electorate();">
	        <option value="0" selected="selected">Any</option>
	        
	        <option></option>
	        </select></td>
	      <td width="8%">Electorate</td>
	      <td width="29%"><select name="electorate" id="electorate"
			
			class="comboBox">
	        <option value="0" selected="selected">Any</option>
	        
	        <option></option>
	        </select></td>
	      </tr>
	    </table></td>
	  </tr>
	<tr>
	  <td width="15%">Region</td>
	  <td width="25%"><select name="reigon" id="reigon"
			onChange="load_region();" onkeydown="focus_next(event,'depot')"
			class="comboBox">
	    <option></option>
	    </select></td>
	  <td width="15%">Depot</td>
	  <td width="20%"><select name="depot" id="depot" class="comboBox">
	    <option value="0">Any</option>
      </select></td>
	  <td width="13%" style="padding-right:5px;">&nbsp;</td>
	  <td width="25%" >&nbsp;</td>	
	  </tr>
	<tr>
	  <td style="padding-right:5px;">Grading</td>
	  <td ><select name="grading" id="grading"
			onchange="load_designation();" class="comboBox">
	    <option></option>
	    </select></td>
	  <td style="padding-left:5px;">Designation</td>
	  <td><select name="designation" id="designation" class="comboBox">
	    <option value="0">Any</option>
	    </select></td>
	  </tr>
	<tr>
	  <td style="padding-right:5px;">Join Date</td>
	  <td >From 
	    <input type="text" name="joinFrom" id="joinFrom" onclick="clearField(this)"/></td>
	  <td style="padding-left:5px;">To</td>
	  <td><input type="text" name="joinTo" id="joinTo" onclick="clearField(this)"/></td>
	  </tr>
	<tr>
	  <td style="padding-right:5px;">&nbsp;</td>
	  <td >&nbsp;</td>
	  <td style="padding-left:5px;">&nbsp;</td>
	  <td>&nbsp;</td>
	  </tr>
	<tr>
	  <td style="padding-right:5px;">Order By</td>
	  <td ><select name="order_by" id="order_by" class="comboBox">
	    <option value="epf" selected="selected">EPF No</option>
	    <option value="region">Region</option>
	    <option value="depot">Depot</option>
	    <option value="grading">Grading</option>
	    <option value="designation">Designation</option>
	    <option value="sex">Sex</option>
      </select></td>
	  <td style="padding-left:5px;">Then</td>
	  <td><select name="order_by2" id="order_by2" 
			class="comboBox">
	    <option value="epf">EPF No</option>
	    <option value="region">Region</option>
	    <option value="depot">Depot</option>
	    <option value="grading">Grading</option>
	    <option value="designation">Designation</option>
	    <option value="sex" selected="selected">Sex</option>
	    </select></td>
	  </tr>
	<tr>
	  <td style="padding-right:5px;">&nbsp;</td>
	  <td >&nbsp;</td>
	  <td style="padding-left:5px;">&nbsp;</td>
	  <td>&nbsp;</td>
	  </tr>
	<tr>	
			
		<td width="15%" style="padding-right:5px;">Show Images</td>
		<td width="25%" ><select name="showImages" id="showImages" class="comboBox">
		  <option value="y">Show Images On Search</option>
		  <option value="n" selected="selected">Dont Show Images On Search</option>
        </select></td>		
		<td width="15%" style="padding-left:5px;">&nbsp;</td>
		<td width="20%">&nbsp;</td>
			
	</tr>

</table>
</div>
<div>
<p style="">
	<a href="javascript:divContent('advSearchPanel');" style="color: #FF0033; font-size: 12px; text-decoration: none;cursor: pointer" >Advance Search</a>
</p>
<div id="advSearchPanel" style="display:none;">
<table class="grid_head_tbl">

	
	<tr>
	<td width="18%" style="padding-right: 5px;">From Date</td>
		<td width="15%"><input type="text" name="fromDate" id="fromDate" onclick="clearField(this)"/></td>
		<td width="28%" style="padding-right: 5px;">To Date</td>
		<td width="15%"><input type="text" name="toDate" id="toDate" onclick="clearField(this)"/></td>
		
	</tr>
</table>
</div>
<table class="grid_head_tbl">

	<tr align="right">	
		<td colspan="3" style="align:right;padding-left:880px;">
		<input type="button" value="Search" onclick="javascript:load_stock_paper()" />
		</td>
	</tr>

</table>

<br />
<br />
<br />
</div>
</form>
<div id="waitingDiv" style="display: none;">
<img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/>
</div>
<div id="div_content"></div>
</div>

