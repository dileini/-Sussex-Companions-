<!-- vaidation  area-->

<script language="javascript">

//others validate
function validate()
{
  
	
	 if (document.employe.drop_1.value == 'sefpf') 
    {
        alert('Please select EPF number!');
        return false;
    }
	 if (document.employe.img.value == '') 
    {
        alert('Please select Employe photo!');
        return false;
    }
	 
	
    return true;
}

</script>
<script language="javascript">
function validates()
{
    if (document.approved.drop_1.value == 'sefpf') 
    {
        alert('Please select EPF Number!');
        return false;
    }
	
    return true;
}
</script>
<!-- vaidation  areaend-->
<style type="text/css">

.img {
	border: 1px solid #993300;
	margin: 5px;
	padding: 5px;
}

input#fname:hover, input#fname:focus {
border: 1px solid #000000;
background-color: #CCCCCC;
color: #000000;
}
input#lname:hover, input#lname:focus {
border: 1px solid #000000;
background-color: #cccccc;
color: #000000;
}
textarea#address:hover, textarea#address:focus {
border: 1px solid #000000;
background-color: #CCCCCC;
color: #000000;
}

input#tp:hover, input#tp:focus {
border: 1px solid #000000;
background-color: #cccccc;
color: #000000;
}
input#uname:hover, input#uname:focus {
border: 1px solid #000000;
background-color: #CCCCCC;
color: #000000;
}
input#pass:hover, input#pass:focus {
border: 1px solid #000000;
background-color: #CCCCCC;
color: #000000;
}
input#cpass:hover, input#spass:focus {
border: 1px solid #000000;
background-color: #CCCCCC;
color: #000000;
}

</style>

<!--calander scrip start-->
<style type="text/css">
	body{
		/*
		You can remove these four options 
		
		*/
		background-repeat:no-repeat;
		font-family: Trebuchet MS, Lucida Sans Unicode, Arial, sans-serif;
		margin:0px;
		

	}
	#ad{
		padding-top:220px;
		padding-left:10px;
	}
	</style>
	<link type="text/css" rel="stylesheet" href="css/calendar.css?random=15112000" media="screen"></LINK>
	<SCRIPT type="text/javascript" src="js/calendar.js?random=15112000"></script>
<!--calander scrip end-->

 <?php
 error_reporting(0);
	
	 ?>
<!--chain select start-->
<script type="text/javascript" src="code/chainselect/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$('#wait_1').hide();
	$('#drop_1').change(function(){
	  $('#wait_1').show();
	  $('#result_1').hide();
      $.get("code/chainselect/name.php", {
		func: "drop_1",
		drop_var: $('#drop_1').val()
      }, function(response){
        $('#result_1').fadeOut();
        setTimeout("finishAjax('result_1', '"+escape(response)+"')", 400);
      });
    	return false;
	});
});

function finishAjax(id, response) {
  $('#wait_1').hide();
  $('#'+id).html(unescape(response));
  $('#'+id).fadeIn();
}
</script>
<!--chain select end-->




<?php
	//error_reporting(0);
	include('db-config.php');
	
	/*$depot=$_SESSION['user_depot'];
	$machine_number=$_SESSION['user_machine_number'];
	$username=$_SESSION['user_name'];
	$randnumber=$_SESSION['randomeNumber'];
	$Numdivision=$_SESSION['havemoredivi'];*/
 
 ?>
 <?php

	
	include('code/chainselect/name.php');
	
?>
    
    
    
   
<!--sub link-->
<?php //include('sublinks/employee.php');  ?>

<div id="enter">
	
   
   
   <div id="enter-title">
  Insert Employe Photo
    </div>
    <div id="form">
    	<form action="" name="employe" method="post" enctype="multipart/form-data" onSubmit="return validate()">
    	
       
         <div id="form-line">
        	<div id="form-line-left">
            Select EPE :
            </div>
            <div id="form-line-riht">
        	<p>
                <select name="drop_1" id="drop_1"  class="select">
                
                  <option value="sefpf" selected="selected" disabled="disabled">-Select a EPF Number-</option>
                    <?php getTierOne(); ?>
                </select> 
                
                
                <span id="wait_1" style="display: none;">
                <img alt="Please Wait" src="image/ajax-loader.gif"/>
                </span>
                <span id="result_1" style="display: inline;"></span> 
              
        
            </p>
            </div>
        </div>
		
		<div id="form-line">
        	<div id="form-line-left">
            Select Photo :
            </div>
            <div id="form-line-riht">
        	<input type="file" name="img" id="img" /> <font color="#990000">3.5cm X 4.5cm</font>
            </div>
        </div>
		
        <div id="submit">
        <br />
        	<input type="submit" name="submit" value="Submit" class="formbutton"/>

        </div>
        
    
      </form>
    </div>
   

   
</div>

<?php
	if ( isset($_POST['submit'])){  


$timezone_offset = +5.5; // us central time (gmt-6) for me
$date = gmdate('d-m-Y ,h.i a ', time()+$timezone_offset*60*60);
$datee = gmdate('MdYhia', time()+$timezone_offset*60*60);
$date2 = gmdate('Y/m/d', time()+$timezone_offset*60*60);//like --- 2011/03/12 --
$ip=$_SERVER['REMOTE_ADDR'];

$epf=$_POST['drop_1'];
	
$rand=rand(1,100000000);
$username=$_SESSION['user_name'];
	
	list($width, $height) = getimagesize($_FILES['img']['tmp_name']);
	//list($width, $height) = getimagesize("$_FILES['file']");
	$maxheight = 400;
	$maxwidth = 500;
	if ($width > $maxwidth) {
	
	echo
	("<font color=\"#FF0000\"><SCRIPT LANGUAGE='JavaScript'>
				window.alert('Your image file was too large,  please reduce image size')
	</SCRIPT></font>"); 
	} else {
	
	$impath='images/';
	$h1=rand(1, 100000000000);
              $imagename = $h1.'_'.$_FILES['img']['name'];
              $source = $_FILES['img']['tmp_name'];
             $target = $impath.$imagename;
              move_uploaded_file($source, $target);  
 				
				
               
			 $imagepath = $imagename; 
			 
			 //step 1  
			 
             $save = $impath . $imagepath; //This is the new file you saving
              $file = $impath . $imagepath; //This is the original file 
 		     
 		     
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = $width; 
 
              $diff = $width / $modwidth;
 
              $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
              $image = @imagecreatefromgif($file) or 
			  $image = @imagecreatefromjpeg($file) ;
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
 
              imagejpeg($tn, $save, 100) ; 
			  
			  
			  //step 2
			  // $h=rand(1, 10000000000);
              $save = $impath."min". $imagepath; //This is the new file you saving
              $file = $impath . $imagepath; //This is the original file
 
 
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = 200; 
			  //$modheight = 70; 
 
              $diff = $width / $modwidth;
			  //$diff = $height / $modheight ;
 
              
			  $modheight = $height / $diff; 
			  //$modwidth = $width / $diff;
			  
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
              $image = @imagecreatefromgif($file) or 
			  $image = @imagecreatefromjpeg($file) ; 
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
 
              imagejpeg($tn, $save, 100) ; 
			  
			  
			  
			  
	  
	  //image rize end
$minimageup='min'.$imagepath;
$imagelarg=$imagename;
	
	


	$temp=mysql_query("UPDATE personalinfo SET originalimage='$imagelarg',image='$minimageup',recordProcessedDate='$date',userID='$username' WHERE epfNo='".$epf."'") or die("update  error".mysql_error());
	
	
								//$statu=$_GET['status'];
								$viewcount=mysql_query("SELECT status FROM  personalinfo ORDER BY status DESC LIMIT 1") or die("SELECT ERROR:".mysql_error());
								
								$viewcount_info=mysql_fetch_array($viewcount);
								//$dateviewcount=$viewcount_info['ho_date'];
								$downloadc=$viewcount_info['status'];
						
								$downloadc=++$downloadc;
						
								mysql_query("UPDATE personalinfo  SET  status ='$downloadc' WHERE epfNo='$epf' ");
								

								
								
								echo
								("<SCRIPT LANGUAGE='JavaScript'>
											window.alert('Upload Successfully')
								</SCRIPT>"); 
	}

	
	/* } else {
	
		echo
	("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Already exist photo')
	</SCRIPT>"); 
	
	
	} */
	  




?>
<div id="enter">
	<div id="form">
 <img src="images/<?php echo  $minimageup; ?>" class="img" align="bottom" width="200" height="auto" /> <br />
 <p>&nbsp;&nbsp;<?php echo $epf; ?></p>
 	</div>
</div>
<?php


}
 ?>
 
 <div id="enter">
	<div id="form">
	<font color="#990000" style="font-family:'Times New Roman', Times, serif; font-size:14px; font-weight:600; text-decoration:underline;">Updated Employees</font> <br/><br/>
	<?php 
	$image=mysql_query("SELECT * FROM  personalinfo WHERE image <> '' ORDER BY epfNo DESC") or die("SELECT ERROR:".mysql_error());
	//$image_info=mysql_fetch_array($image);	
	while($image_info=mysql_fetch_array($image)){					
	?>
	<?php echo $image_info['epfNo']; ?> &nbsp;&nbsp;  <?php echo $image_info['initials']; ?> <?php echo $image_info['surName']."<br/>";  }?> 
 	</div>
</div>
 


