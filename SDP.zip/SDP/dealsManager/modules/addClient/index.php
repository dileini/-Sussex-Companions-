<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/account/combo.js"> </script>
<script type="text/javascript" src="js/account/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">
    var formcheck;
    window.addEvent('domready', function() {
		formcheck = new FormCheck('grid_form',{
												display : {
													showErrors:1,	
													closeTipsButton : 0,
													keepFocusOnError : 1,
													flashTips : 1
												},
												alerts : {
													required : 'This feield is required..!'
												}
											   });

        //load_combo_data('ajax/regions.php','reigon','region_text','region_id','change=true');
        //load_userLevel();
		load_hobbies();
		load_interrests();
		load_locations();
    });
// save button function
    function saveUser(){

		if (formcheck.checkValidation()) {

			if(document.getElementById('hb').value == "0")
			{
				alert("Please select a Hobbie");
				document.getElementById('hb').focus();
			}
			else if(document.getElementById('inter').value == "0")
			{
				alert("Please select an interest");
				document.getElementById('inter').focus();
			}
			else if(document.getElementById('loc').value == "0")
			{
				alert("Please select a office location");
				document.getElementById('loc').focus();
			}
			else if(document.getElementById('pass').value != document.getElementById('conpass').value)
			{
				alert("Please confirm the correct password");
				document.getElementById('conpass').focus();
			}
			else
			{
				//document.querySelector('input[name="gender"]:checked').value
				var query = "first_name="+document.getElementById('first_name').value
				+"&last_name="+ document.getElementById('last_name').value
				+"&nic="+document.getElementById('nic').value
				+"&Gender="+document.querySelector('input[name="Gender"]:checked').value
				+"&tel_no="+document.getElementById('tel_no').value
				+"&email="+document.getElementById('email').value
				+"&hb="+document.getElementById('hb').value
				+"&inter="+document.getElementById('inter').value
				+"&loc="+document.getElementById('loc').value
				+"&address="+document.getElementById('address').value
				+"&pass="+document.getElementById('pass').value;
				var url = 'ajax/saveUser.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						//alert(result);
						
						if(result.trim() == '01')
						{
							alert('New client added sucessfully')
							window.location.reload();
						}
						else
						{
							alert('Error Occored, Pl. try again..');
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

			}
		}
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Register New Client</p>
<form id="grid_form">
<table width="400px" border="0" class="grid_head_tbl">
  <tr>
    <td>First Name : </td>
    <td><input type="text" value=""  name="first_name" id="first_name" style="width:180px;" class="validate['required','nodigit']"/></td>
  </tr>
  <tr>
    <td>Last Name : </td>
    <td><input type="text" value=""  name="last_name" id="last_name" style="width:180px;" class="validate['required','nodigit']"/></td>
  </tr>
  <tr>
    <td>NIC</td>
    <td><input type="text" value=""  name="nic" id="nic" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
    <td>Gender</td>
    <td><p>
      <label>
        <input name="Gender" type="radio" id="Gender_0" value="m" checked="checked" />
        Male</label>
      <label>
        <input type="radio" name="Gender" value="f" id="Gender_1" />
        Female</label>
      <br />
    </p></td>
  </tr>
  <tr>
    <td>Telephone Number</td>
      <td><input type="text" value=""  name="tel_no" id="tel_no" style="width:180px;" class="validate['required','digit','length[10,-1]']"/></td>
  </tr>
  <tr>
    <td>E-mail</td>
    <td><input type="text" value=""  name="email" id="email" style="width:180px;" class="validate['required','nodigit']"/></td>
  </tr>
  <tr>
    <td>Hobbie</td>
    <td><select name="hb" id="hb"  style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  <tr>
    <td>Interest</td>
    <td><select name="inter" id="inter" style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  <tr>
    <td>Location</td>
    <td><select name="loc" id="loc" style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  <tr>
    <td>Address : </td>
    <td><input type="text" value=""  name="address" id="address" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
      <td>Password</td>
      <td><input type="password" value=""  name="pass" id="pass" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
      <td>Confirm Password</td>
      <td><input type="password" value=""  name="conpass" id="conpass" style="width:180px;" class="validate['confirm[pass]']"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td colspan="3" style="align:right;padding-left:200px;">
		<input type="button" value="Ad New Client" onclick="saveUser()" />
		</td>
	</tr>

</table>
</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>