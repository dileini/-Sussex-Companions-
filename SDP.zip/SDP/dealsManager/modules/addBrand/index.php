<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/addCategory/combo.js"> </script>
<script type="text/javascript" src="js/addCategory/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">

    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{showErrors:1});
		
		new Picker.Date($('fromDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2017-01-01',
         	maxDate: '2020-03-01'
	    });
		
		new Picker.Date($('toDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2017-01-01',
          	maxDate: '2020-03-01'
	    });
		
		load_catos();
    });

    function saveCatos()
	{
		if (formcheck.checkValidation()) 
		{

				var query = "jobmane="+$('jobmane').value
				           +"&companyName="+ $('companyName').value
						   +"&desc="+ $('desc').value
						   +"&fromDate="+ $('fromDate').value
						   +"&toDate="+ $('toDate').value
						   +"&jobCat="+ $('job').value
						   +"&poss="+ $('poss').value;
				var url = 'ajax/saveJobs.php';

				alert($('job').value);
				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						alert(result);
						
						if(result =='1')
						{
							alert('Job sucessfully added..!')
							window.location.reload();
						}
						if(result =='2')
						{
							alert('Inserting problem occor.')
							//window.location.reload();
						}
						else
						{
							alert('Job not posted. Try again..!')
							//window.location.reload();
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

			}
		
    }
	
	function loadImage(myImage)
	{
		
		var query = "jobid="+myImage;
				var url = 'ajax/loadSlidShowJobImage.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result)
					{
						//alert(result);
						hideImgContent('waitingDiv');
						
						$('adImage').style.display = "inline";
						$('adImage').innerHTML = result;			
					}});
				showImgContent('waitingDiv');
				req.send();

	}

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Add Brand Image - Size 404px X 200px </p>
<form action="./ajax/uploadBrandImage.php" method="post" enctype="multipart/form-data">
<table width="611" border="0" class="grid_head_tbl">
  
  <tr>
    <td>Brand Name : </td>
    <td><input type = "text" name="bname"></td>
  </tr>
  
  <tr>
    <td>Avaliable Image</td>
    <td><div id="adImage" style="display:none"><img src="images/jobPics/noJobImage.jpg" width="401" height="401" /></div></td>
  </tr>
  <tr>
    <td>Select New Image : </td>
    <td><input type="file" name="file" id="file"></td>
  </tr>
  
  
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td style="align:right;padding-left:200px;">
		<input type="submit" name="submit" value="Upload Image">
		</td>
	</tr>

</table>


</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>