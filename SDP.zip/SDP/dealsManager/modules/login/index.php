
<form action="./modules/login/action/do.php" method="post" >

<input id="username" type="text" name="username" />
<br style="clear: both">
<input id="password" type="password" name="password" />
<br style="clear: both">

  <input id="submit" type="image" src="images/login_button.jpg" type="submit" />
  
</form>
<?php 
     if(isset($_GET['error'])) 
     {
	 	if($_GET['error'] == 1)
		{	
 ?>
<span style="position: relative;top:190px;left:35px;color:#ff0000">Wrong Username or Password</span>
<?php 
		}
     
?>
<?php 
     if($_GET['error'] == 2)
     {
 ?>
<span style="position: relative;top:190px;left:35px;color:#ff0000">Please Log in again.</span>
<?php 
     }
?>

<?php 
     if($_GET['error'] == 3)
     {
 ?>
<span style="position: relative;top:190px;left:35px;color:#ff0000">Your Account has been blocked. Contact Administrator.</span>
<?php 
     }
?>
<?php 
     if($_GET['error'] == 4)
     {
 ?>
<span style="position: relative;top:190px;left:35px;color:#ff0000">Your Session has been expired. Please Log in again.</span>
<?php 
     }
	 
	 }
?>
