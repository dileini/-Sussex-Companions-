<?php

session_start();
error_reporting(E_ALL);
include("../../../db_connector.php");

$username = $_POST ['username'];
$password = md5($_POST ['password']);

$selectUser = "SELECT `username`, `password` , `status`, `user_id`
	FROM `users`
WHERE `username`='$username' AND `password`='$password'";

$userResult = mysql_query($selectUser);

if(mysql_num_rows($userResult) == 0){
	$_SESSION ['logged_in'] = false;
	$_SESSION ['username'] = NULL;
	$_SESSION ['user_id'] = NULL;
	header ( 'Location:../../../index.php?error=1' );
}
else{
	$row = mysql_fetch_array($userResult);
	$_SESSION['username']    = $username;
	$_SESSION['logged_in']   = true;
	$_SESSION['user_id']     = $row['user_id'];
	$_SESSION['sessionBegi'] = session_id();	
	
	if($row['status'] == 0){
		$authQuery = "select `region_auth_id`, `user_id`, `region_id`, `deport_id`, `user_level` from region_auth where user_id =" . $row['user_id'];
		$authQueryRes = mysql_query($authQuery);
		$mySub = mysql_fetch_array($authQueryRes);
		$_SESSION ['user_level'] = $mySub['user_level'];
		
		if ($mySub['user_level'] != 1){
			$_SESSION ['user_deport'] = $mySub['deport_id'];
			$_SESSION ['user_region'] = $mySub['region_id'];		
		}	
	header ( 'Location:../../../main.php' );	
	}
	else{
		header ( 'Location:../../../index.php?error=3' );
	}
}
?>
