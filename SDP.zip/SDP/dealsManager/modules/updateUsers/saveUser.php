<?php 
session_start();
require_once('../../db_connector.php');


//echo "HIII";
$userid    = $_GET['p']; //user ID
$firstname = $_GET['q']; //First Name
$lastname  = $_GET['r']; //Last name
$address   = $_GET['s']; //Address
$phone   = $_GET['t']; //Address

$updateUser = "update user_details set first_name='$firstname',last_name='$lastname',Address='$address',tel_no='$phone' where user_id=$userid";
$updateUserExecute = mysql_query($updateUser);

if(mysql_affected_rows() >0)
{
	echo("User Saved...!");
}

	else 
	{
		echo"Error updating User, Please Try again later..!"; 
	}

?>
