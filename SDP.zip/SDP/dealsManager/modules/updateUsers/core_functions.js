function saveNewUser(str)
{
	
	var fname 	= document.getElementById('fname').value;
	var lname 	= document.getElementById('lname').value;
	var address = document.getElementById('address').value;
	var phone = document.getElementById('phone').value;
	saveUser(str,fname,lname,address,phone);
	
	
}