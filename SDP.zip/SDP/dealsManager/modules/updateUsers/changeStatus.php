<?php
session_start();
require_once('../../db_connector.php');

$userID = $_GET['q'];
$newStat = $_GET['p'];

$chamgeStatus ="update users set status='$newStat' where user_id='$userID'";
$changeStatusExecute = mysql_query($chamgeStatus);

if(mysql_affected_rows() >0)
{
	echo "Account Enabled...!";
}

	else 
	{
		echo "Account Disabled...!";
	}

?>
