<script type="text/javascript"  src="modules/updateUsers/changeStat.js"> </script>

<?php

session_start();
require_once('../../db_connector.php');
$userID = $_GET['q'];

$checkAvailability = "SELECT users.username, user_details.image_url,user_details.tel_no, ud.user_id,ud.first_name,ud.last_name,ud.gender,ud.Address, users.status from user_details ud 
	left join users on users.user_id = ud.user_id left join user_details on user_details.user_id = ud.user_id where ud.user_id=$userID";
$checkAvailExecute = mysql_query($checkAvailability);

if(mysql_num_rows($checkAvailExecute) != 0) 
{ 
	?>
  <table width="100%" border="1">
<tr>
      <td width="50%"><?php 
  	
      while ($row = mysql_fetch_array($checkAvailExecute))
		{
      		$_SESSION['$USERID'] = $userID;
		    ?>
		    
      
<form id="form1" name="form1" method="post" action="">
<table width="100%" border="0">
      <tr>
        <td>User ID</td>
        <td><label>
          <input type="text" name="userid" id="userid" readonly="readonly" value="<?php echo $userID; ?>"/>
        </label></td>
      </tr>
      <tr>
        <td>User Name</td>
        <td><label>
          <input type="text" name="uname" id="uname" readonly="readonly" value="<?php echo $row['username']; ?>"/>
        </label></td>
      </tr>
      <tr>
            <td width="16%">First Name</td>
            <td width="84%"><label>
              <input type="text" name="fname" id="fname" value="<?php echo $row['first_name']; ?>"/>
            </label></td>
          </tr>
          <tr>
            <td>Last Name</td>
            <td><input name="lname" type="text" id="lname" value="<?php echo $row['last_name']; ?> " /></td>
          </tr>
          <tr>
            <td>Phone</td>
            <td><input name="phone" type="text" id="phone" value="<?php echo $row['tel_no']; ?> " /></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><textarea name="address" rows="3" id="address"><?php echo $row['Address']; ?>
</textarea></td>
          </tr>
          <tr>
            <td>User Status</td>
            <td><table width="100%" border="0">
              <tr>
                <td width="52%"><?php 
            
            if($row['status']==NULL)
			{
				echo "Please set the Status";
				?>
                <table width="11%" height="29" border="0">
  <tr>
    <td width="13%" height="23"><a href="javascript:changeStatus(<?php echo $userID; ?>,0)"><img src="modules/updateUsers/spics/greenb.jpg" width="30" height="30"/></a><a href="javascript:changeStatus(<?php echo $userID; ?>,0)"></a><a href="javascript:changeStatus(<?php echo $userID; ?>,1)"></a><a href="javascript:changeStatus(<?php echo $userID; ?>,1)"></a></td>
    <td width="87%"><a href="javascript:changeStatus(<?php echo $userID; ?>,0)"><img src="modules/updateUsers/spics/redb.jpeg" width="30" height="30" /></a></td>
  </tr>
</table>
                <?php
			}
			
			if($row['status'] =='0')
			{
			
			?>
            <table width="69%" height="29" border="0">
  <tr>
    <td width="5%" height="23" align="left"><img src="modules/updateUsers/spics/greenb.jpg" width="30" height="30" /></td>
    <td width="95%" align="left" valign="middle"><a href="javascript:changeStatus(<?php echo $userID; ?>,1)">Click to Disable</a></td>
  </tr>
</table>
            
            <?php
			
			}
			if($row['status'] =='1')
			{
			
			?>
            
            <table width="69%" height="29" border="0">
  <tr>
    <td width="5%" height="23" align="left"><img src="modules/updateUsers/spics/redb.jpeg" width="30" height="30" /></td>
    <td width="95%" align="left" valign="middle"><a href="javascript:changeStatus(<?php echo $userID; ?>,0)">Click to Enable</a></td>
  </tr>
</table>
            
            
            
            <?php

			}
			
            ?>
            <label></label></td>
                <td width="48%" valign="middle" align="left"><div id="statusme"> Click Enable or Disable.</div></td>
              </tr>
            </table>            </td>
          </tr>
          <tr>
            <td>Image URL</td>
            <td><?php echo $row['image_url']; ?></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>
            <?php 
			if($row['image_url'] == NULL)
			{
				?>
				<Iframe src="modules/updateUsers/imageupload/ck.php" width="300" height="400"></Iframe>
				<?php 
			}
			else 
			{
				?>
				<table width="16%" border="0">
				  <tr>
				    <td><img src="<?php echo 'images/users/'.$row['image_url']; ?>" width="210" height="210"></td>
				  </tr>
				</table>
				
				
				<?php 				
			}
			
			
			?>            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><table width="100%" border="0">
              <tr>
                <td width="20%"><a href="javascript:saveNewUser(<?php echo $userID; ?>)">Save Details</a></td>
                <td width="80%"><div id="savestat"> Details Not saved yet.</div></td>
              </tr>
            </table></td>
          </tr>
        </table>
      <br />
      <?php 
		  
		}
  }
  else 
  {
  	echo "No Records Bro...! :D";
  }


?>
</form>
</td></tr></table>   