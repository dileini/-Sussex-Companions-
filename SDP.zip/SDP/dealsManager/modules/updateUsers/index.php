<script type="text/javascript"  src="modules/updateUsers/users.js"> </script>
<script type="text/javascript"  src="modules/updateUsers/changeStat.js"> </script>
<script type="text/javascript"  src="modules/updateUsers/saveUser.js"> </script>
<script type="text/javascript"  src="modules/updateUsers/core_functions.js"> </script>
<div class="box_header">
<?php
//session_start();
require_once('db_connector.php');

$checkAvailability = "SELECT ud.user_id,ud.first_name,ud.last_name,ud.gender,ud.Address,tel_no, users.status from user_details ud 
	left join users on users.user_id = ud.user_id";
$myqAvailable = mysql_query($checkAvailability);
if(mysql_num_rows($myqAvailable) != 0) 
{    
	 
	?>
<table width="50%" border="0">
  <tr>
    <td width="5%">ID</td>
    <td width="22%">First Name</td>
    <td width="21%">Last Name</td>
    <td width="19%">Phone</td>
    <td width="23%">Address</td>
    <td width="10%"> Status</td>
  </tr>
</table>
<br />
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="1">
    <tr>
      <td width="50%"><?php 
  		while ($row = mysql_fetch_array($myqAvailable))
		{
		    ?>
          <table width="100%" border="0">
            <tr>
              <td width="5%"><a href="javascript:showCustomer(<?php echo $row['user_id']; ?>)" ><?php echo $row['user_id']; ?></a></td>
              <td width="22%"><?php echo $row['first_name']; ?></td>
              <td width="21%"><?php echo $row['last_name']; ?></td>
              <td width="19%"><?php echo $row['tel_no']; ?></td>
              <td width="23%"><?php echo $row['Address']; ?></td>
              <td width="10%"><?php echo $row['status']; ?></td>
            </tr>
          </table>
        <?php 
		  
		}
  }
  else 
  {
  	echo "No Records Bro...! :D";
  }

?></td>
      <td width="50%" valign="top" align="left"><div id="txtHint"> Please select one user for update his/her data.</div></td>
    </tr>
  </table>
</form>
</div>
