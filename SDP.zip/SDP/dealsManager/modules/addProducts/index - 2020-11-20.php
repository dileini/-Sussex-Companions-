<script src="js/ckeditor/ckeditor.js"></script>
<link rel="stylesheet" href="sample.css">
<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/addCategory/combo.js"> </script>
<script type="text/javascript" src="js/addCategory/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">
    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{
												display : {
													showErrors:1,	
													closeTipsButton : 0,
													keepFocusOnError : 1,
													flashTips : 1
												},
												alerts : {
													required : 'This feield is required..!'
												}
											   });
		new Picker.Date($('toDate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2020-11-10',
         	maxDate: '2021-11-01'
	    });
		
		load_catos();
    });

    function saveCatos()
	{
		if (formcheck.checkValidation()) 
		{

				if($('job').value == '0')
				{
					alert('Please select product category');
					$('job').focus();
				}
				
				else
				{

					var desValue = CKEDITOR.instances.productDesc.getData();
					
					var query = "productName="+$('productName').value
					           +"&productDesc="+ desValue
							   +"&productDisCount="+ $('productDisCount').value
							   +"&productNormalPrice="+ $('productNormalPrice').value
							   +"&productSave="+ $('productSave').value
							   +"&productFinalPrice="+ $('productFinalPrice').value
							   +"&toDate="+ $('toDate').value
							   +"&job="+ $('job').value
							   +"&productItems="+ $('productItems').value;
					var url = 'ajax/saveProducts.php';
	
					var req = new Request({method: 'POST',
						data:query,
						url: url,
						onSuccess: function(result){
							hideImgContent('waitingDiv');
							//alert(result);
							
							if(result =='1')
							{
								alert('Product sucessfully added..!')
								window.location.reload();
							}
							if(result =='2')
							{
								alert('Inserting problem occor.')
								//window.location.reload();
							}
							else
							{
								alert('Product not posted. Try again..!')
								//window.location.reload();
							}
							
						}});
					showImgContent('waitingDiv');
					req.send();
				
				}

			}
		
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Add New Product</p>
<form enctype="multipart/form-data" id="grid_form" action="">
<table width="637" border="0" class="grid_head_tbl">
  <tr>
    <td width="76" align="left" valign="top"><strong>Product Name : </strong></td>
    <td width="551"><input  name="productName" type="text" class="validate['required','nodigit']" id="productName" style="width:450px;" value="" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Product Description:</strong></td>
    <td><textarea name="productDesc" rows="30" class="ckeditor" id="productDesc" style="width:450px;"></textarea></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Product Category:</strong></td>
    <td><select name="job" id="job" style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Off Percentage: </strong></td>
    <td><input  name="productDisCount" type="text" class="validate['required','length[1,2]','number']" id="productDisCount" style="width:25px;" value="" maxlength="5"/>
    %</td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Original Price: </strong></td>
    <td><input  name="productNormalPrice" type="text" class="validate['required','number']" id="productNormalPrice" style="width:100px;" value="" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>You Save:</strong></td>
    <td><input  name="productSave" type="text" class="validate['required','number']" id="productSave" style="width:100px;" value="" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Final Price:</strong></td>
    <td><input  name="productFinalPrice" type="text" class="validate['required','number']" id="productFinalPrice" style="width:100px;" value="" /></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Closing Date:</strong></td>
    <td><input type="text" value=""  name="toDate" id="toDate" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
    <td align="left" valign="top"><strong>Number Items on stock:</strong></td>
    <td><input  name="productItems" type="text" class="validate['required','number']" id="productItems" style="width:180px;" value="" size="4" maxlength="3"/></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td><label for="fileField"></label></td>
  </tr>
  
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td style="align:right;padding-left:200px;">
		<input type="button" value="Save Product" onclick="saveCatos()" />
		</td>
	</tr>

</table>


</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>