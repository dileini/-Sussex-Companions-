<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/account/combo.js"> </script>
<script type="text/javascript" src="js/account/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">
    var formcheck;
    window.addEvent('domready', function() {
		formcheck = new FormCheck('grid_form',{
												display : {
													showErrors:1,	
													closeTipsButton : 0,
													keepFocusOnError : 1,
													flashTips : 1
												},
												alerts : {
													required : 'This feield is required..!'
												}
											   });
		load_hobbies2();
		load_interrests2();
		load_locations2();
    });
// save button function
    function searchClient(){

		if (formcheck.checkValidation()) {

				var query = "first_name="+document.getElementById('first_name').value
				+"&last_name="+ document.getElementById('last_name').value
				+"&nic="+document.getElementById('nic').value
				+"&Gender="+document.querySelector('input[name="Gender"]:checked').value
				+"&tel_no="+document.getElementById('tel_no').value
				+"&email="+document.getElementById('email').value
				+"&hb="+document.getElementById('hb').value
				+"&inter="+document.getElementById('inter').value
				+"&loc="+document.getElementById('loc').value;
				var url = 'ajax/searchUser.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						//alert(result);
						
						if(result.trim() == '01')
						{
							alert('New client added sucessfully')
							window.location.reload();
						}
						else
						{
							//alert('Error Occored, Pl. try again..');
							$('res').innerHTML=result;
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();
		}
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Search Client</p>
<form id="grid_form">
<table width="400px" border="0" cellpadding="2" cellspacing="2" class="grid_head_tbl">
  <tr>
    <td bgcolor="#CCCCCC">First Name : </td>
    <td bgcolor="#CC3399"><input type="text" value=""  name="first_name" id="first_name" style="width:180px;" /></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">Last Name : </td>
    <td bgcolor="#CC3399"><input type="text" value=""  name="last_name" id="last_name" style="width:180px;" /></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">NIC</td>
    <td bgcolor="#CC3399"><input type="text" value=""  name="nic" id="nic" style="width:180px;" /></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">Gender</td>
    <td bgcolor="#CC3399"><p>
      <label>
        <input name="Gender" type="radio" id="Gender_0" value="m" checked="checked" />
        Male</label>
      <label>
        <input type="radio" name="Gender" value="f" id="Gender_1" />
        Female</label>
      <br />
    </p></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">Telephone Number</td>
      <td bgcolor="#CC3399"><input type="text" value=""  name="tel_no" id="tel_no" style="width:180px;" /></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">E-mail</td>
    <td bgcolor="#CC3399"><input type="text" value=""  name="email" id="email" style="width:180px;" /></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">Hobbie</td>
    <td bgcolor="#CC3399"><select name="hb" id="hb"  style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">Interest</td>
    <td bgcolor="#CC3399"><select name="inter" id="inter" style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC">Location</td>
    <td bgcolor="#CC3399"><select name="loc" id="loc" style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  
  <tr>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CC3399">&nbsp;</td>
  </tr>
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td colspan="3" style="align:right;padding-left:200px;">
		<input type="button" value="Search" onclick="searchClient()" />
		</td>
	</tr>

</table>
</form></div>
<div id="res"> </div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>