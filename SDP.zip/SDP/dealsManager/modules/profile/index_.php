

<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/promotionhistory/combo.js"> </script>
<script type="text/javascript" src="js/promotionhistory/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css"
	type="text/css" media="screen" />
<link href="css/textStyles.css" rel="stylesheet">

<script src="js/Source/Locale.en-US.DatePicker.js"
	type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css"
	rel="stylesheet">

<script type="text/javascript">
var formcheck;

window.addEvent('domready', function() {
    
    formcheck = new FormCheck('grid_form',{showErrors:1});
    

   	/* new Picker.Date($('trasferFrom'), {
        positionOffset: {x: 5, y: 0},
        //format : '%d/%m/%Y',
		format : '%Y-%m-%d',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    });

	new Picker.Date($('trasferTo'), {
        positionOffset: {x: 5, y: 0},
        //format : '%d/%m/%Y',
		format : '%Y-%m-%d',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
    }); 
	*/
  	
	
          
});

function clearField(ele)
{
	ele.value = "";
}

	
function load_stock_paper(page){	
		    
	  	  var query =
		  			 "epf="+          $('epf').value;
				
					 
					

			var url = 'ajax/profileSummary.php';
					
	        var req = new Request({method: 'GET',
	            data:query,
	            url: url,
	            onSuccess: function(result){
	            	hideImgContent('waitingDiv');
	                document.getElementById('div_content').innerHTML = result;
	            }});
	        showImgContent('waitingDiv');
	        req.send();
  
    }


function printSelection(node){

  var content=node.innerHTML
  var pwin=window.open('','print_content','width=700,height=900');

  pwin.document.open();
  pwin.document.write('<html><body">'+content+'</body></html>');
  pwin.document.close();
 
  //setTimeout(function(){pwin.close();},1000);

}



	
</script>
<style>
@media print {
   thead {display: table-header-group;}
}
</style>
<style>
.comboBox {
	width: 200px;
}
.advcomboBox {
	width: 150px;
}
</style>


<div class="box_header">
<form id="grid_form">
<input type="hidden" name="advSch" id="advSch" value="0" /> 
<div >
<h1>Complete Profile</h1>
<table width="95%" height="91" class="grid_head_tbl">


	<tr>
	  <td height="40">E.P.F.</td>
	  <td><label for="epf"></label>
	    <input type="text" name="epf" id="epf" /></td>
	  <td colspan="2">Comma Separated. Eg: xxxxa,xxxxb,xxxxc</td>
	  <td width="13%" style="padding-right:5px;">&nbsp;</td>
	  <td width="25%" >&nbsp;</td>
	  </tr>
	<tr>
	  <td height="43" style="padding-right:5px;">&nbsp;</td>
	  <td >&nbsp;</td>
	  <td style="padding-left:5px;">&nbsp;</td>
	  <td>&nbsp;</td>
	  </tr>
</table>
</div>

<table class="grid_head_tbl">

	<tr align="right">	
		<td colspan="3" style="align:right;padding-left:880px;">
		<input type="button" value="Search" onclick="javascript:load_stock_paper()" />
		</td>
	</tr>

</table>

<br />
<br />
<br />
</div>
</form>
<div id="waitingDiv" style="display: none;">
<img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/>
</div>
<div id="div_content"></div>
</div>

