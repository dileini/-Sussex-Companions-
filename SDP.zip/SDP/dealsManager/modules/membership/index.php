<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/account/combo.js"> </script>
<script type="text/javascript" src="js/account/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">
    var formcheck;
    window.addEvent('domready', function() {
		formcheck = new FormCheck('grid_form',{
												display : {
													showErrors:1,	
													closeTipsButton : 0,
													keepFocusOnError : 1,
													flashTips : 1
												},
												alerts : {
													required : 'This feield is required..!'
												}
											   });
		new Picker.Date($('pdate'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2021-02-01',
         	maxDate: '2022-10-01'
	    });
		

		load_clients();
    });
// save button function
    function confirmPayment(){

		if (formcheck.checkValidation()) {

			if(document.getElementById('client').value == "0")
			{
				alert("Please select a Client");
				document.getElementById('client').focus();
			}
			else if(document.getElementById('pdate').value == "")
			{
				alert("Please select an yeat");
				document.getElementById('pdate').focus();
			}
			else
			{
				//document.querySelector('input[name="gender"]:checked').value
				var query = "client="+document.getElementById('client').value
							+"&pdate="+document.getElementById('pdate').value;
				var url = 'ajax/confirmPayment.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						//alert(result);
						
						if(result.trim() == '01')
						{
							alert('Membership payment conformed');
							window.location.reload();
						}
						else
						{
							alert('Error Occored, Pl. try again..');
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

			}
		}
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Assign Membership Payment to Clients</p>
<form id="grid_form">
<table width="400px" border="0" class="grid_head_tbl">
  <tr>
    <td>Select Client :</td>
    <td><select name="client" id="client"  style="width:180px;">
      <option></option>
    </select></td>
  </tr>
  
  <tr>
    <td>Payment Year :</td>
    <td><label for="pdate"></label>
      <input type="text" name="pdate" id="pdate" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td colspan="3" align="left" style="align:right;padding-left:200px;"><input type="button" value="Confirm Membership Payment" onclick="confirmPayment()" /></td>
	</tr>

</table>
</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>