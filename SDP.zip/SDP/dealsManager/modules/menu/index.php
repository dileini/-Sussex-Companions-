<style type="text/css">

.sidebarmenu ul{
margin: 0;
padding: 0;
list-style-type: none;
font: bold 13px Verdana;
width: 200px; /* Main Menu Item widths */
border-bottom: 1px solid #ccc;

}

.sidebarmenu ul li{
position: relative;
z-index: 1000;
padding-top:2px;

}

/* Top level menu links style */
.sidebarmenu ul li a{
display: block;
overflow: auto; /*force hasLayout in IE7 */
color: white;
text-decoration: none;
padding: 6px;

background-color: #333333;
border-radius: 8px 0px 8px 0px;
-moz-border-radius: 8px 0px 8px 0px;
-webkit-border-radius: 8px 0px 8px 0px
}

.sidebarmenu ul li a:link, .sidebarmenu ul li a:visited, .sidebarmenu ul li a:active{
background-color: #333333; /*background of tabs (default state)*/
}

.sidebarmenu ul li a:visited{
color: white;
}

.sidebarmenu ul li a:hover{
background-color: #191919;
}

/*Sub level menu items */
.sidebarmenu ul li ul{
position: absolute;
width: 190px; /*Sub Menu Items width */
top: 0;
visibility: hidden;
}

.sidebarmenu a.subfolderstyle{
background: url(images/right.gif) no-repeat 97% 50%;
}


/* Holly Hack for IE \*/
* html .sidebarmenu ul li { float: left; height: 1%; }
* html .sidebarmenu ul li a { height: 1%; }
/* End */

</style>

<script type="text/javascript">

//Nested Side Bar Menu (Mar 20th, 09)
//By Dynamic Drive: http://www.dynamicdrive.com/style/

var menuids=["sidebarmenu1"]; //Enter id(s) of each Side Bar Menu's main UL, separated by commas

function initsidebarmenu(){
for (var i=0; i<menuids.length; i++){
  var ultags=document.getElementById(menuids[i]).getElementsByTagName("ul");
    for (var t=0; t<ultags.length; t++){
    ultags[t].parentNode.getElementsByTagName("a")[0].className+=" subfolderstyle";
  if (ultags[t].parentNode.parentNode.id==menuids[i]) //if this is a first level submenu
   ultags[t].style.left=ultags[t].parentNode.offsetWidth+"px"; //dynamically position first level submenus to be width of main menu item
  else //else if this is a sub level submenu (ul)
    ultags[t].style.left=ultags[t-1].getElementsByTagName("a")[0].offsetWidth+"px"; //position menu to the right of menu item that activated it
    ultags[t].parentNode.onmouseover=function(){
    this.getElementsByTagName("ul")[0].style.display="block";
    }
    ultags[t].parentNode.onmouseout=function(){
    this.getElementsByTagName("ul")[0].style.display="none";
    }
    }
  for (var t=ultags.length-1; t>-1; t--){ //loop through all sub menus again, and use "display:none" to hide menus (to prevent possible page scrollbars
  ultags[t].style.visibility="visible";
  ultags[t].style.display="none";
  }
  }
}

if (window.addEventListener)
window.addEventListener("load", initsidebarmenu, false);
else if (window.attachEvent)
window.attachEvent("onload", initsidebarmenu);

</script>
<div class="sidebarmenu">
<ul id="sidebarmenu1" >

	<li ><a href="#">Main</a>
	<ul >
		<li><a href="dashboard.php"> DashBoard </a></li>
		<li><a href="logout.php"> Log out</a></li>
	</ul>
	</li>
    
    
	<?php

	if ($_SESSION ['user_level'] == 1)
	{
	?>
	<li><a href="#">User Management</a>
	<ul>
		<li><a href="account.php"> Admin Account Creation </a></li>
		<li><a href="updateUsers.php"> Update Admins </a></li>
	</ul>
	</li> 
	<li><a href="#">Add Client </a>
		<ul>
			<li><a href="addClient.php">Add Client</a></li>
			<li><a href="editClient.php">Edit Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Assign Events </a>
		<ul>
			<li><a href="assignEvents.php">Assign Event to Member</a></li>
			<li><a href="assignEventRep.php">Assign Event Report</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Images</a>
		<ul>
			<li><a href="addImage.php">Add Client Image</a></li>
		</ul>    
	</li> 
	<li><a href="#">Match Clients </a>
		<ul>
			<li><a href="searchClient.php">Search Client</a></li>
		</ul>    
	</li>
	<?php
	}
	else if ($_SESSION ['user_level'] == 2)
	{
	?>
	<li><a href="#">User Management</a>
	<ul>
		<li><a href="account.php"> Admin Account Creation </a></li>
		<li><a href="updateUsers.php"> Update Admins </a></li>
	</ul>
	</li> 
	<li><a href="#">Add Client </a>
		<ul>
			<li><a href="addClient.php">Add Client</a></li>
			<li><a href="editClient.php">Edit Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Assign Events </a>
		<ul>
			<li><a href="assignEventRep.php">Assign Event Report</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Images</a>
		<ul>
			<li><a href="addImage.php">Add Client Image</a></li>
			<li><a href="addImageEvent.php">Add Event Image</a></li>
		</ul>    
	</li> 
	<li><a href="#">Search Clients </a>
		<ul>
			<li><a href="searchClient.php">Search Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Hobbies </a>
		<ul>
			<li><a href="addHobbie.php">Add Hobbie</a></li>
            <li><a href="editHobbie.php">Edit Hobbie</a></li>
		</ul>    
	</li>
	<?php	
	}
	else if ($_SESSION ['user_level'] == 3)
	{
	?>
	<li><a href="#">User Management</a>
	<ul>
		<li><a href="account.php"> Admin Account Creation </a></li>
		<li><a href="updateUsers.php"> Update Admins </a></li>
	</ul>
	</li> 
	<li><a href="#">Add Client </a>
		<ul>
			<li><a href="addClient.php">Add Client</a></li>
			<li><a href="editClient.php">Edit Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Assign Events </a>
		<ul>
			<li><a href="assignEventRep.php">Assign Event Report</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Images</a>
		<ul>
			<li><a href="addImage.php">Add Client Image</a></li>
			<li><a href="addImageEvent.php">Add Event Image</a></li>
		</ul>    
	</li> 
	<li><a href="#">Search Clients </a>
		<ul>
			<li><a href="searchClient.php">Search Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Hobbies </a>
		<ul>
			<li><a href="addHobbie.php">Add Hobbie</a></li>
            <li><a href="editHobbie.php">Edit Hobbie</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Event </a>
		<ul>
			<li><a href="addEvent.php">Add Event</a></li>
            <li><a href="editEvent.php">Edit Event</a></li>
		</ul>    
		</li>
	<?php	
	}
	else if ($_SESSION ['user_level'] == 4)
	{
	?>
	<li><a href="#">User Management</a>
	<ul>
		<li><a href="account.php"> Admin Account Creation </a></li>
		<li><a href="updateUsers.php"> Update Admins </a></li>
	</ul>
	</li> 
	<li><a href="#">Add Client </a>
		<ul>
			<li><a href="addClient.php">Add Client</a></li>
			<li><a href="editClient.php">Edit Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Assign Events </a>
		<ul>
			<li><a href="assignEventRep.php">Assign Event Report</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Images</a>
		<ul>
			<li><a href="addImage.php">Add Client Image</a></li>
			<li><a href="addImageEvent.php">Add Event Image</a></li>
		</ul>    
	</li> 
	<li><a href="#">Search Clients </a>
		<ul>
			<li><a href="searchClient.php">Search Client</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Hobbies </a>
		<ul>
			<li><a href="addHobbie.php">Add Hobbie</a></li>
            <li><a href="editHobbie.php">Edit Hobbie</a></li>
		</ul>    
	</li>
	<li><a href="#">Add Event </a>
		<ul>
			<li><a href="addEvent.php">Add Event</a></li>
            <li><a href="editEvent.php">Edit Event</a></li>
		</ul>    
	</li>
	<li><a href="#">Finance </a>
		<ul>
			<li><a href="membershipFee.php">Membership Fee Report</a></li>
			<li><a href="eventFeesReport.php">Event Fees Report</a></li>
			<li><a href="incomeOfEvents.php">Income of Events</a></li>
			<li><a href="overDueLetter.php">Over Due Letter</a></li>
		</ul>    
	</li>
	<?php	
	}
	else if ($_SESSION ['user_level'] == 5)
	{
	?>
			<li><a href="#">User Management</a>
		<ul>
			<li><a href="account.php"> Admin Account Creation </a></li>
			<li><a href="updateUsers.php"> Update Admins </a></li>
		</ul>
		</li> 
        
        <li><a href="#">Add Hobbies </a>
		<ul>
			<li><a href="addHobbie.php">Add Hobbie</a></li>
            <li><a href="editHobbie.php">Edit Hobbie</a></li>
		</ul>    
		</li>
		
		<li><a href="#">Add Client </a>
		<ul>
			<li><a href="addClient.php">Add Client</a></li>
            <li><a href="editClient.php">Edit Client</a></li>
		</ul>    
		</li>
		
		<li><a href="#">Add Event </a>
		<ul>
			<li><a href="addEvent.php">Add Event</a></li>
            <li><a href="editEvent.php">Edit Event</a></li>
		</ul>    
		</li>
		
		<li><a href="#">Assign Events </a>
		<ul>
			<li><a href="assignEvents.php">Assign Event to Member</a></li>
			<li><a href="assignEventRep.php">Assign Event Report</a></li>
		</ul>    
		</li>
		
		<li><a href="#">Add Images</a>
		<ul>
			<li><a href="addImage.php">Add Client Image</a></li>
			<li><a href="addImageEvent.php">Add Event Image</a></li>
		</ul>    
		</li> 
		
		<li><a href="#">Match Clients </a>
		<ul>
			<li><a href="searchClient.php">Search Client</a></li>
		</ul>    
		</li>
		
		<li><a href="#">Membership Payment </a>
		<ul>
			<li><a href="membership.php">Add Payment</a></li>
		</ul>    
		</li>
		
		<li><a href="#">Finance </a>
		<ul>
			<li><a href="membershipFee.php">Membership Fee Report</a></li>
			<li><a href="eventFeesReport.php">Event Fees Report</a></li>
			<li><a href="incomeOfEvents.php">Income of Events</a></li>
			<li><a href="overDueLetter.php">Over Due Letter</a></li>
		</ul>    
		</li>
	<?php	
	}
	?>
	</ul>
</div>


