<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/addCategory/combo.js"> </script>
<script type="text/javascript" src="js/addCategory/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<script type="text/javascript">
    var formcheck;

    window.addEvent('domready', function() {

		formcheck = new FormCheck('grid_form',{showErrors:1});
		
		LoadAllCatos();
		$('cmd').addEvent('click', getPdf);
		
    });

function addWaterMark(doc) {
  var totalPages = doc.internal.getNumberOfPages();

  for (i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    //doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
    doc.setTextColor(150);
    doc.text(50, doc.internal.pageSize.height - 30, 'Lanka Auto Motive Spare Parts Store');
  }

  return doc;
}

function getPdf() {
  var pdf = new jsPDF("p", "pt", "a4");
  pdf.addHTML($('print_div'), 10, 10, function() {
	  pdf.setFontSize(3);
	  pdf.setTextColor(150);
	  pdf.save('div.pdf');
	});
}


function loadPage(pageName,id)
{
	var query = '?id='+id;
	window.open('ajax/'+pageName+query,'Print','left=20,top=20,width=720,height=500,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	
}


function saveCatos()
{
	if (formcheck.checkValidation()) 
	{

				var query = "catoText="+$('catText').value
				           +"&catoCode="+ $('catCode').value;
				var url = 'ajax/saveCato.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						//alert(result);
						
						if(result =='1')
						{
							alert('Category name or Text allready posted.')
							//window.location.reload();
						}
						if(result =='2')
						{
							alert('Inserting problem occor.')
							//window.location.reload();
						}
						if(result =='3')
						{
							alert('Category sucess fully added..')
							window.location.reload();
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

	}
 }
 
 function LoadAllCatos()
 {
 	var query = "catoText="+'x';
	var url = 'ajax/reorder.php';

	var req = new Request({method: 'POST',
		data:query,
		url: url,
		onSuccess: function(result){
			hideImgContent('waitingDiv');
			//alert(result);
			
			if(result =='1')
			{
				alert('No recores found')
				//window.location.reload();
			}
			else
			{
				//alert('Category sucess fully added..')
				//window.location.reload();
				$('results').innerHTML = result;
			}
			
		}});
	showImgContent('waitingDiv');
	req.send();
 }

function modifyCato(id,tpe,ed)
{
	//Id = ID of rcord
	//tye = edit or desable
	//ed = elable or desable
	var recordId = id;
	var modifyTupe = tpe;
	var enableOrDesable = ed;
	
	var catoCode     = 'catoCode'+recordId;
	var catoText     = 'catoText'+recordId;
	var jobTitle     = 'jobTitle'+recordId;
	var JobDesc      = 'JobDesc'+recordId;
	var jobOpenDate  = 'jobOpenDate'+recordId;
	var jobCloseDate = 'jobCloseDate'+recordId;
	var companyName  = 'companyName'+recordId;
	var jobCatID     = 'jobCatID'+recordId;
	var noPoss       = 'noPoss'+recordId;
	
	
	//alert(catoText);
	if(modifyTupe == 'm')
	{
		var query = "catoText="+$(catoText).value
				  +"&catoCode="+$(catoCode).value
				  +"&jobTitle="+$(jobTitle).value
				  +"&JobDesc="+$(JobDesc).value
				  +"&jobOpenDate="+$(jobOpenDate).value
				  +"&jobCloseDate="+$(jobCloseDate).value
				  +"&companyName="+$(companyName).value
				  +"&noPoss="+$(noPoss).value
				  +"&jobCatID="+$(jobCatID).value
				  +"&id="+id;
			//alert(query);	  
		var url = 'ajax/modifyJobs.php';

		var req = new Request({method: 'POST',
			data:query,
			url: url,
			onSuccess: function(result){
				hideImgContent('waitingDiv');
				//alert(result);
				
				if(result =='1')
				{
					alert('Update Successfull..!')
					window.location.reload();
				}
					else if(result =='2')
					{
						alert('Update problem occer..')
						window.location.reload();
						//$('results').innerHTML = result;
					}
						else if(result =='3')
						{
							alert('Invalid record ID..');
							//window.location.reload();
							//$('results').innerHTML = result;
						}
					
			}});
		showImgContent('waitingDiv');
		req.send();
		
	}
/*	
	else (modifyTupe == 'd')
	{
		
		var query = "enableOrDesable="+enableOrDesable
				  +"&id="+recordId;
				  
		var url = 'ajax/modifyCatoStatus.php';

		var req = new Request({method: 'POST',
			data:query,
			url: url,
			onSuccess: function(result){
				hideImgContent('waitingDiv');
				//alert(result);
				
				if(result =='1')
				{
					alert('Update Successfull..!')
					window.location.reload();
				}
				else if(result =='2')
				{
					alert('Update problem occer..')
					//window.location.reload();
					//$('results').innerHTML = result;
				}
				else if(result =='3')
				{
					alert('Invalid record ID..');
					//window.location.reload();
					//$('results').innerHTML = result;
				}
				
			}});
		showImgContent('waitingDiv');
		req.send();
		
	}
*/	
	
}



function enableDesableJobs(id,tpe,ed)
{
	//Id = ID of rcord
	//tye = edit or desable
	//ed = elable or desable
	var recordId = id;
	var modifyTupe = tpe;
	var enableOrDesable = ed;
	
	
	var query = "enableOrDesable="+enableOrDesable
				  +"&id="+recordId;
			//alert(query);	  
	var url = 'ajax/modifyJobStatus.php';

		var req = new Request({method: 'POST',
			data:query,
			url: url,
			onSuccess: function(result){
				hideImgContent('waitingDiv');
				//alert(result);
				
				if(result =='1')
				{
					alert('Update Successfull..!')
					window.location.reload();
				}
					else if(result =='2')
					{
						alert('Update problem occer..')
						window.location.reload();
						//$('results').innerHTML = result;
					}
						else if(result =='3')
						{
							alert('Invalid record ID..');
							//window.location.reload();
							//$('results').innerHTML = result;
						}
					
			}});
		showImgContent('waitingDiv');
		req.send();
		
}






</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
tr.border_bottom td {
  border-bottom:1pt solid black;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Reorder Level of Stock Report</p>
<input type="button" id="cmd" value="Download PDF" 
 style="width:160px; height:25px; margin:0px; background-color:#6BAAF8; border-radius: 3px; border: 2px solid gray;">

<form id="grid_form">
  <table class="grid_head_tbl">
    
    <tr align="right">
		<td colspan="3" style="align:right;padding-left:200px;">&nbsp;</td>
	</tr>

</table>
<div id="results">
</div>


</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>