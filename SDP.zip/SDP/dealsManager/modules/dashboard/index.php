<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<style>
.comboBox {
	width: 200px;
}

.advcomboBox {
	width: 150px;
}

.td_class {
	width: 125px;
	padding: 10px;
	font-family: Arial 14px;
	font-size: 12px;
	font-weight: bold;
}

.img_class {
	width: 350px;
	height: 250px;
	padding: 5px;
	border: solid 5px #000000;
	float: left;
}
.img_class1 {
	width: 150px;
	height: 150px;
	padding: 5px;
	border: solid 1px #000000;
	float: left;
}
</style>
<script type="text/javascript">
	
    window.addEvent('domready', function() {
    <?php
				if ($_SESSION ['user_level'] == 4 || $_SESSION ['user_level'] == 5)
				{
	?>
    				load_account();
					
    <?php
				}				
				else if($_SESSION ['user_level'] == 3)
				{
	?>								
					load_RMaccount();	
	<?php 
				}				
				else if($_SESSION ['user_level'] == 1)
				{
	?>
					loadAdminPanel();
    <?php
				}
				else if($_SESSION ['user_level'] == 6)
				{?>
			
					loadAdminPanel();
					<?php
				}
	?>    
   
        
    });
	
    function load_account()
    {        
        var url = '../../ajax/loadUser.php';
		
        var req = new Request({method: 'GET',
            data:'',
            url: url,
            onSuccess: function(result){
                document.getElementById('div_content').innerHTML = result;
            }});
        req.send();
    	
    }
/*
    function load_RMaccount()
    {        
        var url = '../../ajax/loadRMUser.php';		
        var req = new Request({method: 'GET',
            data:'region=<?php echo $_SESSION['user_region'];?>',            
            url: url,
            onSuccess: function(result){
                document.getElementById('div_content').innerHTML = result;
            }});
        req.send();
    	
    }*/

    function loadAdminPanel()
    {
		var url = 'ajax/loadAdminPanle.php';		
        var req = new Request({method: 'GET',
            data:'',
            url: url,
            onSuccess: function(result){
                document.getElementById('div_content').innerHTML = result;
            }});
        req.send();
        
    }
    function viewDeports(index,region_txt)
    {
		var url = '../../ajax/loadDeportPanel.php';
		var query = 'regionId=' + index + '&regiontxt=' + region_txt ;		
        var req = new Request({method: 'GET',
            data:query,
            url: url,
            onSuccess: function(result){
                document.getElementById('div_content').innerHTML = result;
            }});
        
        req.send();
        
    }		

    function viewDeportInfo(index,deport_txt,regionid,region_txt)
    {
    	var url = '../../ajax/loadDeportInfo.php';
		var query = 'deportId=' + index + '&deporttxt=' + deport_txt + '&regionId=' + regionid + '&region_txt=' + region_txt;		
        var req = new Request({method: 'GET',
            data:query,
            url: url,
            onSuccess: function(result){
                document.getElementById('div_content').innerHTML = result;
            }});
        
        req.send();
    }
</script>

<div class="box_header">
<div id="div_content"></div>
</div>

