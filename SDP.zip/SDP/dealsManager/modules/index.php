<style>

.box_header
{
	width:800;
}
.paginate {
font-family:Arial, Helvetica, sans-serif;
	padding: 3px;
	margin: 3px;
}

.paginate a {
	padding:2px 5px 2px 5px;
	margin:2px;
	border:1px solid #999;
	text-decoration:none;
	color: #666;
}
.paginate a:hover, .paginate a:active {
	border: 1px solid #999;
	color: #000;
}
.paginate span.current {
    margin: 2px;
	padding: 2px 5px 2px 5px;
		border: 1px solid #999;
		
		font-weight: bold;
		background-color: #999;
		color: #FFF;
	}
	.paginate span.disabled {
		padding:2px 5px 2px 5px;
		margin:2px;
		border:1px solid #eee;
		color:#DDD;
	}
	
.comboBox {
	width: 200px;
}
.advcomboBox {
	width: 150px;
}
</style>

<script type="text/javascript">
    var depot_text ='<?php echo $_SESSION ['user_deport'];?>';
</script>
<script type="text/javascript" src="js/commonFunctions.js"> </script>
<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/log_SaleReport/combo.js"> </script>
<script type="text/javascript" src="js/log_SaleReport/core_functions.js"> </script>

<link rel="stylesheet" href="css/style_OtherSale.css" type="text/css" media="screen" />
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">

<script type="text/javascript">
    var formcheck;

	window.addEvent('domready', function() {
        formcheck = new FormCheck('grid_form',{showErrors:1});

		new Picker.Date($('fromDate'), {
        positionOffset: {x: 5, y: 0},
        format : '%d/%m/%Y',
        pickerClass: 'datepicker_dashboard',
        useFadeInOut: !Browser.ie
   		});

	    new Picker.Date($('toDate'), {
	        positionOffset: {x: 5, y: 0},
	        format : '%d/%m/%Y',
	        pickerClass: 'datepicker_dashboard',
	        useFadeInOut: !Browser.ie
	    });


		//load_combo_data('/wayside/ajax/regions.php','reigon','region_text','region_id','');
		load_combo_data('/wayside/ajax/regions.php','inreigon','region_text','region_id','');
		
		//load Sub region
		load_combo_data('/wayside/ajax/subregion.php', 'subregion', 'subregiontext', 'subcord','');
		
		//load Coupe onload
		load_combo_data('/wayside/ajax/coupes.php', 'coupe', 'coupe_txt', 'coupe_id','');
		
		//load_species();
		//load_region();
		
	});

	function checkHammer()
	{
		var elementHammer = document.getElementById('hammer');
		var eleValue = elementHammer.value;
		if(eleValue.indexOf("STC") != 0)
		{
			alert("Hammer Mark Should start with 'STC' .");
			elementHammer.value = "STC";
			elementHammer.focus();
		}
	}
	
	function doc_print(query)
	{	
		window.open('/wayside/ajax/printPreSaleInvoice.php?' +query,'Print','left=20,top=20,width=1050,height=500,toolbar=0,resizable=0,menubar=1,location=0,status=0,scrollbars=1');	
	}
	
	
	function printNotes(saleNo)
	{	
    	var query = "id="+saleNo;
		doc_print(query);
    }
	
	function clearField(ele)
	{
		ele.value = "";
	}
	
	function sendGetReport()
	{
		
		var query ="regeion="+$('regid').value
	  	  			+ "&subregion="+$('subregion').value
					+ "&coupe="+$('coupe').value 
					+ "&fromDate="+$('fromDate').value
					+ "&toDate="+$('toDate').value;
					
	
			//+"&sellDate="+document.getElementById('document_date').value; 
			var url = '/wayside/ajax/log_sales_summary.php';
					
	        var req = new Request({method: 'GET',
	            data:query,
	            url: url,
	            onSuccess: function(result){
	            	hideImgContent('waitingDiv');
	                document.getElementById('saleReport').innerHTML = result;
	            }});
	        showImgContent('waitingDiv');
	        req.send();
	}
function printDiv(divName) 
	{
	     var printContents = $(divName).innerHTML;
	     var originalContents = document.body.innerHTML;
	
	     document.body.innerHTML = printContents;
	
	     window.print();
	
	     document.body.innerHTML = originalContents;
	}
	
	function PrintElem(elem)
    {
        Popup($(elem).innerHTML);
    }

    function Popup(data) 
    {
        var mywindow = window.open('', 'saleReport');
        mywindow.document.write('<html><head><title>Way Side Log Sale Report</title>');
        
        mywindow.document.write('</head><body >');
        mywindow.document.write(data);
        mywindow.document.write('</body></html>');

        return true;
    }





</script>


<div class="box_header">
<form id="grid_form">
<input type="hidden" name="advSch" id="advSch" value="0" /> 
<input type="hidden" name="regid" id="regid" value="<?php echo $_SESSION ['user_region'];?>" />
<h1>Wayside Log Sale Summary</h1>
<table width="90%" border="0">
  <tr>
    <td colspan="5"><table width="100%" border="0">
      <tr>
        <td>Region</td>
        <td>Sub Eegion</td>
        <td>Coupe</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><select name="inregion" id="inreigon" onChange="loadSubRegion();" style="width:180px;">
        	<option></option>
        	</select></td>
        <td><select name="subregion" id="subregion" style="width:180px;"  onChange="loadCoupe();">
          <option value="Any">Any</option>
        </select></td>
        <td><select  name="coupe" id="coupe" style="width:180px;"  >
          <option value="Any">Any</option>
        </select></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td colspan="5">Please select date range.</td>
    </tr>
  <tr>
    <td>Start Data:</td>
    <td><input type="text" name="fromDate" id="fromDate" style="width:175px;" onclick="clearField(this)"/></td>
    <td>End Date</td>
    <td><input type="text" name="toDate" id="toDate" style="width:175px;" onclick="clearField(this)"/></td>
    <td><a href="#" onclick="sendGetReport();">Search</a></td>
  </tr>
</table>
<br />
<br />
<div id="waitingDiv" style="display: none;">
<img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/>
</div>
<div id="saleReport">Content for  id "saleReport" Goes Here</div>
<p><br />
  <br />
</p>
</form>

<div id="div_content"></div>
</div>


