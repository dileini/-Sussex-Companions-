<script type="text/javascript" src="js/lang/en.js"> </script>
<script type="text/javascript" src="js/empty.js"> </script>
<script type="text/javascript" src="js/formcheck.js"> </script>
<script type="text/javascript" src="js/autocomplete.js"> </script>
<script type="text/javascript" src="js/account/combo.js"> </script>
<script type="text/javascript" src="js/account/core_functions.js"> </script>
<link rel="stylesheet" href="js/theme/classic/formcheck.css" type="text/css" media="screen" />


<script src="js/Source/Locale.en-US.DatePicker.js" type="text/javascript"></script>
<script src="js/Source/Picker.js" type="text/javascript"></script>
<script src="js/Source/Picker.Attach.js" type="text/javascript"></script>
<script src="js/Source/Picker.Date.js" type="text/javascript"></script>
<link href="js/Source/datepicker.css" rel="stylesheet">
<link href="js/Source/datepicker_dashboard/datepicker_dashboard.css" rel="stylesheet">
<script type="text/javascript">
    var formcheck;
    window.addEvent('domready', function() {
		formcheck = new FormCheck('grid_form',{
												display : {
													showErrors:1,	
													closeTipsButton : 0,
													keepFocusOnError : 1,
													flashTips : 1
												},
												alerts : {
													required : 'This feield is required..!'
												}
											   });
		new Picker.Date($('event_date'), 
		{
			positionOffset: {x: 5, y: 0},
			format : '%Y-%m-%d',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2021-02-01',
         	maxDate: '2022-10-01'
	    });
		
		new Picker.Date($('event_time'), 
		{
			positionOffset: {x: 5, y: 0},
			timePicker: true,
			format : '%H:%M',
			pickerClass: 'datepicker_dashboard',
			useFadeInOut: !Browser.ie,
			minDate: '2021-02-01',
         	maxDate: '2022-10-01'
	    });
    });
// save button function
    function saveEvent(){

		if (formcheck.checkValidation()) {
				//document.querySelector('input[name="gender"]:checked').value
				var query = "event_name="+document.getElementById('event_name').value
				+"&event_date="+ document.getElementById('event_date').value
				+"&event_time="+document.getElementById('event_time').value
				+"&event_cost="+document.getElementById('event_cost').value
				+"&event_perhead="+document.getElementById('event_perhead').value;
				var url = 'ajax/saveEvent.php';

				var req = new Request({method: 'POST',
					data:query,
					url: url,
					onSuccess: function(result){
						hideImgContent('waitingDiv');
						//alert(result);
						
						if(result.trim() == '01')
						{
							alert('New Event added sucessfully')
							window.location.reload();
						}
						else
						{
							alert('Error Occored, Pl. try again..');
						}
						
					}});
				showImgContent('waitingDiv');
				req.send();

			
		}
    }

</script>
<style>
.transDiv {
	background-color:#f0f0f0;
	opacity:.6;
	filter:alpha(opacity=50);
	position:fixed;
	left:0;
	top:0;
	z-index: 999;
	width:100%;
	height:100%;
}
</style>
<div class="box_header">
<p style="font-weight:bold;font-size:14px;">Register New Event</p>
<form id="grid_form">
<table width="400px" border="0" class="grid_head_tbl">
  <tr>
    <td>Event Name : </td>
    <td><input type="text" value=""  name="event_name" id="event_name" style="width:180px;" class="validate['required','nodigit']"/></td>
  </tr>
  <tr>
    <td>Event Date : </td>
    <td><input type="text" value=""  name="event_date" id="event_date" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
    <td>Event Time</td>
    <td><input type="text" value=""  name="event_time" id="event_time" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
    <td>Event Cost</td>
      <td><input type="text" value=""  name="event_cost" id="event_cost" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
    <td>Cost per Person</td>
    <td><input type="text" value=""  name="event_perhead" id="event_perhead" style="width:180px;" class="validate['required']"/></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table class="grid_head_tbl">

	<tr align="right">
		<td colspan="3" style="align:right;padding-left:200px;">
		<input type="button" value="Ad New Event" onclick="saveEvent()" />
		</td>
	</tr>

</table>
</form></div>
<div id="waitingDiv" style="display:none" class="transDiv" ><center><div style="text-align: center;padding-top:250px;"><img name="waitingGif" id="waitingGif" src="images/wait.gif" style="width:150px;height:40px;"/></div></center></div>