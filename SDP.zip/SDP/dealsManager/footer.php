<style type="text/css">
#footer {
	float: left;
	width: 100%;
	height: 100px;
	/*background-color: #ffffff;*/
	padding-top: 0px;
}
#footer-area {
	float: left;
	width: 100%;
	height: 100px;
	/*background-image: url(image/footer.gif);
	background-repeat: repeat-x;*/
}
#footer-right {
	float: left;
	width: 25%;
	height: 100px;
	/*
	background-image: url(image/fotterlog.png);
	*/
	background-repeat: no-repeat;
	background-position: right;
	
}
#footer-left {
	float: left;
	width: 70%;
	height: 100px;
	color: #FFFFFF;
	padding-left: 50px;
}

</style>
<div id="footer">
    <div id="footer-area">
		
		<div id="footer-left">
		 <br />
		  <br />
		<font style="font-size:15px"> All Rights Reserved.</font> <br />

<font style="font-size:13px">xxx</font>
		</div>
		<div id="footer-right">
		
		</div>

    </div>
</div>