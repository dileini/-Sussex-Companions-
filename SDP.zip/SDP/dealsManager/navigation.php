<style type="text/css">
#menu {
	float: left;
	width: 210px;
	height: auto;
	background-color: #ECEAEE;
	border-radius: 5px 5px 5px 5px;
	-moz-border-radius: 5px 5px 5px 5px;
	-webkit-border-radius: 5px 5px 5px 5px;
	/*background-image: url(image/navigation.gif);
	background-repeat: repeat-x;*/
}
#menu-in {
	float: left;
	width: 200px;
	height: auto;
	padding: 5px;
}
#menu-in-area {
	float: left;
	width:  200px;
	height: auto;
	background-color: #ffffff;
	border-radius: 8px 0px 8px 0px;
	-moz-border-radius: 8px 0px 8px 0px;
	-webkit-border-radius: 8px 0px 8px 0px;
}

</style>
<div id="menu">
    	<div id="menu-in">
        <div id="menu-in-area">
    	 <?php require_once('modules/menu/index.php'); ?>
		 </div>
    </div>
</div