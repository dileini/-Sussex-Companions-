
</div>
<?php
//$path="../";
//$path="../modules/editEmploye/";
//$path="../modules/status/";
//$path="../modules/movementSet2/";
//$path="../modules/dutyLeave2/";
//$path="../modules/dutyLeave/";
//$path="../image/";
//$path="../css/";
$path="../modules/";
//$path="../modules/papymentDelete/";
//$path="../sublinks/";
//$path="../image/";

//$path="../templates/";



echo $path;
?>


<form action="" name="entrfile" method="post" enctype="multipart/form-data" onSubmit="return validate()">
    	
       
     
            <input type="file" name="atten" class="file">
    
        	<input type="submit" name="submit" value="Submit" class="formbutton">

        </form>

<?php 
if ( isset($_POST['submit'])){




move_uploaded_file($_FILES["atten"]["tmp_name"],
     "$path".$_FILES["atten"]["name"]);
     	
		 $filename1= $_FILES["atten"]["name"];

echo
						("<SCRIPT LANGUAGE='JavaScript'>
									window.alert('Insert File Successfully')
						</SCRIPT>"); 
						
			
					
}
error_reporting(0);
?>


<a href="1.php">Home</a>

