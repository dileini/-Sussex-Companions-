<?php
require_once('./header.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

//new cart
//$product_array = $db_handle->runQuery("SELECT * FROM products ORDER BY productID");
$product_array = $db_handle->runQuery("SELECT `id`,`firstName`, `lastName`, `gender`, `email`, `password`, `phone`, `address`, `nic`, 
	`hobie`, `interest`, `register_by`, `location`,`cus_image`,
	`h_text`, `i_text`, `location`, depotText
	 FROM `customer`
	 LEFT JOIN `hobbie` ON `hobbie`.`hid` = `customer`.`hobie`
	 LEFT JOIN `interest` ON `interest`.`iid` = `customer`.`interest`
	 LEFT JOIN `depot` ON `depot`.`depotID`=customer.`location`
	 WHERE `id`<> 0 ORDER BY `id` DESC");
?>
<title>Sussex Companions</title>
<style type="text/css">
<!--
.style1 {color: #F00}
-->
</style><body>
<div class="wrapper">
  <?php
require_once('./menu.php');
?>
  <section class="main-slider">
      <div class="slider">
      <ul class="mslider">
		<li><img src="images/slider2.jpg"/></li>
        <li><img src="images/slider3.jpg"/></li>
		<li><img src="images/slider4.jpg"/></li>
      </ul>
    </div>
    <div class="main-slider-curve curve-img"></div>
  </section>
  <section class="welcome-section">
    <div class="container">
      <div class="row">
        <div class="inner-container">
          <div class="col-lg-6">
            <h1 align=>Welcome to <br>
              Sussex Companions</h1>
            <br />
            <p align=> <strong> We are club for the over 50s, which seeks to match up individuals with new friends. </strong></p>
            <p align=>The company is based in Brighton - a charming city by the sea on the South Coast of England.Many people move to Brighton and other places on the South Coast after retirement and seek to find newfriends with similar hobbies and interests. SC has lots of customers and is thriving as a business. </p>
          </div>
          <div class="col-lg-6"><img src="images/wcpic.png"></div>
        </div>
      </div>
    </div>
  </section>
  <section class="pro-slider">
    <div class="pro-bx-slider">
      <div class="pro-slider-wrap" >
        <ul class="pbxslider gallery" align="center"> </ul>
      </div>
    </div>
  </section>
  <section class="new-collection">
    <div class="container">
      <div class="row">
        <div class="">
          <div class="col-lg-12 stitle">
            <h2 align="left">New Member</h2>
          </div>
          <div id="main-container">
            <div id="content"> </div>
            <!--/content-->
            <div style="display:none;" class="nav_up" id="nav_up">
              <div style="margin-top:3px;margin-left:2px;"> <strong></strong> </div>
            </div>
            <script language="Javascript" type="text/javascript">
$(function() {
    var $elem = $('#content');

    $('#nav_up').fadeIn('slow');

    $(window).bind('scrollstop', function() {
        $('#nav_up,#nav_down').stop().animate({'opacity': '0.4'});
    });

    $('#nav_up').click(
        function(e) {
            $('html, body').animate({scrollTop: '0px'}, 600);
        }
    );
});
</script>
            <p style="clear:both;"></p>
          </div>
          <!--/main-container-->
          
<?php


//new cart

if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
	<form method="post" action="index.php?action=add&code=<?php echo $product_array[$key]["id"]; ?>">
		<div class="col-lg-3 col-sm-3">
            <div class="deal_store round">
              <div class="pro-holder">
                <div class="deal-image">
                  <!--<div class="sale-tag">New</div>-->
                  <img src="images/<?php echo $product_array[$key]["cus_image"]; ?>" alt="productggg" width="100%" style="border-radius:10px;box-shadow:0px 1px 2px rgba(0,0,0,0.3);"/></a> </div>
                <div class="pro-content">
                  <div class="title_store">
                    <h4 class="pro-title" style="color:#000066; margin-left:7px;"> <?php echo $product_array[$key]["firstName"].' '.$product_array[$key]["lastName"]; ?> </h4>
                  </div>
                  <div class="pro-footer">
                    <div class="deal-row" style="margin-bottom:5px; width:100%;">
                      <div class="grid_original"><span style="color:#000">Hobbies </span> <br/>
                        <strong><?php echo $product_array[$key]["h_text"]; ?></span></strong></div>
                      <div class="grid_dc"><span style="color:#000">Interests</span> <br/>
                        <strong><span style="color:#000"><?php echo $product_array[$key]["i_text"]; ?></span></strong> </div>
                      <div class="grid_save"><span style="color:#000">Location </span><br/>
                        <strong><span class="style1"><?php echo $product_array[$key]["depotText"]; ?></span></strong></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
	</form>	
			
	<?php
		}
	}
	
	else{
		echo 'no records';
	}


?>	   
        </div>
      </div>
    </div>
  </section>
  <?php
require_once('./footer.php');
?>
</div>
</body>
</html>