<?php
include("dealsManager/db_connector.php");
 $FirstName = $_POST['Fname'];
 $LastName = $_POST['Lname'];
 $gender = $_POST['gender'];
 $email = $_POST['Email'];
 $password = md5($_POST['Password']);
 $rePassword = $_POST['Repassword'];
 $phone = $_POST['Phone'];
 $address = $_POST['Address'];
 $myNIC = $_POST['nic'];
 

$insrtQuery = "insert into `customer`(`firstName`,`lastName`,`gender`,`email`,`password`,`phone`,`address`,`nic`)
values ('$FirstName','$LastName','$gender','$email','$password','$phone','$address',$myNIC)";
$result = mysql_query($insrtQuery);
header("location: register.php?err=2");
?>