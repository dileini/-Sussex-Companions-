<section class="header">
  <div class="topbar"> 
    <!--<div class="container">
<div class="top-nav"><a href="login.html">Login</a> / <a href="register.html">Register</a> <span class="top-cart"><i class="fa fa-shopping-cart"></i> Cart (0)</span></div>
</div>--> 
  </div>
  <div class="nav-wrap">
    <div class="container">
      <div class="row">
        <div class="inner-container" style="max-width:1160px;">
          <div class="col-lg-12">
            <div class="head-nav">
              <div role="navigation" class="navbar navbar-inverse">
                <div class="navbar-header">
                  <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                  <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="Lanka Automotive Motor Spare Parts  Store"></a> </div>
                <div class="collapse navbar-collapse">
                  <nav id="nav">
                    <ul>
                      <li class="active"><a href="index.php">Home</a></li>
                      <li><a href="register.php">Register/Login</a></li>
                      <!--<li><a href="list.php">Products</a></li>
                      <li><a href="aboutus.php">About Us</a></li>-->
                      <li><a href="contactus.php">Contact Us</a></li>
                      <?php
					  //if(isset($_SESSION['login']))
					  //{
						  ////if($_SESSION['login']=='1'){
						  ?>
							  <li><a href="list.php">Event List</a></li>
							  <li><a href="myOrders.php">My Orders</a></li>
							  <li><a href="logout.php">Log out</a></li>
						  <?php
						  //}
					  //}
					  ?>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
