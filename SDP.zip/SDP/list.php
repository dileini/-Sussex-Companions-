<?php
session_start();
require_once('./header.php');
require_once("dbcontroller.php");
$db_handle    = new DBController();
$newProductID = "";
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM `event` WHERE `event_id`='" . $_GET["code"] . "'");
			$newProductID  = 'x'.$productByCode[0]["event_id"];
			$itemArray     = array($newProductID=>array('name'=>$productByCode[0]["event_title"], 
																	 'code'=>$productByCode[0]["event_id"], 
																	 'quantity'=>$_POST["quantity"], 
																	 'price'=>$productByCode[0]["event_per_head_cost"], 
																	 'image'=>'images/'.$productByCode[0]["event_pic"]));
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($newProductID,array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($newProductID == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					var_dump($v);
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]); 
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}

//new cart

if(isSet($_GET['searchme'])){
	$query   = "SELECT * FROM `event` WHERE `event_id`<>0 ";
	$catos   = "";
	$itemTex = "";

	if($_GET['searchme'] != ''){
		$query = $query . " and `event_title` LIKE '%". $_GET['searchme'] ."%' ";
	}
	//echo $query;
	$product_array = $db_handle->runQuery($query);
}
else{
	$product_array = $db_handle->runQuery("SELECT * FROM `event`");
}

//Generate category list box
$listQuery = "SELECT `id`, `catoText` FROM `jobcats`";
$listQueryR = mysql_query($listQuery);
$headofList = "";
$middleList = "<option value='0' selected>Any</option>";
$tailList = "</select>";
while($litstRow = mysql_fetch_array($listQueryR)){
	$middleList = $middleList. "<option value='".$litstRow['id']."'>".$litstRow['catoText']."</option>";
}
$headofList = "<select name='job' id='job' style='width:180px;'>";
	

?>

<title>usex</title>
<style type="text/css">
<!--
.style1 {color: #F00}
-->
</style><body>
<div class="wrapper">
<?php
require_once('./menu.php');
?>
  <section class="main-slider">
      <div class="slider">
      <ul class="mslider">
		<li><img src="images/slider2.jpg"/></li>
        <li><img src="images/slider3.jpg"/></li>
      </ul>
    </div>
    <div class="main-slider-curve curve-img"></div>
  </section>
  <section class="welcome-section">
    <div class="container">
      <div class="row">
        
		<div id="shopping-cart">
<div class="txt-heading">Shopping Cart</div>

<a id="btnEmpty" href="list.php?action=empty">Empty Cart</a>

<?php 
if(isset($_SESSION["cart_item"])){
?>
	<a id="btnEmpty" href="processCart.php">Proceed to Check Out</a>
<?php
}

?>

<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	
<table cellpadding="10" cellspacing="1" class="blueTable" border="1">
<thead>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Code</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
<th style="text-align:center;" width="5%">Remove</th>
</tr>
</thead>	
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
			
				<tr>
				<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ". number_format($item_price,2); ?></td>
				<td style="text-align:center;"><a href="list.php?action=remove&code=<?php echo 'x'.$item["code"]; ?>" class="btnRemoveAction"><img src="images/icon-delete.png" alt="Remove Item" /></a></td>
				</tr>
			
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>
<tfoot>
<tr>
<td colspan="2" align="right"  style="line-height:26px;">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tfoot>
</table>		
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty Now</div>
<?php 
}
?>
</div>
		
		
      </div>
    </div>
  </section>
  <section class="pro-slider">
    <div class="pro-bx-slider">
      <div class="pro-slider-wrap" >
        <ul class="pbxslider gallery" align="center"> </ul>
      </div>
    </div>
  </section>
  <section class="new-collection">
    <div class="container">
      <div class="row">
        <div class="inner-container1">
          <div class="col-lg-12 stitle">
            <h2 align="left">New Events</h2>
          </div>
          <div id="main-container">
            <div id="content"> </div>
            <!--/content-->
            <div style="display:none;" class="nav_up" id="nav_up">
              <div style="margin-top:3px;margin-left:2px;"> <strong></strong> </div>
            </div>
			<div>
            
            <form name="search" action="list.php" method="get">
			Event Name <input type="text" name="searchme" id="searchme" width="250">
			<input type="submit" value="Search Event" class="btnAddAction" />
			</form>
			</div>
            <script language="Javascript" type="text/javascript">
$(function() {
    var $elem = $('#content');

    $('#nav_up').fadeIn('slow');

    $(window).bind('scrollstop', function() {
        $('#nav_up,#nav_down').stop().animate({'opacity': '0.4'});
    });

    $('#nav_up').click(
        function(e) {
            $('html, body').animate({scrollTop: '0px'}, 600);
        }
    );
});
</script>
            <p style="clear:both;"></p>
          </div>
          <!--/main-container-->
          
<?php


//new cart

if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
	<form method="post" action="list.php?action=add&code=<?php echo $product_array[$key]["event_id"]; ?>">
		<div class="col-lg-3 col-sm-3">
            <div class="deal_store round">
              <div class="pro-holder">
                <div class="deal-image">
                  <img src="images/<?php echo $product_array[$key]["event_pic"]; ?>" alt="productggg" width="100%" style="border-radius:10px;box-shadow:0px 1px 2px rgba(0,0,0,0.3);"/></a> </div>
                <div class="pro-content">
                  <div class="title_store">
                    <h4 class="pro-title" style="color:#000066; margin-left:7px;"> <?php echo $product_array[$key]["event_title"]; ?> <span></h4>
                  </div>
                  <div class="pro-footer">
                    <div class="deal-row" style="margin-bottom:5px; width:100%;">
                      <div class="grid_original"><span style="color:#000">Event Cost </span> <br/>
                        <strong><span style="color:#000">$ <?php echo $product_array[$key]["event_per_head_cost"]; ?></span></strong></div>
                     
                    </div>
              
					<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input type="submit" value="Add to Cart" class="btnAddAction" /></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
	</form>	
		
		
		
		
	<?php
		}
	}
	
	else{
		echo 'no records found';
	}

?>	   
        </div>
      </div>
    </div>
  </section>
  <?php
require_once('./footer.php');
?>
</div>
</body>
</html>