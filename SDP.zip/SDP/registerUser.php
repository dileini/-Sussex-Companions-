<?php
include("dealsManager/db_connector.php");
$FirstName    = $_POST['Fname'];
$LastName     = $_POST['Lname'];
$gender       = $_POST['gender'];
$email        = $_POST['Email'];
$password     = md5($_POST['Password']);
$rePassword   = $_POST['Repassword'];
$phone        = $_POST['Phone'];
$address      = $_POST['Address'];
$myNIC        = $_POST['nic'];
$hobbies      = $_POST['hobbies'];
$inter        = $_POST['inter'];
$loc          = $_POST['loc'];


echo $insrtQuery = "insert into `customer`(`firstName`,`lastName`,`gender`,`email`,`password`,`phone`,`address`,`nic`, `hobie`, `interest`,`register_by`,`location`)
values ('$FirstName','$LastName','$gender','$email','$password','$phone','$address',$myNIC, $hobbies,$inter,'self','$loc')";
$result = mysql_query($insrtQuery);
header("location: register.php?err=2");
?>